# SPDX-FileCopyrightText: 2026 Blender Authors
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""
Operators for remote API testing, model browsing, and agent ping.
"""

__all__ = (
    "_BFACW_OT_test_remote_api",
    "_BFACW_OT_refresh_remote_models",
    "_BFACW_OT_open_model_browser",
    "_BFACW_OT_ping_agent",
    "_BFACW_OT_check_ports",
    "_BFACW_OT_test_step",
    "_BFACW_OT_test_step_reset",
    "_BFACW_OT_asset_selftest_run",
    "_BFACW_OT_asset_selftest_reset",
    "BFACW_OT_copy_mcp_config",
    "BFACW_OT_register_claude_code",
    "BFACW_OT_test_mcp_config",
    "BFACW_OT_mcp_server_start",
    "BFACW_OT_mcp_server_stop",
    "BFACW_OT_save_provider",
    "BFACW_OT_delete_provider",
    "BFACW_OT_load_provider",
    "BFACW_OT_test_polyhaven_hdri",
    "BFACW_OT_test_polyhaven_texture",
    "BFACW_OT_open_harness_prefs",
    "BFACW_OT_open_addon_prefs",
    "BFACW_OT_open_url",
    "BFACW_OT_open_log",
    "BFACW_OT_compare_benchmarks",
)

import bpy  # pylint: disable=import-error

import threading

from .shared import effective_ports, get_llm_manager, get_agent_controller, HARNESS_PRESET_ITEMS
from . import agent_controller as _ac_mod


class _BFACW_OT_test_remote_api(bpy.types.Operator):  # type: ignore[misc]
    bl_idname = "bfacw.test_remote_api"
    bl_label = "Test Connection"
    bl_description = "Test the remote API connection"

    def execute(self, context: bpy.types.Context) -> set[str]:
        prefs = context.preferences.addons[__package__].preferences
        if not prefs.remote_api_url:
            self.report({"ERROR"}, "No API URL configured")
            return {"CANCELLED"}
        if not prefs.remote_api_key:
            self.report({"ERROR"}, "No API key configured")
            return {"CANCELLED"}

        llm = get_llm_manager()
        ok = llm.check_remote_api(prefs.remote_api_url, prefs.remote_api_key)
        if ok:
            self.report({"INFO"}, "Remote API connection successful")
        else:
            self.report({"ERROR"}, "Remote API connection failed -- check URL and key")
        return {"FINISHED"}


class _BFACW_OT_refresh_remote_models(bpy.types.Operator):  # type: ignore[misc]
    bl_idname = "bfacw.refresh_remote_models"
    bl_label = "Refresh Models"
    bl_description = "Fetch the live model list from the remote API"

    def execute(self, context: bpy.types.Context) -> set[str]:
        prefs = context.preferences.addons[__package__].preferences
        if not prefs.remote_api_url:
            self.report({"ERROR"}, "No API URL configured -- select a provider first")
            return {"CANCELLED"}
        if not prefs.remote_api_key:
            self.report({"ERROR"}, "No API key configured")
            return {"CANCELLED"}

        llm = get_llm_manager()
        models, error = llm.fetch_remote_models(prefs.remote_api_url, prefs.remote_api_key)

        if error:
            prefs.remote_models_count = 0
            prefs.remote_models_fetch_error = error
            self.report({"ERROR"}, error)
            return {"CANCELLED"}

        prefs.remote_models_count = len(models)
        prefs.remote_models_fetch_error = ""

        self.report({"INFO"}, "{:d} models available from the API".format(len(models)))
        return {"FINISHED"}


class _BFACW_OT_open_model_browser(bpy.types.Operator):  # type: ignore[misc]
    bl_idname = "bfacw.open_model_browser"
    bl_label = "Browse Models"
    bl_description = "Open openrouter.ai/models in your browser to find model IDs"

    def execute(self, context: bpy.types.Context) -> set[str]:
        import webbrowser
        webbrowser.open("https://openrouter.ai/models")
        return {"FINISHED"}


class _BFACW_OT_check_ports(bpy.types.Operator):  # type: ignore[misc]
    bl_idname = "bfacw.check_ports"
    bl_label = "Check Ports"
    bl_description = "Test whether the default ports are available or in use"

    _result: dict = {}  # class-level storage for display in draw()

    def execute(self, context: bpy.types.Context) -> set[str]:
        prefs = context.preferences.addons[__package__].preferences
        _bridge_port, _mcp_port, _llm_port = effective_ports(prefs)

        def _do_check():
            _BFACW_OT_check_ports._result = _ac_mod.check_ports_available(
                bridge_port=_bridge_port,
                mcp_port=_mcp_port,
                llm_port=_llm_port,
            )

        thread = threading.Thread(target=_do_check, daemon=True)
        thread.start()
        thread.join(timeout=10)

        result = _BFACW_OT_check_ports._result
        if not result:
            self.report({"ERROR"}, "Port check timed out")
            return {"CANCELLED"}

        lines = []
        for label_key in [("bridge", "Bridge"), ("mcp", "MCP"), ("llm", "LLM")]:
            available = result.get(label_key[0], False)
            lines.append("{:s}: {:s}".format(label_key[1], "Available" if available else "In Use"))

        summary = "  |  ".join(lines)
        if all(result.values()):
            self.report({"INFO"}, "All ports available -- {:s}".format(summary))
        else:
            self.report({"WARNING"}, "Some ports in use -- {:s}".format(summary))

        return {"FINISHED"}


class _BFACW_OT_ping_agent(bpy.types.Operator):  # type: ignore[misc]
    bl_idname = "bfacw.ping_agent"
    bl_label = "Ping"
    bl_description = "Test connectivity to MCP server and LLM backend"

    _result: dict = {}  # class-level storage for display in draw()

    def execute(self, context: bpy.types.Context) -> set[str]:
        _ac = get_agent_controller()
        prefs = context.preferences.addons[__package__].preferences
        _bridge_port, _mcp_port, _llm_port = effective_ports(prefs)

        def _do_ping():
            _BFACW_OT_ping_agent._result = _ac.ping_agent(
                mcp_port=_mcp_port, llm_port=_llm_port, bridge_port=_bridge_port,
                operating_mode=prefs.operating_mode,
                check_harness_config=(prefs.operating_mode == "EXTERNAL_HARNESS"),
                use_blender_python=getattr(prefs, "use_blender_python_for_harness", True),
            )

        thread = threading.Thread(target=_do_ping, daemon=True)
        thread.start()
        thread.join(timeout=35)

        result = _BFACW_OT_ping_agent._result

        if not result:
            self.report({"ERROR"}, "Ping timed out or failed")
            return {"CANCELLED"}

        lines = []
        for key, label in [
            ("bridge_server", "Bridge"),
            ("mcp_server", "MCP"),
            ("llm_health", "LLM Health"),
            ("llm_chat", "LLM Chat"),
            ("harness_config", "Harness Config"),
        ]:
            val = result.get(key, "not tested")
            if val == "N/A":
                continue
            lines.append("{:s}: {:s}".format(label, val))

        summary = " | ".join(lines)
        if result.get("all_ok"):
            self.report({"INFO"}, "All OK -- {:s}".format(summary))
        else:
            self.report({"ERROR"}, summary)

        return {"FINISHED"}


# ---------------------------------------------------------------------------
# Multi-Step Test Suites -- natural artist workflow sequences
#
# Each test suite is a list of (step_number, label, prompt) tuples.
# Steps are designed to be run in order, building on each other like
# a real artist would work. The prompts use natural language -- as if
# you're asking a colleague to do something.

_TEST_SUITES: dict[str, list[tuple[int, str, str]]] = {
    # -- Scene Building Workflow --------------------------------------
    # Tests object creation, collections, materials, lighting, camera
    "scene_build": [
        (1, "Ground",
         "I'm setting up a scene to render. First, create a rounded corner ground mesh -- "
         "like a large stage floor or backdrop. "
         "Name it \"Ground\"."),
        (2, "Props",
         "Now scatter some random cartoon objects on the ground, like rocks, bushes, trees."
         "Arrange them in a loose circle like toys"
         "around the center. Vary their, viewport colors, sizes and shapes so they look interesting."),
        (3, "Collections",
         "Organize everything into collections. Create three collections "
         "with color tags: \"Props\" (blue), \"Ground\" (green), and "
         "\"Lighting\" (yellow). Move the ground into Ground, "
         "all the scattered objects into Props."),
        (4, "Materials",
         "Give each object in the Props collection a material. Use a "
         "mix: some metallic (gold/copper), some rough (stone/concrete), "
         "and one glass. Name each material after the object."),
        (5, "Lighting",
         "Now light the scene. Add a Sun lamp angled from above-right "
         "for key light, and a warm-colored Point light near the center "
         "for fill. Put both in the Lighting collection."),
        (6, "Camera",
         "Place the camera to frame the whole scene from a slight "
         "high angle -- like a long shot. Use a nice portrait "
         "focal length. Render at a decent HD resolution with EEVEE."),
    ],
    # -- Animation Workflow ------------------------------------------
    # Tests keyframes, timeline, motion paths
    "animation": [
        (1, "Ball",
         "Create a sphere at the origin, name it \"Bouncing Ball\". "
         "Give it a shiny red rubber material with smooth shading and a bit of SSS."),
        (2, "Floor",
         "Add floor below the ball -- position it "
         "just under the ball and scale it wide enoguh for the animation. "
         "Give it a simple tiled floor material (like a gym floor) and name it \"Floor\"."),
        (3, "Bounce Keys",
         "Animate the ball bouncing up and down. "
         "It starts on the floor, jumps up high, comes back down, "
         "then does a few smaller bounces that settle back to the "
         "floor. Make the whole animation about 4 seconds long at "
         "30 fps. Try make the hit on the ground feel solid and the bounces feel natural."),
        (4, "Squash & Stretch",
         "Add squash and stretch to the bounce. When the ball hits "
         "the floor it should flatten (squash), and when it's in the "
         "air it should elongate slightly (stretch). Keyframe the "
         "scale to match the motion."),
        (5, "Camera Move",
         "Add a camera that slowly moves around the ball. "
         "Keep the camera tracked a little towards the ball the whole time "
         "so the viewer sees the bounce but follow it. "
         "Make sure the framing covers the full arc."),
    ],
    # -- Modifier Chain Workflow -----------------------------------------
    # Tests modifier stacking, applying, and remeshing on a torus.
    # Goal: build a detailed mechanical part from a torus base.
    "modifiers": [
        (1, "Torus Base",
         "Create a torus mesh named 'Gear_Base'. "
         "Major radius 1.0, minor radius 0.3, "
         "major segments 48, minor segments 16. "
         "Position it at the origin, centered."),
        (2, "Array & Bevel",
         "Add an Array modifier (count 3, offset on X axis by 2.5) "
         "to create a row of three rings. "
         "Then add a Bevel modifier (width 0.05, segments 2) to round all edges. "
         "Do NOT apply yet."),
        (3, "Apply Array",
         "Apply the Array modifier so the three rings become real geometry. "
         "Then check how many vertices the object has and report the count."),
        (4, "Remesh",
         "Add a Remesh modifier (mode: Voxel, voxel size 0.1) to unify "
         "the merged geometry into a single clean mesh. "
         "Apply the Remesh modifier."),
        (5, "Solidify & Smooth",
         "Add a Solidify modifier (thickness 0.02) to give the mesh wall thickness. "
         "Then add a Smooth modifier (factor 0.5, iterations 3) to soften edges. "
         "Apply both modifiers."),
        (6, "Subdivide & Final",
         "Add a Subdivision Surface modifier (viewport levels 2) for a polished look. "
         "Do NOT apply it yet. "
         "Then rename the object to 'Mechanical_Part' and "
         "report the final vertex count and modifier stack."),
    ],

    # -- Asset Browser Workflow -------------------------------------
    # Tests asset browser search, material assignment, node groups
    "assets_browser": [
        (1, "Search",
         "Search the asset browser for any available materials. "
         "List what you find."),
        (2, "Assign",
         "Create a cube and assign a material asset from the asset browser to it."),
        (3, "Node Group",
         "Load a node group asset from the asset browser into the active material."),
        (4, "Collection",
         "Load a collection asset from the asset browser into the scene."),
        (5, "Mesh",
         "Load a mesh asset from the asset browser into the scene."),
        (6, "World",
         "Load a world asset from the asset browser and set it as the scene world."),
    ],
    # -- Poly Haven Workflow ---------------------------------------
    # Tests Poly Haven integration, PBR materials, model import
    "polyhaven": [
        (1, "Texture",
         "Search Poly Haven for a brick texture, download and create a PBR material."),
        (2, "Model",
         "Search Poly Haven for a chair model, download and import it into the scene."),
        (3, "HDRI",
         "Search Poly Haven for a sunset HDRI, download and set it as the world environment."),
        (4, "Apply",
         "Create a cube and apply the brick PBR material to it."),
        (5, "Render",
         "Add camera and lighting, render the scene with the imported assets."),
    ],
    # -- Shader Nodes Workflow -------------------------------------
    # Tests material creation, node tree building
    "shader_nodes": [
        (1, "Material",
         "Create a new material named \"Procedural_Grass\"."),
        (2, "Node Tree",
         "Build a node tree: Noise Texture -> ColorRamp -> Principled BSDF. "
         "Use green colors for the grass look."),
        (3, "Assign",
         "Create a plane and assign the Procedural_Grass material to it."),
        (4, "Preview",
         "Take a screenshot of the 3D viewport to preview the shader."),
    ],
    # -- Geometry Nodes Workflow -----------------------------------
    # Tests GN modifier, node tree building
    "geometry_nodes": [
        (1, "GN Modifier",
         "Create a Geometry Nodes modifier on a new grid object."),
        (2, "Node Tree",
         "Build a GN node tree: Distribute Points on Faces -> Instance on Points "
         "(using an Ico Sphere) -> Set Shade Smooth."),
        (3, "Random Scale",
         "Add a Random Value node to vary the instance scale between 0.5 and 2.0."),
        (4, "Verify",
         "Take a screenshot of the 3D viewport to verify the geometry nodes result."),
    ],
    # -- Sequencer Workflow ----------------------------------------
    # Tests video sequence editor operations
    "sequencer": [
        (1, "Color Strip",
         "Create a color strip in the Video Sequence Editor with a blue background."),
        (2, "Transform",
         "Add a transform effect strip on top of the color strip."),
        (3, "Text",
         "Add a text overlay strip with the text \"BFA Coworker Test\"."),
        (4, "Range",
         "Set the render frame range from 1 to 100 for the sequencer output."),
    ],
    # -- Image Editor Workflow -------------------------------------
    # Tests image creation, pixel manipulation
    "image_editor": [
        (1, "New Image",
         "Create a new 512x512 image named \"Test_Pattern\" in the Image Editor."),
        (2, "Draw",
         "Draw a colored rectangle on the image -- fill the center half with red."),
        (3, "Save",
         "Save the image to disk as test_pattern.png."),
    ],
    # -- Compositor Workflow ---------------------------------------
    # Tests compositor node setup
    "compositor": [
        (1, "Enable",
         "Enable the compositor and set it to use nodes."),
        (2, "Node Tree",
         "Add Render Layers -> Blur -> Viewer node chain in the compositor."),
        (3, "Settings",
         "Set the blur to use Gaussian with 10px size."),
        (4, "Render",
         "Render a frame and verify the compositor output."),
    ],
    # -- Multi-Editor Cross-Context --------------------------------
    # Tests agent ability to work across multiple editors
    "multi_editor_cross": [
        (1, "Mesh",
         "Create a monkey head mesh object (Suzanne)."),
        (2, "GN Modifier",
         "Add a Geometry Nodes modifier to the monkey and build a simple node tree."),
        (3, "Material",
         "Create a material for the monkey with a Principled BSDF."),
        (4, "Render",
         "Render a frame of the monkey with the GN modifier and material applied."),
    ],
    # -- Baseline Latency (quick sanity -- fun scene) -----------------
    "baseline": [
        (1, "Stone Ring",
         "Can you make a stonehenge? First, create a ring of stone "
         "pillars -- tall, rough-hewn blocks arranged in a circle "
         "around the center, evenly spaced. Make them look like "
         "standing stones. Name them \"Pillar_1\" through \"Pillar_8\"."),
        (2, "Lintels",
         "Now add lintels on top of the pillars. For each pair of "
         "adjacent pillars, create a horizontal beam resting on top. "
         "Make each one thick enough to look like a solid stone "
         "crossbeam. Name them \"Lintel_1\" through \"Lintel_8\"."),
        (3, "Ground",
         "Add a large flat ground plane beneath the circle -- a wide "
         "flat disc. Give it a grassy green material."),
        (4, "Material",
         "Give all the stone pillars and lintels a rough stone "
         "material: high roughness, low specular, a warm gray color. "
         "Use a noise texture to add some surface variation."),
        (5, "Lighting",
         "Add dramatic lighting: a sun lamp angled low from the east "
         "(like sunrise) with warm orange tint, and a faint blue fill "
         "light from the opposite side for contrast."),
        (6, "Camera",
         "Place the camera at a low angle looking up at the stones, "
         "framing the circle with the sun behind the pillars. "
         "Use a wide focal length for a dramatic shot. "
         "Frame and render at square resolution."),
    ],
    # -- Error Handling (ambiguous prompts) --------------------------
    "error_handling": [
        (1, "Vague",
         "Make it nicer."),
        (2, "Impossible",
         "Render a 16K IMAX movie with 10 million polygons."),
        (3, "Contradiction",
         "Delete everything but keep all objects."),
    ],
    # -- Vision: Camera Placement ------------------------------------
    # For vision-capable models. Tests whether the model can SEE the
    # viewport via get_screenshot_of_area_as_image and use what it sees
    # to place, reframe, and verify a camera.
    "vision_camera": [
        (1, "Stage",
         "I'm testing camera framing, so build me a small product stage: "
         "a round ground disc with a light gray material, and three distinct "
         "objects on it -- a red cube, a blue cylinder, and a green sphere. "
         "Place them asymmetrically (not in a line, not all at the center) "
         "at different distances from the center so the composition is "
         "interesting. Name them \"Cube_A\", \"Cylinder_B\", \"Sphere_C\". "
         "Do NOT add a camera yet."),
        (2, "Frame It",
         "Add a camera for a classic product shot: a 3/4 view from the "
         "front-left, slightly elevated, aiming at the middle of the three "
         "objects, with all three fully in frame and a little margin around "
         "them. Now take a screenshot of the 3D viewport with the "
         "get_screenshot_of_area_as_image tool and LOOK at the image. "
         "Check the framing: if any object is clipped, too small, or off- "
         "center, move or re-aim the camera and re-screenshot until the "
         "shot frames all three objects nicely. Tell me what you saw in "
         "the screenshot and the final camera placement."),
        (3, "Hero Angle",
         "Reframe the same camera as a dramatic low-angle hero shot: "
         "camera near the ground, looking up at the objects from the front, "
         "like a product advertisement. Take a screenshot of the viewport "
         "with get_screenshot_of_area_as_image and LOOK at it. Adjust the "
         "camera position, angle, and target until the composition looks "
         "intentional -- all three objects visible and balanced, the ground "
         "disc framing the bottom of the shot. Iterate with more screenshots "
         "until it looks good, then report the camera location, rotation, "
         "and what the final screenshot showed."),
        (4, "Final Check",
         "Now switch the 3D viewport to camera view so a screenshot shows "
         "exactly what the camera sees, and take a final screenshot with "
         "get_screenshot_of_area_as_image. Verify the composition from the "
         "camera's perspective: all three objects fully in frame, the shot "
         "balanced, and a pleasant low-angle composition. If anything is "
         "clipped or off, adjust the camera and re-check. Report the final "
         "camera location, rotation, and focal length, and what the final "
         "screenshot looks like."),
    ],
    # -- Vision: Relative Placement ----------------------------------
    # For vision-capable models. Tests whether the model can SEE one
    # object in relation to another and position new objects correctly
    # (on top, centered, touching) -- verified via screenshots.
    "vision_relative": [
        (1, "Table",
         "I'm testing how well you can judge object placement visually. "
         "Create a simple pedestal table: a rectangular top (about 2m x "
         "1.2m, 0.1m thick) at 0.9m height with four thin legs. Give it a "
         "warm brown wood material and name it \"Table\". Take a screenshot "
         "of the 3D viewport with get_screenshot_of_area_as_image and confirm "
         "it reads as a table before moving on."),
        (2, "Cup on Table",
         "Create a bright red cup (a cylinder, about 0.25m tall) and place "
         "it so it rests exactly ON TOP of the table: the cup's bottom must "
         "touch the table's top face, and the cup should be centered on the "
         "table. Name it \"Cup\". Now take a screenshot of the viewport with "
         "get_screenshot_of_area_as_image and LOOK at it: if the cup floats "
         "above the table or sinks into it, fix the position and re-screenshot. "
         "Keep adjusting until the screenshot clearly shows the cup resting "
         "on the table surface."),
        (3, "Stack",
         "Place a small green sphere (a marble, 0.08m radius) on top of the "
         "cup's rim, balanced on the opening. Take a screenshot with "
         "get_screenshot_of_area_as_image and LOOK at it: the marble must sit "
         "centered on the cup's opening -- not floating above it, not half- "
         "buried inside. Adjust the marble's position and re-screenshot until "
         "the screenshot shows it balanced on top. Name it \"Marble\"."),
        (4, "Centered Cone",
         "Create a cylinder pedestal (0.6m radius, 0.4m tall) sitting on the "
         "table next to the cup, and a cone (0.3m radius, 0.5m tall). Place "
         "the cone exactly centered on the cylinder's top face. Take a "
         "screenshot with get_screenshot_of_area_as_image, look at it, and "
         "adjust the cone's X/Y position until it is visually dead-center on "
         "the cylinder -- neither leaning nor off to the side. Name them "
         "\"Pedestal\" and \"Cone\"."),
        (5, "Touch",
         "Create one more cube (0.4m) and place it NEXT TO the pedestal: "
         "the new cube's side must touch the pedestal's side exactly, both "
         "sitting on the table top -- no gap and no overlap. Take a screenshot "
         "with get_screenshot_of_area_as_image, look at it, and adjust the "
         "cube's position until the two objects are flush. Name it "
         "\"Neighbor\" and report how you verified the contact."),
    ],
}

# Track which step the user is on for each suite.
# Keyed by suite name, value is the current step index (0-based).
_test_suite_progress: dict[str, int] = {}
# Busy guard: True while a step thread is running for a given suite.
_test_suite_running: dict[str, bool] = {}
# Timing data: keyed by (suite_name, step_number) -> elapsed seconds.
_test_suite_timings: dict[tuple[str, int], float] = {}
# Per-step outcome: keyed by (suite_name, step_number) -> "ok" | "failed".
# Without this a failed step was indistinguishable from a successful one in
# the Diagnostics panel -- both showed only a timing, so a suite that failed
# instantly looked like it had simply run quickly.
_test_suite_status: dict[tuple[str, int], str] = {}
# Per-step error text: keyed by (suite_name, step_number) -> message.
_test_suite_errors: dict[tuple[str, int], str] = {}

# Steps whose prompt is deliberately vague / impossible / contradictory: the
# correct behaviour is to ASK a clarifying question or DECLINE, not to act.
# The end-of-turn execution guarantee must NOT force these steps to act -- for
# the contradictory "delete everything but keep all objects" prompt, forcing
# action could nudge a destructive mistake.  Keyed by (suite, step_number).
_REFUSAL_STEPS: set[tuple[str, int]] = {
    ("error_handling", 1),
    ("error_handling", 2),
    ("error_handling", 3),
}
# Path to persist benchmark results.
import os as _os
_BENCHMARK_RESULTS_PATH = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "benchmark_results.json")


class _BFACW_OT_test_step(bpy.types.Operator):  # type: ignore[misc]
    """Run the next step in a multi-step test suite."""
    bl_idname = "bfacw.test_step"
    bl_label = "Run Step"
    bl_description = "Run the next step in this test suite"

    suite: bpy.props.StringProperty(  # type: ignore[valid-type]
        name="Suite",
        default="",
    )

    def execute(self, context: bpy.types.Context) -> set[str]:
        if not get_agent_controller()._agent_state.mcp_server_running:
            self.report({"ERROR"}, "Coworker is not running. Start it from Preferences.")
            return {"CANCELLED"}

        suite = _TEST_SUITES.get(self.suite)
        if not suite:
            self.report({"ERROR"}, "Unknown test suite '{:s}'".format(self.suite))
            return {"CANCELLED"}

        # Busy guard: don't start a new step while one is running.
        if _test_suite_running.get(self.suite, False):
            self.report({"WARNING"}, "A step is already running for this suite.")
            return {"CANCELLED"}

        # Get current step index.
        step_idx = _test_suite_progress.get(self.suite, 0)
        if step_idx >= len(suite):
            self.report({"INFO"}, "All steps completed! Reset to run again.")
            return {"FINISHED"}

        step_num, step_label, prompt = suite[step_idx]
        # Capture the pre-step object set (main thread) so a FAILED step can
        # be rolled back and not poison the next step.
        _before_objects = {o.name for o in bpy.data.objects}
        _run_test_step(
            context, self.suite, step_num, step_label, prompt,
            before_objects=_before_objects,
        )

        # Advance progress.
        _test_suite_progress[self.suite] = step_idx + 1

        total = len(suite)
        remaining = total - (step_idx + 1)
        if remaining == 0:
            # Auto-reset on completion.
            _test_suite_progress[self.suite] = 0
            # Persist results.
            _save_benchmark_results()
            self.report({"INFO"}, "Step {:d}/{:d} '{:s}' done -- suite complete, auto-reset!".format(
                step_num, total, step_label))
        else:
            self.report({"INFO"}, "Step {:d}/{:d} '{:s}' done -- {:d} more to go".format(
                step_num, total, step_label, remaining))
        return {"FINISHED"}


class _BFACW_OT_test_step_reset(bpy.types.Operator):  # type: ignore[misc]
    """Reset progress for a test suite so it starts from step 1 again."""
    bl_idname = "bfacw.test_step_reset"
    bl_label = "Reset"
    bl_description = "Reset this test suite back to step 1"

    suite: bpy.props.StringProperty(  # type: ignore[valid-type]
        name="Suite",
        default="",
    )

    def execute(self, context: bpy.types.Context) -> set[str]:
        del context
        _test_suite_progress.pop(self.suite, None)
        # Clear this suite's recorded outcomes so a re-run starts clean.
        for key in [k for k in _test_suite_timings if k[0] == self.suite]:
            _test_suite_timings.pop(key, None)
        for key in [k for k in _test_suite_status if k[0] == self.suite]:
            _test_suite_status.pop(key, None)
        for key in [k for k in _test_suite_errors if k[0] == self.suite]:
            _test_suite_errors.pop(key, None)
        self.report({"INFO"}, "Test suite '{:s}' reset to step 1".format(self.suite))
        return {"FINISHED"}


class _BFACW_OT_asset_selftest_run(bpy.types.Operator):  # type: ignore[misc]
    """Run the deterministic (LLM-free) asset-tool self-test suite."""
    bl_idname = "bfacw.asset_selftest_run"
    bl_label = "Run All Auto"
    bl_description = (
        "Run every asset tool against a throwaway fixture library in-session "
        "(no MCP server, no LLM) with PASS/FAIL + timing per step"
    )

    _timer = None

    def invoke(self, context: bpy.types.Context, _event) -> set[str]:
        from . import asset_selftests as _ast

        if _ast.is_running():
            self.report({"WARNING"}, "Self-test is already running.")
            return {"CANCELLED"}
        self.report({"INFO"}, "Starting asset self-test suite...")

        wm = context.window_manager
        self._timer = wm.event_timer_add(0.25, window=context.window)
        wm.modal_handler_add(self)

        def _do_run():
            try:
                _ast.run_auto_suite()
            except Exception as ex:  # pylint: disable=broad-exception-caught
                print("[Coworker] asset self-test crashed: {:s}".format(str(ex)))

        threading.Thread(target=_do_run, daemon=True).start()
        return {"RUNNING_MODAL"}

    def modal(self, context: bpy.types.Context, _event) -> set[str]:
        from . import asset_selftests as _ast

        # Redraw the preferences UI so step results appear as they land.
        for area in context.window.screen.areas:
            if area.type == "PREFERENCES":
                area.tag_redraw()
        if _ast.is_running():
            return {"RUNNING_MODAL"}
        wm = context.window_manager
        if self._timer is not None:
            wm.event_timer_remove(self._timer)
            self._timer = None
        return {"FINISHED"}


class _BFACW_OT_asset_selftest_reset(bpy.types.Operator):  # type: ignore[misc]
    """Clear asset self-test results (and any leftover fixture data)."""
    bl_idname = "bfacw.asset_selftest_reset"
    bl_label = "Reset"
    bl_description = "Clear asset self-test results"

    def execute(self, context: bpy.types.Context) -> set[str]:
        del context
        from . import asset_selftests as _ast
        _ast._results.clear()
        _ast._last_error = ""
        try:
            import bpy as _bpy  # pylint: disable=import-error
            _ast._purge_datablocks(_bpy)
        except Exception:
            pass
        self.report({"INFO"}, "Asset self-test results cleared.")
        return {"FINISHED"}


def _save_benchmark_results() -> None:
    """Save benchmark timings to a JSON file."""
    import json as _json
    import time as _time

    if not _test_suite_timings:
        return

    results = {
        "timestamp": _time.time(),
        "timings": {
            "{:s}:{:d}".format(k[0], k[1]): v
            for k, v in _test_suite_timings.items()
        },
    }

    try:
        # Load existing results if present.
        existing = []
        if _os.path.isfile(_BENCHMARK_RESULTS_PATH):
            with open(_BENCHMARK_RESULTS_PATH, "r") as f:
                existing = _json.load(f)
                if not isinstance(existing, list):
                    existing = [existing]
        existing.append(results)
        # Keep last 20 runs.
        existing = existing[-20:]
        with open(_BENCHMARK_RESULTS_PATH, "w") as f:
            _json.dump(existing, f, indent=2)
        print("[Coworker] Benchmark results saved to {:s}".format(_BENCHMARK_RESULTS_PATH))
    except Exception as ex:
        print("[Coworker] Failed to save benchmark results: {:s}".format(str(ex)))


def _load_previous_benchmark() -> dict | None:
    """Load the second-to-last benchmark run for comparison, or None."""
    import json as _json
    try:
        if _os.path.isfile(_BENCHMARK_RESULTS_PATH):
            with open(_BENCHMARK_RESULTS_PATH, "r") as f:
                data = _json.load(f)
                if isinstance(data, list) and len(data) >= 2:
                    return data[-2]
    except Exception:  # pylint: disable=broad-exception-caught
        pass
    return None


def _record_step_outcome(
    suite_key: str,
    step_num: int,
    elapsed: float,
    error: str = "",
) -> None:
    """Record a step's timing and outcome for the Diagnostics panel.

    *error* empty means the step succeeded.  A non-empty *error* marks the
    step failed and stores the message so the panel can show it -- previously
    only the timing was kept, so failures were invisible.
    """
    _test_suite_timings[(suite_key, step_num)] = elapsed
    if error:
        _test_suite_status[(suite_key, step_num)] = "failed"
        _test_suite_errors[(suite_key, step_num)] = error
    else:
        _test_suite_status[(suite_key, step_num)] = "ok"
        _test_suite_errors.pop((suite_key, step_num), None)


def _suite_failure_count(suite_key: str) -> int:
    """Return how many steps of *suite_key* have failed."""
    return sum(
        1 for (sk, _step), status in _test_suite_status.items()
        if sk == suite_key and status == "failed"
    )


def _reset_scene_to_before(before_objects: set[str]) -> None:
    """Delete objects created since *before_objects* -- main-thread rollback.

    Called after a FAILED benchmark step (when "Reset on failure" is on) so
    the step's leftover geometry does not corrupt the next step (duplicate
    objects, ``.001`` name drift).  MUST run on the main thread -- bpy data
    edits are not thread-safe, so the caller schedules this via a timer.
    """
    try:
        added = [o for o in list(bpy.data.objects) if o.name not in before_objects]
        for obj in added:
            try:
                bpy.data.objects.remove(obj, do_unlink=True)
            except Exception:  # pylint: disable=broad-exception-caught
                pass
        # Return to a neutral context so the next step starts cleanly.
        try:
            if bpy.context.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
        except Exception:  # pylint: disable=broad-exception-caught
            pass
        # Purge datablocks the failed step orphaned (meshes, materials, ...).
        for coll in (
            bpy.data.meshes, bpy.data.materials, bpy.data.curves,
            bpy.data.lights, bpy.data.cameras, bpy.data.images,
            bpy.data.node_groups, bpy.data.collections,
        ):
            for block in [b for b in coll if b.users == 0]:
                try:
                    coll.remove(block)
                except Exception:  # pylint: disable=broad-exception-caught
                    pass
        print("[Coworker] benchmark reset: removed {:d} object(s) left by "
              "the failed step".format(len(added)))
    except Exception as _ex:  # pylint: disable=broad-exception-caught
        print("[Coworker] benchmark reset failed: {:s}".format(str(_ex)))


def _run_test_step(
    context: bpy.types.Context,
    suite_key: str,
    step_num: int,
    step_label: str,
    prompt: str,
    before_objects: set[str] | None = None,
) -> None:
    """Run a single test step through the full agent pipeline in a background thread.

    *before_objects* is the object-name set captured before the step; when a
    step FAILS and "Reset on failure" is enabled, the scene is rolled back to
    it so the failure does not poison the following step.
    """
    _ac = get_agent_controller()

    prefs = context.preferences.addons[__package__].preferences
    _bridge_port, _mcp_port, _llm_port = effective_ports(prefs)
    # Use actual port if auto-shuffle kicked in.
    actual_mcp = _ac._agent_state.mcp_port_actual
    test_mcp_port = actual_mcp if actual_mcp else _mcp_port

    # Refusal steps must not be force-nudged into acting (see _REFUSAL_STEPS).
    allow_action_nudge = (suite_key, step_num) not in _REFUSAL_STEPS
    reset_on_failure = bool(getattr(prefs, "reset_scene_on_failure", True))

    # Resolve LLM config (same as chat_send).
    llm = get_llm_manager()
    from . import ui_chat as _ui_chat
    _ui_chat._sync_prefs_to_config(prefs)
    llm_cfg = llm.get_config()
    llm_url = None
    api_key = None
    model = None
    if llm_cfg.mode == "remote":
        llm_url = llm_cfg.remote_api_url
        api_key = llm_cfg.remote_api_key
        model = llm_cfg.remote_model or None

    print("[Coworker] test suite '{:s}': step {:d}/{:s} starting...".format(
        suite_key, step_num, step_label))
    print("[Coworker] test suite '{:s}': prompt = {:s}".format(suite_key, prompt))

    def _do_step():
        import time as _time
        _test_suite_running[suite_key] = True
        t_start = _time.monotonic()
        _failed = False
        # Snapshot the error before the call.  We deliberately do NOT clear
        # _agent_state.error up front: the session log exports it, and
        # clearing it destroyed the evidence of what actually failed.
        _prev_error = _ac._agent_state.error or ""
        try:
            _ac.run_conversation_turn(
                user_message=prompt,
                on_text=None,
                on_status=lambda s: print("[Coworker] test suite '{:s}': status = {:s}".format(
                    suite_key, s)),
                llm_url=llm_url or None,
                api_key=api_key or None,
                model=model,
                mcp_port=test_mcp_port,
                allow_action_nudge=allow_action_nudge,
            )
            elapsed = _time.monotonic() - t_start
            # run_conversation_turn does NOT raise on an LLM failure -- it
            # returns normally and records the reason in _agent_state.error.
            # Checking the exception alone therefore reported every failed
            # step as a success, which is why a broken benchmark run looked
            # like it had simply done nothing.
            step_error = _ac._agent_state.error or ""
            # An error that differs from the pre-call snapshot is this step's
            # failure.  An unchanged error is stale (left by an earlier step)
            # and must not be attributed here.  The one case this cannot
            # distinguish is a step that fails with a byte-identical message
            # to the previous step's -- rare, and erring toward "success"
            # there keeps the log honest about which step introduced it.
            if step_error and step_error != _prev_error:
                _failed = True
                _record_step_outcome(suite_key, step_num, elapsed, step_error)
                print("[Coworker] test suite '{:s}': step {:d}/{:s} FAILED in {:.1f}s -- {:s}".format(
                    suite_key, step_num, step_label, elapsed, step_error))
            else:
                _record_step_outcome(suite_key, step_num, elapsed)
                print("[Coworker] test suite '{:s}': step {:d}/{:s} completed in {:.1f}s".format(
                    suite_key, step_num, step_label, elapsed))
        except Exception as ex:
            _failed = True
            elapsed = _time.monotonic() - t_start
            _record_step_outcome(suite_key, step_num, elapsed, str(ex))
            print("[Coworker] test suite '{:s}': step {:d}/{:s} FAILED in {:.1f}s -- {:s}".format(
                suite_key, step_num, step_label, elapsed, str(ex)))
            _ac._agent_state.error = str(ex)
        finally:
            _test_suite_running[suite_key] = False
            # Reset-on-failure: roll the scene back to its pre-step object set
            # so the failed step's leftovers do not corrupt the next step.
            # Scheduled on the MAIN thread -- bpy data edits are not thread-safe.
            if _failed and reset_on_failure and before_objects is not None:
                bpy.app.timers.register(
                    (lambda _b=set(before_objects): (
                        _reset_scene_to_before(_b), None)[1]),
                    first_interval=0.0,
                )

    thread = threading.Thread(target=_do_step, daemon=True)
    thread.start()


# ---------------------------------------------------------------------------
# Copy MCP Client Config (External Harness)

class BFACW_OT_copy_mcp_config(bpy.types.Operator):  # type: ignore[misc]
    """Copy MCP client configuration to the clipboard."""
    bl_idname = "bfacw.copy_mcp_config"
    bl_label = "Copy MCP Config"
    bl_description = "Copy the MCP client configuration to the clipboard"

    client_type: bpy.props.EnumProperty(  # type: ignore[valid-type]
        name="Client",
        items=HARNESS_PRESET_ITEMS,
        default="claude_desktop",
    )

    def execute(self, context: bpy.types.Context) -> set[str]:
        prefs = context.preferences.addons[__package__].preferences
        _bridge_port, _, _ = effective_ports(prefs)
        use_blender_py = getattr(prefs, "use_blender_python_for_harness", True)
        config = _ac_mod.generate_mcp_client_config(
            client_type=self.client_type,
            blender_host=prefs.host,
            blender_port=_bridge_port,
            use_blender_python=use_blender_py,
        )
        context.window_manager.clipboard = config

        # Preflight the config we just handed out.  The addon previously
        # emitted configs it had never executed, so a broken interpreter path
        # or missing PYTHONPATH entry only surfaced as an opaque traceback
        # inside the user's MCP client.  Copy anyway (the user may target a
        # different machine) but warn with the actionable hint.
        check = _ac_mod.validate_mcp_client_config(
            client_type=self.client_type,
            blender_host=prefs.host,
            blender_port=_bridge_port,
            use_blender_python=use_blender_py,
        )
        BFACW_OT_test_mcp_config._result = check
        if not check.get("ok"):
            self.report(
                {"WARNING"},
                "Config copied, but it may not work: {:s}".format(
                    check.get("hint") or check.get("summary") or "validation failed"),
            )
        elif check.get("bridge_ok") is False:
            self.report(
                {"WARNING"},
                "Config copied and valid -- but the bridge is not running on "
                "port {:d}. Click Start Bridge.".format(_bridge_port),
            )
        else:
            self.report({"INFO"}, "MCP config copied to clipboard (validated)")
        return {"FINISHED"}


class BFACW_OT_register_claude_code(bpy.types.Operator):  # type: ignore[misc]
    """Add the bfa-coworker MCP server to Claude Code's user config."""
    bl_idname = "bfacw.register_claude_code"
    bl_label = "Add to Claude Code"
    bl_description = (
        "Write the bfa-coworker server into ~/.claude.json (user scope, all projects). "
        "Works for the Claude Code CLI and the VS Code / JetBrains extensions. "
        "The previous file is backed up as .claude.json.bfacw.bak"
    )

    def execute(self, context: bpy.types.Context) -> set[str]:
        prefs = context.preferences.addons[__package__].preferences
        _bridge_port, _, _ = effective_ports(prefs)
        try:
            path = _ac_mod.register_claude_code_mcp_server(
                blender_host=prefs.host,
                blender_port=_bridge_port,
                use_blender_python=getattr(prefs, "use_blender_python_for_harness", True),
            )
        except (OSError, ValueError) as ex:
            self.report({"ERROR"}, "Could not update Claude Code config: {:s}".format(str(ex)))
            return {"CANCELLED"}
        self.report(
            {"INFO"},
            "Added bfa-coworker to {:s} -- restart Claude Code, then check /mcp".format(str(path)),
        )
        return {"FINISHED"}


class BFACW_OT_test_mcp_config(bpy.types.Operator):  # type: ignore[misc]
    """Validate the generated MCP client config before the user pastes it."""
    bl_idname = "bfacw.test_mcp_config"
    bl_label = "Test Config"
    bl_description = (
        "Check that the generated MCP config can actually start the server: "
        "verifies the Python interpreter, PYTHONPATH entries, and imports"
    )

    _result: dict = {}  # class-level storage for display in draw()

    def execute(self, context: bpy.types.Context) -> set[str]:
        prefs = context.preferences.addons[__package__].preferences
        _bridge_port, _, _ = effective_ports(prefs)
        use_blender_py = getattr(prefs, "use_blender_python_for_harness", True)
        client_type = getattr(prefs, "harness_preset", "claude_desktop")

        def _do_check() -> None:
            BFACW_OT_test_mcp_config._result = _ac_mod.validate_mcp_client_config(
                client_type=client_type,
                blender_host=prefs.host,
                blender_port=_bridge_port,
                use_blender_python=use_blender_py,
            )

        thread = threading.Thread(target=_do_check, daemon=True)
        thread.start()
        thread.join(timeout=45)

        result = BFACW_OT_test_mcp_config._result
        if not result:
            self.report({"ERROR"}, "Config check timed out")
            return {"CANCELLED"}

        if result.get("ok"):
            self.report({"INFO"}, result.get("summary", "Config OK"))
            return {"FINISHED"}

        self.report(
            {"ERROR"},
            "{:s} -- {:s}".format(
                result.get("summary", "Config invalid"),
                result.get("hint", ""),
            ).strip(" --"),
        )
        return {"CANCELLED"}


# ---------------------------------------------------------------------------
# Open Harness Preferences (from Chat Panel)

def _open_addon_prefs_filtered(context: bpy.types.Context, pref_tab: str | None = None) -> None:
    """Open Blender preferences filtered to the Coworker addon page.

    ``bpy.ops.preferences.addon_show`` is unreliable here: it only works for
    legacy add-ons whose module is registered in ``addon_utils.addons_fake_modules``
    (extension add-ons get a ``bl_ext.`` module prefix and are skipped), and it
    fails silently when called before the preferences window has finished
    building.  Instead we set the same state that operator would set -- the
    addon search filter -- directly, deferred until the preferences area exists.
    """
    bpy.ops.screen.userpref_show('INVOKE_DEFAULT')
    context.preferences.active_section = 'ADDONS'

    # Select the addon's internal tab (e.g. ADVANCED for harness setup).
    if pref_tab is not None:
        try:
            prefs = context.preferences.addons[__package__].preferences
            prefs.pref_tab = pref_tab
        except Exception:
            pass

    # Defer the search filter until the preferences window is fully drawn --
    # calling it synchronously races the addon list population and is dropped.
    def _apply_filter() -> float | None:
        try:
            wm = bpy.context.window_manager
            # Match the addon by its display name (what the search box filters
            # against), not the module name.
            wm.addon_search = "Coworker"
            wm.addon_filter = 'All'
            bpy.context.preferences.view.show_addons_enabled_only = False
            # Expand the addon so its preferences are immediately visible.
            # Set `show_expanded` directly instead of `preferences.addon_expand`
            # (which *toggles* and would collapse it on a second click).
            import addon_utils
            # Ensure the fake-module cache is populated (same as
            # ``PREFERENCES_OT_addon_show`` does) before searching it.
            addon_utils.modules(refresh=False)
            # The addon may be registered as an extension (module name gets a
            # ``bl_ext.<repo>.`` prefix), so match by suffix.
            mod = addon_utils.addons_fake_modules.get(__package__)
            if mod is None:
                for _mod_name, _mod in addon_utils.addons_fake_modules.items():
                    if _mod_name.endswith("." + __package__):
                        mod = _mod
                        break
            if mod is not None:
                addon_utils.module_bl_info(mod)["show_expanded"] = True
            for area in bpy.context.screen.areas:
                if area.type == 'PREFERENCES':
                    area.tag_redraw()
        except Exception:
            pass
        return None

    bpy.app.timers.register(_apply_filter, first_interval=0.1)


class BFACW_OT_open_harness_prefs(bpy.types.Operator):  # type: ignore[misc]
    """Open Blender preferences to the bfa_coworker addon Advanced tab for harness setup."""
    bl_idname = "bfacw.open_harness_prefs"
    bl_label = "Configure Harness"
    bl_description = "Open preferences to configure external MCP client harness"

    def execute(self, context: bpy.types.Context) -> set[str]:
        _open_addon_prefs_filtered(context, pref_tab="ADVANCED")
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# Open Addon Preferences (filters to bfa_coworker)

class BFACW_OT_open_addon_prefs(bpy.types.Operator):  # type: ignore[misc]
    """Open Blender preferences filtered to the Coworker addon page."""
    bl_idname = "bfacw.open_addon_prefs"
    bl_label = "Open Settings"
    bl_description = "Open preferences to configure Coworker"

    def execute(self, context: bpy.types.Context) -> set[str]:
        _open_addon_prefs_filtered(context)
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# Open URL in default browser

class BFACW_OT_open_url(bpy.types.Operator):  # type: ignore[misc]
    """Open a URL in the default web browser."""
    bl_idname = "bfacw.open_url"
    bl_label = "Open URL"
    bl_description = "Open documentation link in your web browser"

    url: bpy.props.StringProperty(  # type: ignore[valid-type]
        name="URL",
        default="",
    )

    def execute(self, context: bpy.types.Context) -> set[str]:
        import webbrowser
        if self.url:
            webbrowser.open(self.url)
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# MCP Server Start (Network Mode)

class BFACW_OT_mcp_server_start(bpy.types.Operator):  # type: ignore[misc]
    """Start the MCP server in Network mode."""
    bl_idname = "bfacw.mcp_server_start"
    bl_label = "Start MCP Server"
    bl_description = "Start the MCP HTTP server for external clients"

    def execute(self, context: bpy.types.Context) -> set[str]:
        prefs = context.preferences.addons[__package__].preferences
        _bridge_port, _mcp_port, _ = effective_ports(prefs)

        mcp_host = prefs.mcp_server_host
        mcp_port = prefs.mcp_server_port_override if prefs.mcp_server_port_override > 0 else _mcp_port

        proc = _ac_mod.start_mcp_server_network(
            host=mcp_host,
            port=mcp_port,
            blender_host=prefs.host,
            blender_port=_bridge_port,
        )
        if proc is None:
            self.report({"ERROR"}, _ac_mod._agent_state.error)
            return {"CANCELLED"}

        actual = _ac_mod._agent_state.mcp_port_actual
        display_port = actual if actual else mcp_port
        self.report({"INFO"}, "MCP server started on {:s}:{:d}".format(mcp_host, display_port))
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# MCP Server Stop

class BFACW_OT_mcp_server_stop(bpy.types.Operator):  # type: ignore[misc]
    """Stop the MCP server."""
    bl_idname = "bfacw.mcp_server_stop"
    bl_label = "Stop MCP Server"
    bl_description = "Stop the MCP HTTP server"

    def execute(self, context: bpy.types.Context) -> set[str]:
        _ac_mod.stop_mcp_server()
        self.report({"INFO"}, "MCP server stopped")
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# BYOK Multi-Provider (Tier 2)

class BFACW_OT_save_provider(bpy.types.Operator):  # type: ignore[misc]
    """Save the current remote API configuration as a named provider profile."""
    bl_idname = "bfacw.save_provider"
    bl_label = "Save Provider"
    bl_description = "Save the current remote API configuration as a named profile"

    profile_name: bpy.props.StringProperty(  # type: ignore[valid-type]
        name="Profile Name",
        default="",
        description="A name for this provider profile (e.g. 'OpenAI', 'Anthropic')",
    )

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event) -> set[str]:
        del event
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=400)

    def draw(self, context: bpy.types.Context) -> None:
        del context
        layout = self.layout
        layout.prop(self, "profile_name")

    def execute(self, context: bpy.types.Context) -> set[str]:
        prefs = context.preferences.addons[__package__].preferences
        name = self.profile_name.strip()
        if not name:
            self.report({"ERROR"}, "Profile name cannot be empty")
            return {"CANCELLED"}

        profile = {
            "name": name,
            "provider": prefs.remote_provider,
            "api_url": prefs.remote_api_url,
            "api_key": prefs.remote_api_key,
            "model": prefs.remote_model,
        }

        providers = prefs._get_saved_providers()
        # Replace existing profile with same name.
        providers = [p for p in providers if p.get("name") != name]
        providers.append(profile)
        prefs._set_saved_providers(providers)

        self.report({"INFO"}, "Saved provider profile '{:s}'".format(name))
        return {"FINISHED"}


class BFACW_OT_delete_provider(bpy.types.Operator):  # type: ignore[misc]
    """Delete a saved provider profile."""
    bl_idname = "bfacw.delete_provider"
    bl_label = "Delete Provider"
    bl_description = "Delete a saved provider profile"

    profile_name: bpy.props.StringProperty(  # type: ignore[valid-type]
        name="Profile Name",
        default="",
    )

    def execute(self, context: bpy.types.Context) -> set[str]:
        prefs = context.preferences.addons[__package__].preferences
        providers = prefs._get_saved_providers()
        providers = [p for p in providers if p.get("name") != self.profile_name]
        prefs._set_saved_providers(providers)
        self.report({"INFO"}, "Deleted provider profile '{:s}'".format(self.profile_name))
        return {"FINISHED"}


class BFACW_OT_load_provider(bpy.types.Operator):  # type: ignore[misc]
    """Load a saved provider profile into the current remote API configuration."""
    bl_idname = "bfacw.load_provider"
    bl_label = "Load Provider"
    bl_description = "Load a saved provider profile"

    profile_name: bpy.props.StringProperty(  # type: ignore[valid-type]
        name="Profile Name",
        default="",
    )

    def execute(self, context: bpy.types.Context) -> set[str]:
        prefs = context.preferences.addons[__package__].preferences
        providers = prefs._get_saved_providers()
        for p in providers:
            if p.get("name") == self.profile_name:
                prefs.remote_provider = p.get("provider", "_custom")
                prefs.remote_api_url = p.get("api_url", "")
                prefs.remote_api_key = p.get("api_key", "")
                prefs.remote_model = p.get("model", "")
                self.report({"INFO"}, "Loaded provider profile '{:s}'".format(self.profile_name))
                return {"FINISHED"}
        self.report({"ERROR"}, "Profile '{:s}' not found".format(self.profile_name))
        return {"CANCELLED"}


# ---------------------------------------------------------------------------
# Poly Haven Test Operators

class BFACW_OT_test_polyhaven_hdri(bpy.types.Operator):  # type: ignore[misc]
    """Download a test HDRI from Poly Haven to verify the integration."""
    bl_idname = "bfacw.test_polyhaven_hdri"
    bl_label = "Download Test HDRI"
    bl_description = "Download a sunset HDRI from Poly Haven and set it as world environment"

    def execute(self, context: bpy.types.Context) -> set[str]:
        # Use the MCP tool via agent controller if running, else direct download.
        if get_agent_controller()._agent_state.mcp_server_running:
            self.report({"INFO"}, "Sending Poly Haven HDRI download request to Coworker...")
            _run_test_step(context, "polyhaven", 1, "HDRI",
                           "Download a sunset HDRI from Poly Haven and set it as "
                           "the world environment. Asset: belfast_sunset, type: hdris.")
            return {"FINISHED"}

        # Direct download fallback.
        self.report({"INFO"}, "Coworker not running. Starting direct download...")
        import threading
        def _do_download():
            try:
                from . import agent_controller as _ac
                result = _ac._call_mcp_tool_sync(
                    "download_polyhaven_asset",
                    {"asset_id": "sunset_meadow", "asset_type": "hdris", "resolution": "2k"},
                )
                print("[Coworker] Poly Haven test HDRI result: {:s}".format(str(result)[:200]))
            except Exception as ex:
                print("[Coworker] Poly Haven test HDRI failed: {:s}".format(str(ex)))
        thread = threading.Thread(target=_do_download, daemon=True)
        thread.start()
        return {"FINISHED"}


class BFACW_OT_test_polyhaven_texture(bpy.types.Operator):  # type: ignore[misc]
    """Download a test texture from Poly Haven to verify the integration."""
    bl_idname = "bfacw.test_polyhaven_texture"
    bl_label = "Download Test Texture"
    bl_description = "Download a brick texture from Poly Haven and apply it as a material"

    def execute(self, context: bpy.types.Context) -> set[str]:
        if get_agent_controller()._agent_state.mcp_server_running:
            self.report({"INFO"}, "Sending Poly Haven texture download request to Coworker...")
            _run_test_step(context, "polyhaven", 2, "Texture",
                           "Download a brick wall texture from Poly Haven and apply "
                           "it as a material on the active object. "
                           "Asset: brick_wall_001, type: textures.")
            return {"FINISHED"}

        self.report({"INFO"}, "Coworker not running. Starting direct download...")
        import threading
        def _do_download():
            try:
                from . import agent_controller as _ac
                result = _ac._call_mcp_tool_sync(
                    "download_polyhaven_asset",
                    {"asset_id": "brick_wall_001", "asset_type": "textures", "resolution": "2k"},
                )
                print("[Coworker] Poly Haven test texture result: {:s}".format(str(result)[:200]))
            except Exception as ex:
                print("[Coworker] Poly Haven test texture failed: {:s}".format(str(ex)))
        thread = threading.Thread(target=_do_download, daemon=True)
        thread.start()
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# Reload Skills

class BFACW_OT_reload_skills(bpy.types.Operator):  # type: ignore[misc]
    """Reload the built-in skills and system prompt cache."""
    bl_idname = "bfacw.reload_skills"
    bl_label = "Reload Skills"
    bl_description = "Reload built-in skills and clear the system prompt cache"
    bl_options = {'INTERNAL'}

    def execute(self, context: bpy.types.Context) -> set[str]:
        from . import agent_controller as _ac
        _ac._clear_system_prompt_cache()
        self.report({"INFO"}, "Skills and system prompt cache cleared")
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# Open Log

class BFACW_OT_open_log(bpy.types.Operator):  # type: ignore[misc]
    """Open the Blender console/log in the system default text editor."""
    bl_idname = "bfacw.open_log"
    bl_label = "Open Log"
    bl_description = "Open the Blender system console or log file for debugging"
    bl_options = {'INTERNAL'}

    def execute(self, context: bpy.types.Context) -> set[str]:
        import subprocess
        import sys
        import os

        # Try to find the Blender console/log location.
        log_path = None

        # On Windows, Blender console is often the terminal itself.
        if sys.platform == "win32":
            # Try opening the Blender log file if it exists.
            # Blender writes to stdout/stderr which can be redirected.
            # For now, just bring the console window to front.
            try:
                import ctypes
                kernel32 = ctypes.windll.kernel32
                kernel32.SetConsoleTitleW("BFA Coworker Log")
                # Try to get the console window handle.
                console_window = kernel32.GetConsoleWindow()
                if console_window:
                    import ctypes.wintypes
                    user32 = ctypes.windll.user32
                    user32.SetForegroundWindow(console_window)
                    self.report({"INFO"}, "Console window brought to front")
                    return {"FINISHED"}
            except Exception:  # pylint: disable=broad-exception-caught
                pass
            self.report({"INFO"}, "Check the Blender console window for logs")
            return {"FINISHED"}

        # On macOS/Linux, try to find and open the Blender log.
        # Blender console logs go to stderr/stdout.
        # Try to use 'tail -f' on the log or open system console.
        blender_app = bpy.app.binary_path
        log_dir = os.path.expanduser("~/Library/Logs/Blender") if sys.platform == "darwin" else \
                  os.path.expanduser("~/.config/blender")

        if os.path.isdir(log_dir):
            # Find the most recent log file.
            log_files = []
            for root, _dirs, files in os.walk(log_dir):
                for f in files:
                    if f.endswith(".log"):
                        log_files.append(os.path.join(root, f))
            if log_files:
                log_files.sort(key=os.path.getmtime, reverse=True)
                log_path = log_files[0]

        if log_path and os.path.isfile(log_path):
            try:
                if sys.platform == "darwin":
                    subprocess.Popen(["open", log_path])
                else:
                    subprocess.Popen(["xdg-open", log_path])
                self.report({"INFO"}, "Opened log: {:s}".format(log_path))
                return {"FINISHED"}
            except Exception:  # pylint: disable=broad-exception-caught
                pass

        self.report({"INFO"}, "Check the Blender console for log output")
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# Compare Benchmarks

class BFACW_OT_compare_benchmarks(bpy.types.Operator):  # type: ignore[misc]
    """Compare current benchmark timings with the previous run."""
    bl_idname = "bfacw.compare_benchmarks"
    bl_label = "Compare Benchmarks"
    bl_description = "Show timing delta from the previous benchmark run"
    bl_options = {'INTERNAL'}

    def execute(self, context: bpy.types.Context) -> set[str]:
        import json as _json
        import time as _time

        current = _test_suite_timings
        prev_data = _load_previous_benchmark()

        if not current:
            self.report({"INFO"}, "No current timings to compare.")
            return {"FINISHED"}

        if prev_data is None:
            self.report({"INFO"}, "No previous benchmark run found. Run a suite first.")
            return {"FINISHED"}

        prev_timings = prev_data.get("timings", {})
        prev_ts = prev_data.get("timestamp", 0)

        print("\n[Coworker] Benchmark Comparison")
        print("  Previous run: {:s}".format(
            _time.strftime("%Y-%m-%d %H:%M:%S", _time.localtime(prev_ts))))
        print("  Current run: {:s}".format(
            _time.strftime("%Y-%m-%d %H:%M:%S", _time.localtime(_time.time()))))
        print("  {:<25s} {:>8s} {:>8s} {:>8s}".format(
            "Step", "Prev", "Now", "Delta"))
        print("  " + "-" * 53)

        for (suite, step), elapsed in sorted(current.items()):
            key = "{:s}:{:d}".format(suite, step)
            prev_elapsed = prev_timings.get(key)
            if prev_elapsed is not None:
                delta = elapsed - prev_elapsed
                delta_str = "+{:.1f}s".format(delta) if delta > 0 else "{:.1f}s".format(delta)
                print("  {:<25s} {:>7.1f}s {:>7.1f}s {:>8s}".format(
                    "{:s}:{:d}".format(suite, step),
                    prev_elapsed, elapsed, delta_str))
            else:
                print("  {:<25s} {:>8s} {:>7.1f}s {:>8s}".format(
                    "{:s}:{:d}".format(suite, step),
                    "--", elapsed, "NEW"))

        self.report({"INFO"}, "Benchmark comparison printed to console.")
        return {"FINISHED"}