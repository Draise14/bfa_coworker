# SPDX-FileCopyrightText: 2026 Blender Authors
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""
Non-blocking TCP socket server that runs inside Blender.

Listens for null-byte-delimited JSON requests, executes Python code
directly in the calling thread, and returns JSON responses.
All socket operations are non-blocking so the server never blocks
Blender's main thread.
"""

__all__ = (
    "DEFAULT_HOST",
    "DEFAULT_PORT",
    "TIMER_INTERVAL_ACTIVE",
    "is_running",
    "poll",
    "poll_blocking",
    "start",
    "stop",
    "timer_idle_interval",
    "timer_idle_reset",
    "timer_internal_vars_calc",
    "use_log",
    "log_level",
    "get_actual_port",
)

import json
import math
import random
import re
import select
import socket
import sys
import threading
import time
import traceback
from collections.abc import Callable
from typing import NamedTuple

DEFAULT_HOST = "localhost"
DEFAULT_PORT = 9876

# Seconds between main-thread timer ticks.
TIMER_INTERVAL_ACTIVE = 0.05
# Seconds between main-thread timer ticks while idle (no pending work).
_TIMER_INTERVAL_IDLE = 1.0
# Seconds of inactivity before switching to the idle interval.
_TIMER_INTERVAL_IDLE_DELAY = 5.0


class _TimerState:
    """
    Mutable singleton holding timer-related runtime state.

    This is manipulated from the preferences and updated via ``timer_internal_vars_calc``.
    """

    __slots__ = (
        "interval_active",
        "interval_idle",
        "interval_idle_delay",
        "idle_countdown_reset",
        "idle_countdown",
        "client_timeout_countdown",
    )

    def __init__(self) -> None:
        self.interval_active: float = TIMER_INTERVAL_ACTIVE
        self.interval_idle: float = _TIMER_INTERVAL_IDLE
        self.interval_idle_delay: float = _TIMER_INTERVAL_IDLE_DELAY
        # Number of active-rate ticks before switching to idle.
        self.idle_countdown_reset: int = 0
        # Current countdown. When zero, `timer_idle_interval` returns idle.
        self.idle_countdown: int = 0
        # Poll ticks before an idle client is evicted.
        self.client_timeout_countdown: int = 2


_timer = _TimerState()


# Actual port the bridge server bound to (may differ from DEFAULT_PORT
# if auto-shuffle kicked in).  0 = not started yet.
_actual_port: int = 0


def get_actual_port() -> int:
    """Return the port the bridge server is actually listening on, or 0."""
    return _actual_port


def _find_available_port(preferred: int, max_offset: int = 100) -> int:
    """Return the first available port starting at *preferred*.

    Tries ``preferred``, ``preferred + 1``, ... up to ``preferred + max_offset``.
    Returns the first port that can be bound, or 0 if none are available.
    """
    for offset in range(max_offset + 1):
        candidate = preferred + offset
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            if sys.platform == "win32":
                s.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            s.bind(("127.0.0.1", candidate))
            s.close()
            if offset > 0:
                print("[Coworker] _find_available_port: port {:d} in use, shuffled to {:d}".format(
                    preferred, candidate))
            return candidate
        except (OSError, socket.error):
            s.close()
            continue
    print("[Coworker] _find_available_port: no port available in range {:d}-{:d}".format(
        preferred, preferred + max_offset))
    return 0


def timer_internal_vars_calc(
        active: float | None = None,
        idle: float | None = None,
        idle_delay: float | None = None,
) -> None:
    """
    Optionally update ``TIMER_*`` constants and recalculate internal variables.

    When keyword arguments are provided they replace the corresponding
    module-level ``TIMER_*`` value. Pass ``None`` (the default) to leave
    a value unchanged.
    """
    if active is not None:
        _timer.interval_active = active
    if idle is not None:
        _timer.interval_idle = idle
    if idle_delay is not None:
        _timer.interval_idle_delay = idle_delay
    # Round up so the delay is never shorter than requested.
    _timer.idle_countdown_reset = math.ceil(_timer.interval_idle_delay / _timer.interval_active)
    _timer.idle_countdown = _timer.idle_countdown_reset
    _timer.client_timeout_countdown = max(2, math.ceil(_CLIENT_TIMEOUT / _timer.interval_active))


def timer_idle_reset() -> None:
    """
    Signal that work was processed, resetting the idle countdown.
    """
    _timer.idle_countdown = _timer.idle_countdown_reset


def timer_idle_interval() -> float:
    """
    Return the appropriate timer interval, decrementing the idle countdown.

    Returns ``TIMER_INTERVAL_ACTIVE`` while the countdown is positive,
    then ``_TIMER_INTERVAL_IDLE`` once it reaches zero.
    """
    if _timer.idle_countdown > 0:
        _timer.idle_countdown -= 1
        return _timer.interval_active
    return _timer.interval_idle


# When True, print every request and response status to STDERR.
use_log: bool = False
# Granular log level: "OFF", "ERRORS_ONLY", or "ALL".
log_level: str = "OFF"

_MAX_REQUEST_BYTES = 10 * 1024 * 1024  # 10 MiB.
# Maximum number of queued incoming connections.
_LISTEN_BACKLOG = 5
_RECV_BUFFER_SIZE = 4096
# Seconds before a client that has not sent a complete request is closed.
_CLIENT_TIMEOUT = 10.0
# How often `poll_blocking` checks for shutdown.
_POLL_BLOCKING_TIMEOUT = 1.0
_DEFERRED_UNSUPPORTED_MESSAGE = (
    "Deferred responses via `check_is_finished` are only supported "
    "by the interactive addon server, and are not available in "
    "background mode. Finish the request synchronously instead."
)

timer_internal_vars_calc()


def _should_log_request() -> bool:
    """Return True when the current log settings want request logging."""
    return use_log or log_level == "ALL"


def _should_log_response(is_error: bool = False) -> bool:
    """Return True when the current log settings want response logging.

    If ``is_error`` is True, both ``ALL`` and ``ERRORS_ONLY`` log levels
    will produce output.
    """
    if use_log or log_level == "ALL":
        return True
    if is_error and log_level == "ERRORS_ONLY":
        return True
    return False


# ---------------------------------------------------------------------------
# Client connection state.

class _Client:
    """
    Per-connection state for a client (the MCP server process) that has not yet sent a complete request.
    """

    __slots__ = (
        "conn",
        "buffer",
        "timeout",
    )

    def __init__(self, conn: socket.socket) -> None:
        self.conn: socket.socket = conn
        # Accumulates data until the null-byte delimiter is received.
        self.buffer: bytearray = bytearray()
        # Poll ticks remaining before this client is evicted.
        self.timeout: int = _timer.client_timeout_countdown


# ---------------------------------------------------------------------------
# Server state.

class _State:
    """
    Mutable singleton holding the runtime state of this socket server (the Blender add-on side).
    """

    __slots__ = (
        "sock",
        "clients",
    )

    def __init__(self) -> None:
        # The listening socket, or `None` when not running.
        self.sock: socket.socket | None = None
        # Connected clients that have not yet sent a complete request.
        self.clients: list[_Client] = []


_state = _State()


class _ExecResult(NamedTuple):
    """
    Result of executing tool-code.

    When *check_fn* is not ``None``, the caller must defer the response
    and poll the callable for completion (see ``deferred_tool``).
    Otherwise *response* is the final result to send.
    """

    response: dict[str, object]
    check_fn: Callable[[], dict[str, object] | None] | None = None


def _encode_response(response: dict[str, object]) -> bytes:
    """
    Serialize a response dict as null-byte-delimited JSON bytes.
    """
    return (json.dumps(response) + "\0").encode("utf-8")


def _safe_depsgraph_sync(allow_full_sync: bool = True) -> None:
    """
    Synchronize the depsgraph using the safest available strategy.

    Blender 5.3 can crash (EXCEPTION_ACCESS_VIOLATION in
    ``deg_eval_copy_is_expanded``) when ``view_layer.update()`` is called
    after collection-manipulation operations (creating collections, moving
    objects between them, setting color tags).  This helper tries multiple
    strategies in order of safety:

    1. Tag each object for update (lightweight, no full rebuild).
    2. Fall back to ``view_layer.update()`` only if tagging is unavailable
       and *allow_full_sync* is ``True``.

    :param allow_full_sync: When ``False``, only the lightweight
        ``update_tag()`` strategy is attempted.  Use this after code that
        manipulates collections, where a full depsgraph rebuild is known
        to crash in Blender 5.3.
    """
    try:
        import bpy as _bpy  # pylint: disable=import-error
    except ImportError:
        return  # Not running inside Blender.

    # -- Strategy 1: Tag each object for update ----------------------
    # This is the safest approach -- it marks objects as needing a
    # re-evaluation without triggering a full depsgraph rebuild.
    # The rebuild is what crashes in Blender 5.3 after collection ops.
    try:
        for _obj in _bpy.data.objects:
            try:
                _obj.update_tag()
            except (ReferenceError, AttributeError):
                pass  # Object may have been deleted mid-iteration.
        # print("[Coworker] _safe_depsgraph_sync: used update_tag strategy")
        return
    except Exception:  # pylint: disable=broad-exception-caught
        if not allow_full_sync:
            return  # Don't fall through to view_layer.update().
        pass  # Fall through to strategy 2.

    # -- Strategy 2: Full view_layer.update() ------------------------
    # This is the traditional approach.  It can crash in Blender 5.3
    # after collection manipulation, but is the only option when
    # update_tag() is not available (e.g. very old Blender versions).
    try:
        _bpy.context.view_layer.update()
        # print("[Coworker] _safe_depsgraph_sync: used view_layer.update strategy")
    except Exception:  # pylint: disable=broad-exception-caught
        pass  # Best-effort; view_layer may not be available.


def _code_touches_collections(code: str) -> bool:
    """Heuristic check: does *code* manipulate collections?

    Returns ``True`` if the code contains patterns that are known to
    trigger depsgraph crashes in Blender 5.3 after a full
    ``view_layer.update()``.

    Covers both direct collection API calls (``collections.new``,
    ``.link()``, ``.unlink()``) and attribute assignments on
    layer-collection objects (``layer_col.exclude``,
    ``layer_col.hide_viewport``) which are generated by the
    ``jump_to_view3d_*`` tool templates.
    """
    _COLLECTION_PATTERNS = (
        "collections.new",
        ".unlink(",
        ".link(",
        "color_tag",
        "children.link",
        "objects.unlink",
        "layer_col.exclude",
        "layer_col.hide_viewport",
    )
    return any(p in code for p in _COLLECTION_PATTERNS)


def _code_is_undo_or_push(code: str) -> bool:
    """Heuristic check: is *code* an undo/push operation?

    Undo/push operations trigger depsgraph notifiers.  If we've tagged
    objects with ``update_tag()`` before the undo, the event loop will
    try to evaluate those now-stale tagged objects and crash.
    """
    return "bpy.ops.ed.undo()" in code or "bpy.ops.ed.undo_push(" in code



# ---------------------------------------------------------------------------
# Preflight code validation -- catches common LLM mistakes before exec().
# Returns a list of (pattern_name, guidance) tuples.  Empty = no issues.
# ---------------------------------------------------------------------------

def _imports_module(code: str, module: str) -> bool:
    """Return True when *code* imports *module*.

    Handles the forms an LLM actually writes:

    * ``import bmesh``
    * ``import bpy, bmesh, math``   (comma-separated)
    * ``import bmesh as bm``
    * ``from bmesh import ops``

    A plain ``"import bmesh" in code`` substring test misses the
    comma-separated form, which made the bmesh preflight check fire on
    valid code and cost the model a wasted retry.
    """
    escaped = re.escape(module)
    # ``import a, b, c`` / ``import a as x`` -- module must be a whole name
    # in the comma-separated list, not a prefix of another module.
    if re.search(r"^\s*import\s+[^\n]*\b{:s}\b".format(escaped), code, re.MULTILINE):
        return True
    # ``from bmesh import ...``
    if re.search(r"^\s*from\s+{:s}\b".format(escaped), code, re.MULTILINE):
        return True
    return False


# --- Main-thread execution guard -------------------------------------------
# Blender's Python context counter (``py_call_level`` in bpy_interface.cc) is a
# single global, and ``bpy_context_set`` / ``bpy_context_clear`` only balance on
# the main thread.  Entering Blender's C API from a worker thread races that
# counter and spams
#
#     ERROR: Python context internal state bug. this should not happen!
#
# to the console, while also exposing an empty context (``bpy.context.window``
# is None there).  So any code that references these C-backed modules must run
# inline on the calling (main) thread.
_BPY_MODULE_REF_RE = re.compile(
    r"\b(?:bpy|bmesh|mathutils|gpu|blf|aud|bpy_extras)\b")


def _code_uses_bpy(code: str) -> bool:
    """Return True when *code* references Blender's C-backed modules.

    Such code must be executed on the main thread (see the module note above).
    False positives are harmless -- they only skip the worker-thread hang
    timeout and run inline instead.
    """
    return bool(_BPY_MODULE_REF_RE.search(code))


# Preflight checks that are style advice or heuristics: the code may well be
# correct, so it runs and the guidance is attached to the result as
# ``preflight_notes`` instead of refusing it (issue #101).  Every other check
# flags code that is certain to fail (removed API, missing import, crash).
_ADVISORY_PREFLIGHT = frozenset((
    "no_existence_check",
    "unguarded_list_index",
    "ops_in_loop",
    "no_output",
    "op_requires_selection",
    "op_requires_active_object",
    "wrong_material_access",
    "wrong_mode_set",
    "bmesh_editmode_mismatch",
    "vector_arithmetic",
))


def _preflight_check(code: str) -> list[tuple[str, str]]:
    """Validate *code* for common LLM-generated mistakes before execution.

    Returns a list of ``(pattern_name, guidance)`` tuples.  An empty list
    means the code passed all checks.  Each check is a lightweight regex --
    total cost is <1ms.
    """
    issues: list[tuple[str, str]] = []

    # 1. Missing bpy import -- most common first-time failure.
    uses_bpy = re.search(r"\bbpy\.", code) or "bpy.ops." in code
    has_import = _imports_module(code, "bpy")
    if uses_bpy and not has_import:
        issues.append((
            "missing_bpy",
            "Missing 'import bpy'. Add 'import bpy' at the top of your code.",
        ))

    # 2. Wrong subdivision modifier attribute.
    if re.search(r"\.subdivisions\s*=", code) and "SUBSURF" in code.upper():
        issues.append((
            "wrong_subdiv_attr",
            "Blender 5.3: mod.subdivisions was renamed. Use mod.levels instead.",
        ))

    # 3. Wrong Principled BSDF attribute access.
    if re.search(r"\.(base_color|base_color_input)\s*=", code):
        issues.append((
            "wrong_principled_attr",
            "Principled BSDF has no base_color attribute. "
            "Use principled.inputs['Base Color'].default_value = (R, G, B, 1.0)",
        ))

    # 4. Wrong torus primitive keywords.
    if "primitive_torus_add" in code and re.search(r"ring_count\s*=", code):
        issues.append((
            "wrong_torus_kw",
            "primitive_torus_add has no ring_count parameter. "
            "Use major_radius, minor_radius, major_segments, minor_segments.",
        ))

    # 5. Wrong sequencer API (sequences vs strips).
    if re.search(r"\.sequences\b", code) and "sequence_editor" in code:
        issues.append((
            "wrong_sequencer_api",
            "Blender 5.x: editor.sequences was renamed to editor.strips.",
        ))

    # 6. Wrong auto smooth API.
    if "use_auto_smooth" in code:
        issues.append((
            "wrong_auto_smooth",
            "mesh.use_auto_smooth and mesh.auto_smooth_angle were removed in "
            "Blender 4.1. Smooth by angle with the operator instead: select the "
            "object, then bpy.ops.object.shade_auto_smooth(angle=math.radians(30)).",
        ))

    # 7. Accessing action.fcurves (removed in Blender 5.0+).
    # `action.fcurves`, `ad.action.fcurves`, `bpy.data.actions[0].fcurves` --
    # but not `channelbag.fcurves`, the 5.x way to read them.
    if re.search(r"(?:\baction|\bactions\[[^\]]*\])\.fcurves", code):
        issues.append((
            "wrong_fcurves",
            "action.fcurves was removed in Blender 5.0 (layered actions). "
            "Create keys with obj.keyframe_insert(data_path, frame=...). Read "
            "F-Curves through the action slot: `from bpy_extras import "
            "anim_utils; ad = obj.animation_data; cb = "
            "anim_utils.action_get_channelbag_for_slot(ad.action, ad.action_slot); "
            "for fc in cb.fcurves: ...` (cb is None when the slot has no keys).",
        ))

    # 7a. GN modifier socket membership (removed in Blender 5.2+).
    #   ``identifier in modifier`` and ``modifier["..."]`` no longer work;
    #   sockets live on ``modifier.properties.inputs``.  Only flag when a
    #   modifier-like name is on the right side, so a plain ``x in some_list``
    #   is not caught.
    if re.search(r"\bin\s+(?:mod|modifier)\b", code):
        issues.append((
            "gn_socket_membership",
            "Geometry-Nodes modifier socket membership (`identifier in modifier`) "
            "was removed in Blender 5.2+. Access sockets via "
            "`getattr(modifier.properties.inputs, 'Socket_3')` (and draw "
            "`.value` on the returned socket), not with `in` or `modifier[...]`.",
        ))

    # 7b. Manual layered-animation channelbag construction (crashes).
    if re.search(r"\.channelbag\(|action\.slots\.new|action\.layers\b", code):
        issues.append((
            "manual_channelbag",
            "Do not build layered-animation channelbags/slots manually "
            "(action.layers / action.slots.new / .channelbag(...)) -- this "
            "crashes Blender. Use obj.keyframe_insert() to create keys; read "
            "existing F-Curves only via the read-only helper in the blender_53 "
            "skill guidance.",
        ))

    # 8. Using bpy.ops in a loop without context override.
    ops_in_loop = re.search(
        r"(for|while)\s+.+:\s*\n\s+bpy\.ops\.", code
    )
    if ops_in_loop:
        issues.append((
            "ops_in_loop",
            "Calling bpy.ops inside a loop is slow and may lose context. "
            "Batch operations with bpy.data or bpy.context instead.",
        ))

    # 9. No output -- code runs but returns nothing visible.
    has_result = "result" in code and ("=" in code or "{" in code)
    has_print = "print(" in code
    if not has_result and not has_print and len(code.strip()) > 50:
        issues.append((
            "no_output",
            "Your code has no print() or result assignment. "
            "Add print() to see output, or assign to a 'result' dict.",
        ))


    # 10. Wrong lamp/light API (lamps -> lights since Blender 4.0).
    if re.search(r"bpy\.data\.lamps", code):
        issues.append((
            "wrong_lamps_api",
            "bpy.data.lamps was renamed to bpy.data.lights in Blender 4.0.",
        ))

    # 11. Wrong render engine name (EEVEE -> BLENDER_EEVEE since Blender 4.0).
    if re.search(r'["\']EEVEE["\']', code) and "render.engine" in code:
        issues.append((
            "wrong_eevee_name",
            "render.engine = 'EEVEE' was renamed to 'BLENDER_EEVEE' in Blender 4.0.",
        ))

    # 12. Accessing scene.render.eevee (moved in Blender 4.0).
    if re.search(r"render\.eevee\.", code):
        issues.append((
            "wrong_eevee_access",
            "scene.render.eevee was removed. EEVEE settings are now on "
            "scene.eevee (e.g. scene.eevee.use_ssr).",
        ))


    # 13. Wrong Principled BSDF input name (common wrong guesses).
    _WRONG_BSDF_INPUTS = {
        "Subsurface Color", "Subsurface", "Specular", "Clearcoat",
        "Sheen", "Transmission", "Emission Strength",
    }
    for wrong_name in _WRONG_BSDF_INPUTS:
        if "['" + wrong_name + "']" in code:
            issues.append((
                "wrong_bsdf_input",
                "Principled BSDF has no input '" + wrong_name + "'. "
                "Use print([i.name for i in principled.inputs]) to list available inputs.",
            ))
            break  # One hint is enough.

    # 14. bpy.data.*.active doesn't exist -- use context.active_object.
    if re.search(r"\.(lights|cameras|meshes|materials|textures)\.active", code):
        issues.append((
            "wrong_collection_active",
            "bpy.data.* collections have no .active attribute. "
            "Use bpy.context.view_layer.objects.active or bpy.context.selected_objects instead.",
        ))

    # 15. Creating objects in a loop without checking what exists first.
    #     Loops over primitive_* operators are fine -- Blender
    #     auto-uniquifies names (Torus, Torus.001, ...), and one-shot
    #     scene building in a loop is legitimate. The real duplicate
    #     hazard is data-level creation (bpy.data.objects.new) with the
    #     SAME literal name on every iteration: repeated runs silently
    #     accumulate objects. Only flag that case, and only when the loop
    #     neither guards with get() nor derives a unique name per
    #     iteration.
    creates_in_loop = ("for " in code or "while " in code) and "objects.new(" in code
    if creates_in_loop and "bpy.data.objects.get" not in code \
            and 'name=f"' not in code and "name=f'" not in code and "name = f\"" not in code and "name = f'" not in code:
        issues.append((
            "no_existence_check",
            "Creating objects in a loop with bpy.data.objects.new(...) "
            "without checking what exists. Give each iteration a unique "
            "name (name=f'item_{i}') or guard with "
            "bpy.data.objects.get('Name') first, so repeated runs don't "
            "silently accumulate duplicates.",
        ))


    # 16. Wrong mode_set enum (POSE mode needs armature context).
    if "mode_set(" in code and "POSE" in code:
        issues.append((
            "wrong_mode_set",
            "POSE mode via mode_set() requires an armature to be active and "
            "selected. Use bpy.ops.object.mode_set(mode='POSE') only after "
            "selecting an armature. Or use bpy.context.object.mode = 'POSE'.",
        ))

    # 17. Hallucinated module imports.
    _HALLUCINATED_MODULES = ["mcp_toolkit", "blender_mcp", "bpy_tools", "ai_tools"]
    for mod_name in _HALLUCINATED_MODULES:
        if ("import " + mod_name) in code or ("from " + mod_name) in code:
            issues.append((
                "hallucinated_module",
                "Module '" + mod_name + "' does not exist. This is an LLM hallucination. "
                "Use standard bpy/bpy.ops/bpy.data instead.",
            ))
            break

    # 18. Wrong mode_set enum values (valid: OBJECT, EDIT, SCULPT, etc).
    _VALID_MODES = {"OBJECT", "EDIT", "SCULPT", "VERTEX_PAINT", "WEIGHT_PAINT",
                    "TEXTURE_PAINT", "POSE", "PARTICLE_EDIT"}
    mode_match = re.search(r"mode_set\(.*mode.*=.([A-Z_]+)", code)
    if mode_match:
        mode_val = mode_match.group(1)
        if mode_val not in _VALID_MODES:
            issues.append((
                "wrong_mode_enum",
                "mode_set(mode='" + mode_val + "') is not a valid mode. "
                "Valid modes: " + ", ".join(sorted(_VALID_MODES)) + ".",
            ))


    # 19. Wrong material object hierarchy.
    #     mesh.material_slots -> obj.material_slots (Object, not Mesh)
    #     obj.materials -> obj.data.materials (Mesh data, not Object)
    #     material_slot.material -> slot.material (correct)
    if re.search(r"\.data\.material_slots", code):
        issues.append((
            "wrong_material_hierarchy",
            "mesh.data.material_slots does not exist. "
            "Use obj.material_slots (on Object) instead of obj.data.material_slots.",
        ))
    if re.search(r"\.materials\b", code) and "obj.data.materials" not in code and "mesh.materials" not in code:
        # Check if it's on an Object (wrong) vs Mesh data (correct)
        if re.search(r"\w+\.materials\[", code) and "data.materials" not in code:
            issues.append((
                "wrong_material_access",
                "obj.materials does not exist on Object. "
                "Use obj.data.materials (on Mesh data) or obj.material_slots instead.",
            ))


    # 20. Wrong world/environment node type names.
    _WRONG_NODE_TYPES = {
        "ShaderNodeEnvironment": "ShaderNodeTexEnvironment",
        "ShaderNodeWorldOutput": "ShaderNodeOutputWorld",
        "ShaderNodeBackground": "ShaderNodeBackground",
    }
    for wrong, correct in _WRONG_NODE_TYPES.items():
        if wrong in code and correct not in code:
            issues.append((
                "wrong_node_type",
                "Node type '" + wrong + "' does not exist. "
                "Use '" + correct + "' instead.",
            ))
            break


    # 21. Calling MCP tool as a Python function inside execute_blender_code.
    _MCP_TOOLS = ["setup_pbr_material", "search_polyhaven_assets",
                  "download_polyhaven_asset", "get_python_api_docs",
                  "search_api_docs", "search_manual_docs"]
    for tool_name in _MCP_TOOLS:
        if tool_name + "(" in code and "def " + tool_name not in code:
            issues.append((
                "mcp_tool_as_function",
                "'" + tool_name + "' is an MCP tool, not a Python function. "
                "Call it as a separate tool call, not inside execute_blender_code. "
                "Use bpy API directly instead.",
            ))
            break

    # 22. Wrong world property access (world["Use Nodes"] -> world.use_nodes).
    if re.search(r'\["Use Nodes"\]', code) or re.search(r"\['Use Nodes'\]", code):
        issues.append((
            "wrong_world_property",
            'world["Use Nodes"] does not exist. '
            "Use world.use_nodes = True instead (it's a boolean attribute).",
        ))

    # 23. Passing INVALID transform kwargs to primitive add operators.
    #     location=/rotation=/scale= ARE accepted in 5.3 (verified against
    #     the dev build) -- only rotation_euler/rotation_mode are invalid.
    _PRIM_OPS = ["primitive_cube_add", "primitive_uv_sphere_add",
                 "primitive_ico_sphere_add", "primitive_cylinder_add",
                 "primitive_cone_add", "primitive_torus_add",
                 "primitive_plane_add", "primitive_circle_add",
                 "primitive_monkey_add", "primitive_grid_add"]
    _TRANSFORM_KWARGS = ["rotation_euler", "rotation_mode"]
    for prim in _PRIM_OPS:
        if prim + "(" in code:
            for kwarg in _TRANSFORM_KWARGS:
                if kwarg + "=" in code:
                    issues.append((
                        "prim_transform_kwarg",
                        prim + "() does not accept '" + kwarg + "' as a keyword. "
                        "Use rotation=(...) instead, or set it after creation: "
                        "obj.rotation_euler = (...)",
                    ))
                    break
            break  # One hint per call is enough.

    # 24. Missing bmesh import -- code uses bmesh without importing it.
    # Match the import properly: a plain substring test for 'import bmesh'
    # misses the common comma-separated form (``import bpy, bmesh, math``),
    # which made this fire on perfectly valid code and cost the model a
    # wasted retry rewriting working code.
    if re.search(r'\bbmesh\.', code) and not _imports_module(code, "bmesh"):
        issues.append((
            "missing_bmesh_import",
            "Code uses bmesh but does not 'import bmesh'. "
            "Add 'import bmesh' at the top of your script.",
        ))

    # 25. bmesh edit mode mismatch -- using from_edit_mesh without entering edit mode,
    #     or using from_mesh (object mode) when edit mode was intended.
    if 'bmesh.from_edit_mesh' in code and 'mode_set' not in code and 'EDIT' not in code:
        issues.append((
            "bmesh_editmode_mismatch",
            "bmesh.from_edit_mesh() requires the object to be in EDIT mode. "
            "Switch to edit mode first: bpy.ops.object.mode_set(mode='EDIT')",
        ))

    # 26. Vector arithmetic type errors -- adding float/tuple to Vector.
    #     Common pattern: vert.co += offset + random.uniform(-0.1, 0.1)
    #     Fix: use mathutils.Vector for offsets, or add component-wise.
    if re.search(r'vert\.co\s*\+=.*\+\s*[a-z]', code):
        issues.append((
            "vector_arithmetic",
            "Can't add a scalar to a Vector. "
            "Use: vert.co += mathutils.Vector((dx, dy, dz)) "
            "or set components: vert.co.x += dx",
        ))

    # 27. update_edit_mesh with wrong number of args.
    #     In Blender 5.x, update_edit_mesh() takes 0 or 1 args.
    if re.search(r'update_edit_mesh\([^)]+,\s*[^)]+\)', code):
        issues.append((
            "update_edit_mesh_args",
            "bmesh.update_edit_mesh() takes at most 1 argument in Blender 5.x. "
            "Use: bm.update_edit_mesh(mesh) -- no extra args.",
        ))

    # 28. Operator context preconditions (scene safety Phase 2).
    #     bpy.ops.object.join takes NO arguments and acts on the current
    #     selection + active object, so it is the most fragile operator:
    #     if the user re-targeted the scene between tool calls it raises
    #     "poll() failed, context is incorrect".  Require an explicit
    #     selection before it.
    if re.search(r"bpy\.ops\.object\.(join|join_shapes)\s*\(", code):
        if not re.search(r"select_set\(|select_all\(", code):
            issues.append((
                "op_requires_selection",
                "bpy.ops.object.join() needs >= 2 selected objects AND one "
                "active object, but no selection call precedes it. Select "
                "explicitly first: for o in objs: o.select_set(True); then "
                "bpy.context.view_layer.objects.active = objs[0].",
            ))

    # 29. Operators that act on the active object need it set first.
    _NEED_ACTIVE = ("modifier_apply", "modifier_remove", "shade_smooth",
                    "shade_flat", "convert", "origin_set", "make_single_user")
    for _op in _NEED_ACTIVE:
        if "bpy.ops.object." + _op + "(" in code:
            # Require an ACTUAL active-object assignment; merely fetching an
            # object with .get() elsewhere must not suppress the check.
            if ("view_layer.objects.active" not in code
                    and not re.search(r"\.active\s*=", code)):
                issues.append((
                    "op_requires_active_object",
                    "bpy.ops.object.{:s}() acts on the active object, but no "
                    "active object is set in this script. Set it first: "
                    "bpy.context.view_layer.objects.active = obj "
                    "(and obj.select_set(True)).".format(_op),
                ))
                break  # One hint per block.

    # 30. Unguarded literal index into a Blender collection (scene safety
    #     Phase 3).  selected_objects / bpy.data.<coll> may be empty, and the
    #     selection can change between tool calls, so `selected_objects[0]`
    #     raises IndexError.  Anchored on known collection roots only, and
    #     suppressed when the block already guards with len()/get()/iter()/if.
    _COLL_INDEX_ROOTS = (
        r"bpy\.context\.selected_objects",
        r"bpy\.data\.objects",
        r"bpy\.data\.materials",
        r"bpy\.data\.meshes",
        r"bpy\.data\.collections",
        r"\bscene\.objects",
        r"bpy\.context\.view_layer\.objects",
    )
    for _root in _COLL_INDEX_ROOTS:
        if re.search(_root + r"\[\s*\d+\s*\]", code):
            # Suppress ONLY when a guard actually covers THIS root: a len() or
            # next(iter()) on it, a .get() on it, or an `if` that mentions it.
            # A bare `if` / `.get()` elsewhere in the script must not defeat
            # the check (that hid the exact `selected_objects[0]` IndexError
            # class this check targets).
            _guarded = (
                re.search(r"len\(\s*" + _root, code)
                or re.search(_root + r"\s*\.get\(", code)
                or re.search(r"next\(iter\(\s*" + _root, code)
                or re.search(r"if\b[^\n]*" + _root, code)
            )
            if not _guarded:
                issues.append((
                    "unguarded_list_index",
                    "Indexing a Blender collection with a literal index can "
                    "raise IndexError when it is empty, and the selection may "
                    "have changed since your last call. Guard with len() or "
                    "next(iter(...), None), and re-fetch references by name.",
                ))
                break  # One hint per block.

    return issues

def _execute_code(
        code: str,
        strict_json: bool,
) -> _ExecResult:
    """
    Execute *code* and return an ``_ExecResult``.

    :param strict_json: When true, the response *must* be serializable.
        Should always be true, when executing Python code we have full-control over,
        because any non-serializable data is effectively a bug.

        Only allow it to be false when executing arbitrary LLM generated code,
        in this case it's not worth the overhead of correcting the LLM mistake,
        just ``__repr__`` the value so it can fumble its way forward.
    """
    from .capture_output import CaptureOutput
    from .weak_sandbox import WeakSandboxForLLM

    # Pre-populate common modules so LLM-generated code doesn't need to
    # import them explicitly -- reduces a common failure mode.
    namespace: dict[str, object] = {
        "result": {},
        "math": math,
        "random": random,
        "time": time,
        "json": json,
        "re": re,
    }
    # Advisory preflight guidance, attached to whatever the code returns.
    preflight_notes: list[str] = []
    with CaptureOutput() as captured, WeakSandboxForLLM():
        try:
            # NOTE: We intentionally do NOT sync the depsgraph before
            # executing LLM code.  Tagging all objects with update_tag()
            # schedules a massive depsgraph evaluation.  If the smart-undo
            # system then fires bpy.ops.ed.undo() (reverting the scene),
            # the event loop tries to evaluate those now-stale tagged
            # objects and crashes with EXCEPTION_ACCESS_VIOLATION in
            # pyrna_struct_CreatePyObject.
            #
            # A Python-level exception from stale layer-collection data
            # is always preferable to an unrecoverable C-level segfault.

            # Auto-fix common LLM mistakes (lamps -> lights, EEVEE ->
            # BLENDER_EEVEE, subdivisions -> levels, ...) BEFORE preflight so
            # corrected code passes validation instead of being rejected.
            # Repository-controlled toolcode is skipped: it is already correct.
            if "# blmcp-toolcode-skip-preflight" not in code:
                from .autofix import _autofix_code
                code, _fixes = _autofix_code(code)
                if _fixes:
                    print("[Coworker] autofix applied: {:s}".format(", ".join(_fixes)))

            # Preflight: validate code before execution. Toolcode-generated
            # payloads (marked by the MCP tools) are repository-controlled and
            # legitimately contain literal patterns the LLM-oriented checks
            # would flag (e.g. `action.fcurves`, `primitive_cube_add` in
            # comments and Params reprs), so they skip the validator.
            if "# blmcp-toolcode-skip-preflight" in code:
                preflight_issues = []
            else:
                preflight_issues = _preflight_check(code)
            preflight_notes[:] = [g for n, g in preflight_issues if n in _ADVISORY_PREFLIGHT]
            preflight_blocking = [(n, g) for n, g in preflight_issues if n not in _ADVISORY_PREFLIGHT]
            if preflight_blocking:
                hint_lines = ["[Preflight] Found {:d} issue(s):".format(len(preflight_blocking))]
                for _name, guidance in preflight_blocking:
                    hint_lines.append("  - {:s}".format(guidance))
                hint_lines.append("")
                hint_lines.append("Fix these issues and retry. Do NOT retry the same code.")
                return _ExecResult({"status": "error", "message": "\n".join(hint_lines)})

            # Toolcode-generated payloads carry this marker: they are
            # repository-controlled and trusted. Execute them inline in
            # the calling thread so that bpy.context (window / screen /
            # active object) is populated. In interactive mode the socket
            # is serviced from bpy.app.timers on the main thread; in
            # background/CLI mode the request loop also runs on the main
            # thread. A worker thread would expose an empty context
            # (bpy.context.window is None, bpy.context.active_object
            # raises AttributeError), which made every window-dependent
            # tool (tab switching, viewport jumps, screenshots, asset
            # browser) fail with "No active window" through the harness.
            is_toolcode = "# blmcp-toolcode-skip-preflight" in code
            _exec_error = [None]
            # LLM code that touches Blender must run on the calling (main)
            # thread.  A worker thread races Blender's global Python context
            # counter -- spamming "ERROR: Python context internal state bug.
            # this should not happen!" -- and exposes an empty context.  Pure
            # Python (no bpy) still uses a worker thread so an accidental
            # infinite loop is caught by the timeout.
            if is_toolcode or _code_uses_bpy(code):
                # Trusted toolcode and any bpy-touching code run inline so
                # bpy.context (window / screen / active object) is populated
                # and Blender's context counter stays balanced.
                try:
                    exec(code, namespace)
                except Exception as _e:
                    _exec_error[0] = _e
            else:
                # Run pure-Python exec() in a thread with a timeout to prevent
                # hangs.  Safe because it never enters Blender's C API.
                def _run_code():
                    try:
                        exec(code, namespace)
                    except Exception as _e:
                        _exec_error[0] = _e
                _exec_thread = threading.Thread(target=_run_code, daemon=True)
                _exec_thread.start()
                _exec_thread.join(timeout=30)
                if _exec_thread.is_alive():
                    return _ExecResult({
                        "status": "error",
                        "message": "[Preflight] Code execution timed out after 30 seconds. "
                        "This usually means an infinite loop or a blocking operator call.",
                    })
            if _exec_error[0] is not None:
                raise _exec_error[0]

            # Force a depsgraph update after successful code execution.
            # Without this, creating many objects in a single call can leave
            # the depsgraph in an inconsistent state, causing a hard crash
            # (EXCEPTION_ACCESS_VIOLATION in layer_collection_sync) on the
            # next viewport redraw timer tick.
            # If the code manipulates collections or is an undo/push op,
            # skip the full sync to avoid Blender 5.3 depsgraph crashes.
            _safe_depsgraph_sync(
                allow_full_sync=(
                    not _code_touches_collections(code)
                    and not _code_is_undo_or_push(code)
                )
            )
            # NOTE: Deferred layer-collection sync via timers was removed.
            # Calling view_layer.update() from a timer triggers a full
            # depsgraph rebuild in a deferred context, which crashes in
            # Blender 5.3 with EXCEPTION_ACCESS_VIOLATION in build_materials
            # when materials are in an inconsistent state (e.g. rapid object
            # creation with scatter operations).  The update_tag() strategy
            # in _safe_depsgraph_sync already handles this safely.
        except Exception:  # pylint: disable=broad-exception-caught
            # Truncate traceback to last 3 frames + exception message.
            # Full tracebacks are verbose and eat context window space.
            tb_str = traceback.format_exc()
            tb_lines = tb_str.splitlines()
            if len(tb_lines) > 8:
                # Keep: "Traceback (most recent call last):" + last 3 frames
                # + blank line + exception type + message.
                # Typical format:
                #   Traceback (most recent call last):
                #     File "...", line N, in ...
                #       code
                #     File "...", line N, in ...
                #       code
                #     File "...", line N, in ...
                #       code
                #   ExceptionType: message
                # We keep header + last 3 frame pairs (file+code) + exception.
                header = tb_lines[0]  # "Traceback (most recent call last):"
                # Find the exception line (last non-empty line).
                exc_line = tb_lines[-1] if tb_lines[-1].strip() else tb_lines[-2]
                # Take last 6 lines before the exception (3 frames x 2 lines each).
                frame_lines = tb_lines[-7:-1] if len(tb_lines) >= 8 else tb_lines[1:-1]
                tb_str = "{:s}\n{:s}\n{:s}".format(header, "\n".join(frame_lines), exc_line)
                tb_str += "\n[Traceback truncated to last 3 frames]"
            # Detect common LLM mistakes and append actionable hints.
            if "__contains__: expected a string or a tuple of strings" in tb_str:
                tb_str += (
                    "\n\nHINT: You used `identifier in modifier` to check a Geometry Nodes socket. "
                    "This pattern is REMOVED in Blender 5.2+. "
                    "Use `getattr(modifier.properties.inputs, identifier)` instead:\n"
                    "    try:\n"
                    "        socket = getattr(mod.properties.inputs, \"Socket_3\")\n"
                    "    except AttributeError:\n"
                    "        pass  # Socket doesn't exist"
                )
            if "Context missing active object" in tb_str or "Context missing object" in tb_str:
                tb_str += (
                    "\n\nHINT: The scene has no active object. "
                    "Many operators (mode_set, transform, etc.) require an active object. "
                    "Create an object first with `bpy.ops.mesh.primitive_cube_add()` or "
                    "check `bpy.context.view_layer.objects.active` before calling mode-dependent operators."
                )
            # Scene safety Phase 4: operator-context and indexing hints.
            if "poll() failed" in tb_str:
                tb_str += (
                    "\n\nHINT: A bpy operator's poll() failed because its context was "
                    "wrong (usually no active object, or the wrong/empty selection). "
                    "Fix per operator:\n"
                    "  * object.join / join_shapes -> select >= 2 objects and set "
                    "bpy.context.view_layer.objects.active before calling it.\n"
                    "  * object.modifier_apply / modifier_remove -> set the active "
                    "object to the one owning the modifier; confirm the name exists.\n"
                    "  * object.mode_set -> an active object is required (and an "
                    "armature for POSE).\n"
                    "  * anything else -> use bpy.context.temp_override(...) to supply "
                    "the required context.\n"
                    "The selection may have changed since your last call -- set it "
                    "explicitly in the SAME script."
                )
            if "IndexError: list index out of range" in tb_str:
                tb_str += (
                    "\n\nHINT: The collection was empty (or the index was out of "
                    "range). selected_objects / bpy.data.<coll> can be empty, and "
                    "auto-undo or a user edit may have removed objects since your "
                    "last call. Guard with len() or use next(iter(...), None), and "
                    "re-fetch references by name with bpy.data.objects.get('Name')."
                )
            if "use_auto_smooth" in tb_str and "has no attribute" in tb_str:
                tb_str += (
                    "\n\nHINT: `mesh.use_auto_smooth` was REMOVED in Blender 5.3. "
                    "Use `mesh.auto_smooth_angle` directly instead:\n"
                    "    mesh.auto_smooth_angle = radians(30)  # Sets angle, auto-smooth is implicit\n"
                    "To disable auto-smooth, set the angle to 0:\n"
                    "    mesh.auto_smooth_angle = 0"
                )
            if "has no attribute 'fcurves'" in tb_str and "Action" in tb_str:
                tb_str += (
                    "\n\nHINT: `Action.fcurves` was REMOVED in Blender 5.0+ (layered animation system). "
                    "Use `keyframe_insert()` for all keyframe creation:\n"
                    "    obj.keyframe_insert(data_path=\"location\", frame=10)\n"
                    "To read existing F-Curves, use the read-only helper from the animation.md skill. "
                    "Never access `action.fcurves` directly."
                )
            if "'Context' object has no attribute 'selected_" in tb_str:
                tb_str += (
                    "\n\nHINT: `bpy.context` has NO `selected_edges` / `selected_faces` / "
                    "`selected_verts` attribute -- edit-mode selections live on the mesh data, "
                    "not on context. Read them with bmesh:\n"
                    "    import bmesh\n"
                    "    bm = bmesh.from_edit_mesh(bpy.context.view_layer.objects.active.data)\n"
                    "    sel_edges = [e for e in bm.edges if e.select]\n"
                    "    sel_faces = [f for f in bm.faces if f.select]\n"
                    "    sel_verts = [v for v in bm.verts if v.select]\n"
                    "To write selections, set `e.select` / `f.select` / `v.select` and call "
                    "`bm.select_flush_mode()`, or use `bmesh.ops.select_*`. "
                    "`bpy.context.selected_objects` IS valid -- but only in OBJECT mode "
                    "for objects."
                )
            if "Converting py args to operator properties" in tb_str and "unrecognized" in tb_str:
                tb_str += (
                    "\n\nHINT: You passed a keyword argument that this operator does not accept "
                    "(e.g. `ring_segments` -- the UV sphere uses `segments` and `ring_count`). "
                    "Discover the real parameters from the operator docstring:\n"
                    "    print(bpy.ops.mesh.primitive_uv_sphere_add.__doc__)\n"
                    "Common primitive keywords: cube/plane/monkey/grid: `size=`; "
                    "uv_sphere: `segments=` + `ring_count=`; ico_sphere: `subdivisions=`; "
                    "circle: `vertices=`; cylinder/cone: `vertices=` + `radius=`/`radius1=` "
                    "+ `depth=`; torus: `major_radius=` + `minor_radius=` + "
                    "`major_segments=` + `minor_segments=`."
                )
            if "StructRNA of type " in tb_str and "has been removed" in tb_str:
                tb_str += (
                    "\n\nHINT: You are using a STALE reference to a datablock that no longer "
                    "exists. This usually happens because a previous failed attempt was "
                    "automatically undone (deleting the objects it created) while you kept "
                    "the old reference, or because you deleted/replaced an object. "
                    "Re-fetch references fresh right before each use:\n"
                    "    obj = bpy.data.objects.get('Name')  # or bpy.context.view_layer.objects.active\n"
                    "    if obj is None:\n"
                    "        ...create or find it again...\n"
                    "Never reuse an object/material reference captured in an earlier tool call, "
                    "and guard lookups with try/except ReferenceError."
                )
            if "ShaderNodeBsdfPrincipled" in tb_str and "has no attribute" in tb_str and ("base_color" in tb_str or "Base Color" in tb_str):
                tb_str += (
                    "\n\nHINT: ShaderNodeBsdfPrincipled has NO `base_color` or `base_color_input" \
                    "` attribute. Access colors through the node's inputs dictionary:\n"
                    "    principled = nodes.new('ShaderNodeBsdfPrincipled')\n"
                    "    principled.inputs['Base Color'].default_value = (0.8, 0.2, 0.2, 1.0)\n"
                    "Other common inputs: 'Metallic', 'Roughness', 'Alpha', 'Emission Color'.\n"
                    "Run `print([i.name for i in principled.inputs])` to list all available inputs."
                )
            if 'Subdivision' in tb_str and 'has no attribute' in tb_str:
                tb_str += (
                    "\n\nHINT: Blender 5.3 changed subdivision modifier attributes. "
                    "Use print(dir(modifier)) to see available attributes. "
                    "Common names: levels (viewport), render_levels (render), "
                    "subdivision_type (CATMULL_CLARK or SIMPLE). "
                    "The old subdivisions attribute was renamed."
                )
            if "lamps" in tb_str and "has no attribute" in tb_str:
                tb_str += (
                    "\n\nHINT: 'BlendData' has no attribute 'lamps'. "
                    "It was renamed to 'lights' in Blender 4.0. "
                    "Use bpy.data.lights instead of bpy.data.lamps."
                )
            if '"EEVEE"' in tb_str and "not found in" in tb_str:
                tb_str += (
                    "\n\nHINT: The render engine name 'EEVEE' was renamed "
                    "to 'BLENDER_EEVEE' in Blender 4.0. "
                    "Use: scene.render.engine = 'BLENDER_EEVEE'"
                )
            if "RenderSettings" in tb_str and "'eevee'" in tb_str and "has no attribute" in tb_str:
                tb_str += (
                    "\n\nHINT: scene.render.eevee was moved to scene.eevee "
                    "in Blender 4.0. Use scene.eevee.use_ssr etc."
                )
            response: dict[str, object] = {"status": "error", "message": tb_str}
            if preflight_notes:
                response["preflight_notes"] = list(preflight_notes)
            if captured.stdout:
                response["stdout"] = captured.stdout
            if captured.stderr:
                response["stderr"] = captured.stderr
            return _ExecResult(response)

    # Check for a deferred response (background job in progress).
    check_fn_raw = namespace.get("check_is_finished")
    if check_fn_raw is not None and callable(check_fn_raw):
        check_fn: Callable[[], dict[str, object] | None] = check_fn_raw
        response = {}
        if captured.stdout:
            response["stdout"] = captured.stdout
        if captured.stderr:
            response["stderr"] = captured.stderr
        return _ExecResult(response, check_fn)

    result = namespace["result"]
    if not isinstance(result, dict):
        response = {
            "status": "error",
            "message": (
                "The `result` variable must be a dict, not {:s}. "
                "Wrap your return value: `result = {{\"key\": value}}`"
            ).format(type(result).__name__),
        }
    else:
        # Guard against LLM-generated code storing non-serializable values
        # such as Blender objects, e.g. `result = {"obj": bpy.context.active_object}`.
        # Without this, `json.dumps` fails inside `_encode_response`.
        if strict_json:
            try:
                json.dumps(result)
            except (TypeError, ValueError) as ex:
                response = {
                    "status": "error",
                    "message": "The `result` value is not JSON-serializable: {:s}".format(str(ex)),
                }
            else:
                response = {"status": "ok", "result": result}
        else:
            # Use `repr` as a fallback so non-serializable objects
            # (e.g. Blender ID types) appear as their string representation.
            result = json.loads(json.dumps(result, default=repr))
            response = {"status": "ok", "result": result}
    if preflight_notes:
        response["preflight_notes"] = list(preflight_notes)
    if captured.stdout:
        response["stdout"] = captured.stdout
    if captured.stderr:
        response["stderr"] = captured.stderr

    # Update bridge activity timestamp for liveness tracking.
    try:
        from . import agent_controller as _ac
        import time as _time
        _ac._agent_state.last_bridge_activity = _time.monotonic()
    except Exception:
        pass

    return _ExecResult(response)


def _execute_code_from_request(
        data: bytes,
) -> tuple[_ExecResult, bool]:
    """
    Parse a raw request and execute it.

    Return ``(exec_result, strict_json)``.
    """

    # NOTE: This function is not expected to raise exceptions because we control the MCP server, tool-code and add-on.
    # If there is an error, it will be handled by the caller (the LLM will get the stack trace).
    #
    # Even so, if a tool is misbehaving, or a change in the code causes an error,
    # give a "helpful" response - to avoid the hassles of searching about for the root cause.

    # Invalid JSON is not expected since the MCP server serializes requests with `json.dumps`.
    # Any error should be rare, the "default" exception path is fine.
    request = json.loads(data)

    # Fork (#85): every window has its own session id.  "identify" lets a
    # client confirm which window owns this port; a request stamped with
    # another window's id is refused instead of editing the wrong scene.
    from . import session_identity
    if request.get("type") == "identify":
        return _ExecResult({
            "status": "ok",
            "result": session_identity.describe(bridge_port=_actual_port),
        }), False
    _wrong_window = session_identity.check_request(request)
    if _wrong_window:
        return _ExecResult({"status": "error", "message": _wrong_window}), False

    if request.get("type") != "execute":
        return _ExecResult({
            "status": "error",
            "message": "Unknown request type: {!r}".format(request.get("type")),
        }), False
    code = request.get("code", "")

    # Not expected in normal use, but a clear message beats a cryptic trace-back,
    # Also make it clear where the error should be addressed.
    strict_json = request.get("strict_json")
    if not isinstance(strict_json, bool):
        return (
            _ExecResult({
                "status": "error",
                "message": (
                    "Internal error: a Coworker tool sent a request without the required 'strict_json' boolean key. "
                    "This is a bug in the tool that generated this code"
                ),
            }),
            False,
        )

    if _should_log_request():
        print("request:\n{:s}".format(code), file=sys.stderr)
    exec_result = _execute_code(code, strict_json=strict_json)
    _is_error = (
        exec_result.response.get("status") == "error"
        if not exec_result.check_fn
        else False
    )
    if _should_log_response(is_error=_is_error):
        if exec_result.check_fn is not None:
            print("response: deferred", file=sys.stderr)
        else:
            print("response: {:s}".format(json.dumps(exec_result.response, indent=2)), file=sys.stderr)

    return exec_result, strict_json


def _close_client(client: _Client) -> None:
    """
    Close a client connection and remove it from the active list.
    """
    try:
        client.conn.close()
    except Exception:  # pylint: disable=broad-exception-caught
        pass
    try:
        _state.clients.remove(client)
    except ValueError:
        pass


# ---------------------------------------------------------------------------
# Polling (called from the execution modules).

def _accept_clients() -> None:
    """
    Accept all pending connections on the listening socket.
    """
    if _state.sock is None:
        return
    while True:
        try:
            conn, _addr = _state.sock.accept()
            conn.setblocking(False)
            _state.clients.append(_Client(conn))
        except BlockingIOError:
            break
        except OSError:
            break


def _service_clients() -> bool:
    """
    Read from all connected clients, execute complete requests.

    Return ``True`` if at least one request was executed.
    """
    did_work = False
    # Iterate over a copy since clients may be removed during the loop.
    for client in _state.clients[:]:
        # Evict clients that have not sent a complete request in time.
        client.timeout -= 1
        if client.timeout <= 0:
            try:
                err: dict[str, object] = {
                    "status": "error",
                    "message": "Client timed out",
                }
                client.conn.sendall(_encode_response(err))
            except OSError:
                pass
            _close_client(client)
            continue

        try:
            chunk = client.conn.recv(_RECV_BUFFER_SIZE)
        except BlockingIOError:
            # No data available yet.
            continue
        except OSError:
            _close_client(client)
            continue

        if not chunk:
            # Client disconnected.
            _close_client(client)
            continue

        client.buffer.extend(chunk)

        # Guard against unbounded input from a misbehaving client.
        if len(client.buffer) > _MAX_REQUEST_BYTES:
            try:
                err = {
                    "status": "error",
                    "message": "Request exceeds {:d} byte limit".format(_MAX_REQUEST_BYTES),
                }
                client.conn.sendall(_encode_response(err))
            except OSError:
                pass
            _close_client(client)
            continue

        if b"\0" not in client.buffer:
            # Request not yet complete.
            continue

        # Execute the request and send the response.
        request_data = bytes(client.buffer[:client.buffer.index(b"\0")])
        try:
            exec_result, strict_json = _execute_code_from_request(request_data)
        except Exception:  # pylint: disable=broad-exception-caught
            exec_result = _ExecResult({"status": "error", "message": traceback.format_exc()})
            strict_json = False

        if exec_result.check_fn is not None:
            # Deferred response: hand the connection to deferred_tool.
            from . import deferred_tool
            deferred_tool.add(
                client.conn,
                exec_result.check_fn,
                strict_json,
                str(exec_result.response.get("stdout", "")),
                str(exec_result.response.get("stderr", "")),
            )
            # Remove from clients without closing the socket.
            try:
                _state.clients.remove(client)
            except ValueError:
                pass
        else:
            try:
                client.conn.sendall(_encode_response(exec_result.response))
            except OSError:
                pass
            _close_client(client)
        did_work = True

    return did_work


def poll() -> bool:
    """
    Non-blocking poll: accept new connections, service existing clients,
    and check deferred responses.

    Return ``True`` if work was done or deferred clients are pending.
    """
    from . import deferred_tool
    _accept_clients()
    did_work = _service_clients()
    if deferred_tool.poll():
        did_work = True
    # Stay in active polling mode while deferred clients exist.
    if deferred_tool.has_pending():
        did_work = True
    return did_work


def _handle_blocking_client(conn: socket.socket) -> bool:
    """
    Handle a single client connection synchronously with blocking I/O.

    Return ``True`` if a request was executed.
    """
    conn.settimeout(_CLIENT_TIMEOUT)
    try:
        buf = bytearray()
        while b"\0" not in buf:
            chunk = conn.recv(_RECV_BUFFER_SIZE)
            if not chunk:
                # Client disconnected.
                return False
            buf.extend(chunk)
            if len(buf) > _MAX_REQUEST_BYTES:
                err: dict[str, object] = {
                    "status": "error",
                    "message": "Request exceeds {:d} byte limit".format(_MAX_REQUEST_BYTES),
                }
                conn.sendall(_encode_response(err))
                return False

        request_data = bytes(buf[:buf.index(b"\0")])
        try:
            exec_result, _strict_json = _execute_code_from_request(request_data)
            if exec_result.check_fn is not None:
                # Unpack to preserve stdout/stderr captured before the deferred handler was set up.
                response = {**exec_result.response, "status": "error", "message": _DEFERRED_UNSUPPORTED_MESSAGE}
                exec_result = _ExecResult(response)
        except Exception:  # pylint: disable=broad-exception-caught
            exec_result = _ExecResult({"status": "error", "message": traceback.format_exc()})
        conn.sendall(_encode_response(exec_result.response))
        return True
    except socket.timeout:
        try:
            err = {"status": "error", "message": "Client timed out"}
            conn.sendall(_encode_response(err))
        except OSError:
            pass
        return False
    except OSError:
        return False
    finally:
        conn.close()


def poll_blocking(timeout: float = _POLL_BLOCKING_TIMEOUT) -> bool:
    """
    Block until a connection arrives (up to *timeout* seconds), then
    handle it synchronously with blocking I/O.

    For use in background mode where the GUI is not running.
    Return ``True`` if a request was executed.
    """
    if _state.sock is None:
        return False

    try:
        readable, _writable, _errored = select.select([_state.sock], [], [], timeout)
    except (OSError, ValueError):
        return False

    if not readable:
        return False

    try:
        conn, _addr = _state.sock.accept()
    except (BlockingIOError, OSError):
        return False

    return _handle_blocking_client(conn)


# ---------------------------------------------------------------------------
# Public API.

def start(host: str, port: int) -> None:
    """
    Bind the listening socket and begin accepting connections.

    This does not block. The caller must arrange for ``poll`` to be
    called periodically (see ``execute_interactive`` and
    ``execute_blocking``).

    If *port* is in use, the function automatically tries the next
    available port (``port + 1``, ``port + 2``, ... up to +100) and
    stores the actual port in ``_actual_port``.

    Callers should catch ``Exception`` broadly rather than specific types,
    since failures may be:
    - ``RuntimeError``, e.g. server already running.
    - ``OSError``, e.g. address already in use.
    ...other exceptions that are difficult to predict exhaustively.
    """

    # Track the actual port we end up binding.
    global _actual_port
    _actual_port = port

    if is_running():
        raise RuntimeError("Server is already running")

    # Pre-bind conflict detection: try connecting to the target port first.
    # If it succeeds, another Blender instance (or another process) already
    # owns this port.  We check *before* binding so we can give a clear
    # error message instead of silently sharing the port (which happens
    # with SO_REUSEADDR on Windows).
    _probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        _probe.settimeout(0.5)
        _probe.connect((host, port))
        _probe.close()
        # Port is in use -- auto-shuffle to the next available port.
        new_port = _find_available_port(port)
        if new_port == 0:
            raise OSError(
                "Port {:d} is in use and no subsequent port is available. "
                "Increase port_offset in Preferences (Advanced tab) to use a "
                "different set of ports.".format(port)
            )
        print("[Coworker] start: port {:d} in use -- shuffled to {:d}".format(port, new_port))
        port = new_port
        _actual_port = port
    except (ConnectionRefusedError, TimeoutError, OSError):
        # Expected -- port is free (connection refused or timed out).
        _probe.close()

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        if sys.platform == "win32":
            # SO_EXCLUSIVEADDRUSE prevents a second process from binding
            # the same port, even with SO_REUSEADDR.  Without this, a
            # second Blender instance would silently share port 9876 and
            # the OS would non-deterministically route code-execution
            # requests to the wrong instance.
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        else:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.setblocking(False)
        sock.bind((host, port))
        sock.listen(_LISTEN_BACKLOG)
    except OSError:
        sock.close()
        raise

    _state.sock = sock

    # Fork (#85): list this window as live so others can tell it apart.
    try:
        from . import session_identity
        session_identity.register_live(bridge_port=port)
    except Exception:  # pylint: disable=broad-exception-caught
        pass


def stop() -> None:
    """
    Close the listening socket, all client connections, and deferred responses.
    """
    from . import deferred_tool

    sock = _state.sock
    _state.sock = None
    if sock is not None:
        try:
            sock.close()
        except Exception:  # pylint: disable=broad-exception-caught
            pass

    for client in _state.clients:
        try:
            client.conn.close()
        except Exception:  # pylint: disable=broad-exception-caught
            pass
    _state.clients.clear()

    deferred_tool.close_all()

    try:
        from . import session_identity
        session_identity.unregister_live()
    except Exception:  # pylint: disable=broad-exception-caught
        pass


def is_running() -> bool:
    """
    Return whether the server is currently listening.
    """
    return _state.sock is not None
