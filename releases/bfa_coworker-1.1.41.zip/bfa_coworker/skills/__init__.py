# SPDX-FileCopyrightText: 2026 Blender Authors
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""
Skills Loader -- injects version-aware built-in skill files into the system prompt.

Always-loaded skills (injected into every conversation):
- Version-specific API changes (``blender_*.md``, cumulative <= current version)
- Best practices (``best_practices.md``)
- Naming conventions (``naming.md``)
- MCP tool guidance (``mcp_tools.md``)

Searchable domain skills live in ``mcp/blmcp/data/skills/`` and are
discovered by the LLM through the existing bundled-docs search tools.
"""

__all__ = (
    "get_always_loaded_skills",
    "get_domain_skills",
    "get_user_skills",
    "list_loaded_skills",
    "clear_cache",
)

from pathlib import Path

# Approximate characters per token -- must match agent_controller._CHARS_PER_TOKEN.
_CHARS_PER_TOKEN = 3.5

# Always-loaded reference files, in PRIORITY order (after the version-drift
# files).  When a token budget is supplied only the leading whole files that
# fit are included.
_ALWAYS_FILES = ("best_practices.md", "mcp_tools.md", "naming.md")

# ---------------------------------------------------------------------------
# Cache

_skills_cache: str | None = None
_skills_list: list[str] | None = None
# Blender minor version the cache was built for.  The cache MUST be keyed on
# the version: ``list_loaded_skills()`` (Preferences draw) builds it without a
# version, and without a key that version-less build would poison every later
# versioned call -- silently dropping all ``blender_*.md`` drift skills.
_UNSET = object()
_skills_cache_key: object = _UNSET
# Per-path skill file read cache (cleared by ``clear_cache``).
_read_cache: dict[str, str | None] = {}


# ---------------------------------------------------------------------------
# Public API

def get_always_loaded_skills(
    bpy_version: tuple[int, int, int] | None = None,
    custom_text: str = "",
    max_tokens: int | None = None,
) -> str:
    """Return concatenated built-in skill content for the system prompt.

    *bpy_version* -- ``(5, 3, 0)`` or ``None`` to skip version-specific files.
    *custom_text* -- optional user-provided custom skills text injected after
    built-in skills.
    *max_tokens* -- when given, include only the WHOLE files that fit, in
    priority order (version-drift files first -- they prevent hard API
    crashes -- then best practices, MCP tool guide, naming).  A file is never
    truncated; a file that does not fit is skipped so later, smaller files
    still make it.  This keeps the most important guidance on a small window
    instead of dropping the entire skills block.

    Result is cached until ``clear_cache()`` is called.
    """
    # pylint: disable=global-statement
    global _skills_cache, _skills_list, _skills_cache_key

    key = (
        bpy_version[1] if bpy_version and len(bpy_version) > 1 else None,
        max_tokens,
    )
    if (_skills_cache is not None and _skills_list is not None
            and _skills_cache_key == key):
        return _build_final(_skills_cache, custom_text)

    skills_dir = _get_skills_dir()
    parts: list[str] = []
    loaded: list[str] = []
    used = 0

    def _add(text: str | None, name: str) -> None:
        nonlocal used
        if not text:
            return
        cost = int(len(text) / _CHARS_PER_TOKEN) + 1
        if max_tokens is not None and parts and used + cost > max_tokens:
            return  # skip; a later smaller file may still fit
        parts.append(text)
        loaded.append(name)
        used += cost

    # 1. Version-specific files (cumulative: 5.3 loads 5.0-5.1 + 5.2 + 5.3).
    if bpy_version is not None:
        _major, _minor, _patch = bpy_version[:3]
        # The filenames encode major+minor (e.g. "blender_53.md" = 5.3), so
        # compare against 53 -- not the minor alone (3), which matched nothing
        # and silently dropped every version-drift skill.
        _current = _major * 10 + _minor
        # Newest-first: the current version's drift file is the most relevant,
        # so a tight budget should keep it over an older one.
        for fname in sorted(skills_dir.glob("blender_*.md"), reverse=True):
            # Parse version from filename like "blender_50_51.md" or "blender_52.md".
            ver_part = fname.stem[len("blender_"):]  # e.g. "50_51" or "52"
            if _version_loaded(ver_part, _current):
                _add(_read_skill(fname), fname.name)

    # 2. Always-loaded reference files, in priority order.
    for name in _ALWAYS_FILES:
        _add(_read_skill(skills_dir / name), name)

    _skills_cache = "\n\n".join(parts) if parts else ""
    _skills_list = loaded
    _skills_cache_key = key

    return _build_final(_skills_cache, custom_text)


def list_loaded_skills(bpy_version: tuple[int, int, int] | None = None) -> list[str]:
    """Return the list of built-in skill file names currently loaded.

    *bpy_version* -- when given, the versioned list is built/returned; without
    it the current cache is used as-is (never rebuilt version-less, which
    would drop the ``blender_*.md`` files for the session).
    """
    # pylint: disable=global-statement
    global _skills_list
    if bpy_version is not None:
        # Force the versioned build: if the cache was built version-less
        # (Preferences draw), get_always_loaded_skills rebuilds for this key.
        get_always_loaded_skills(bpy_version=bpy_version)
    elif _skills_list is None:
        get_always_loaded_skills()
    return _skills_list or []


def clear_cache() -> None:
    """Clear the skills cache so the next call rebuilds from disk."""
    # pylint: disable=global-statement
    global _skills_cache, _skills_list, _skills_cache_key
    _skills_cache = None
    _skills_list = None
    _skills_cache_key = _UNSET
    _read_cache.clear()


# ---------------------------------------------------------------------------
# Helpers

def _get_skills_dir() -> Path:
    """Return the absolute path to the skills/ directory."""
    this_dir = Path(__file__).resolve().parent
    return this_dir


def _read_skill(path: Path) -> str | None:
    """Read a skill .md file, returning ``None`` if missing or unreadable."""
    key = str(path)
    if key in _read_cache:
        return _read_cache[key]
    try:
        text: str | None = path.read_text(encoding="utf-8").strip()
    except OSError:
        text = None
    _read_cache[key] = text
    return text


def _version_loaded(ver_part: str, current_ver: int) -> bool:
    """Return True if *ver_part* should be loaded for *current_ver*.

    *current_ver* is ``major*10 + minor`` (5.3 -> 53).

    Examples:
        "50_51" with current_ver=53 -> True
        "52"     with current_ver=53 -> True
        "53"     with current_ver=53 -> True
        "54"     with current_ver=53 -> False
    """
    # Extract the highest version number from the filename.
    # "50_51" -> 51, "52" -> 52, "53_preview" -> 53
    parts = ver_part.replace("_", " ").replace("-", " ").split()
    max_ver = 0
    for p in parts:
        try:
            v = int(p)
            max_ver = max(max_ver, v)
        except ValueError:
            continue
    return max_ver > 0 and max_ver <= current_ver


def _build_final(built_in: str, custom_text: str) -> str:
    """Assemble the final skills block."""
    result = built_in
    if custom_text and custom_text.strip():
        result += "\n\n## User Custom Skills\n{:s}".format(custom_text.strip())
    return result


# -- Domain-to-skill mapping ----------------------------------------
# Maps domain keys (from _TOOL_DOMAINS in agent_controller.py) to
# skill filenames in mcp/blmcp/data/skills/ (or vendor/blmcp/data/skills/
# in deployed builds).

_DOMAIN_SKILL_MAP: dict[str, list[str]] = {
    "animation": ["animation.md"],
    "material": ["materials.md"],
    "modeling": ["mesh_editing.md", "modifiers.md"],
    "lighting": [],  # No dedicated skill file yet.
    "rendering": ["rendering.md"],
    "vse": [],
    "geometry_nodes": ["modifiers.md"],
    "assets": ["asset_browser.md"],
}


def get_domain_skills(domains: set[str], max_chars: int | None = None) -> str:
    """Load and concatenate skill files for the given domain set.

    Searches both the dev layout (``mcp/blmcp/data/skills/``) and the
    deployed layout (``vendor/blmcp/data/skills/``) for each skill file.
    Returns empty string if no domain skills are found or if no matching
    files exist.

    When *max_chars* is given, only **whole** skill files that fit are
    included.  A skill file is never truncated -- cutting a rule in half is
    worse than omitting the file (the caller can fall back to the always
    available ``get_python_api_docs`` / ``search_api_docs`` tools).  Files are
    considered in a stable (sorted) order; a file that does not fit is skipped
    so later, smaller files can still make it in.
    """
    if not domains:
        return ""

    # Collect skill filenames from all requested domains.
    filenames: set[str] = set()
    for d in domains:
        for fname in _DOMAIN_SKILL_MAP.get(d, []):
            filenames.add(fname)

    if not filenames:
        return ""

    # Search paths: dev layout first, then deployed layout.
    this_dir = Path(__file__).resolve().parent
    search_paths = [
        this_dir.parent.parent.parent / "mcp" / "blmcp" / "data" / "skills",  # dev
        this_dir.parent.parent / "vendor" / "blmcp" / "data" / "skills",  # deployed
    ]

    sep = "\n\n---\n\n"
    parts: list[str] = []
    used = 0
    for fname in sorted(filenames):
        for sp in search_paths:
            fpath = sp / fname
            text = _read_skill(fpath)
            if text:
                if max_chars is not None and max_chars > 0:
                    cost = len(text) + (len(sep) if parts else 0)
                    if used + cost > max_chars:
                        print(
                            "[Coworker] get_domain_skills: skipping {:s} "
                            "({:d} chars) -- would exceed the {:d}-char skill "
                            "budget (whole files only, never truncated)".format(
                                fname, len(text), max_chars))
                        break
                    used += cost
                parts.append(text)
                break

    if not parts:
        return ""

    return "## Domain Skills\n{:s}".format(sep.join(parts))


# -- User skill loader ----------------------------------------------
# Loads custom .md skill files from the user's SCRIPTS directory.
# Users can drop .md files into SCRIPTS/bfa_coworker_skills/ and they
# will be loaded alongside the built-in skills on every conversation.

_USER_SKILLS_DIR_NAME = "bfa_coworker_skills"


def get_user_skills() -> str:
    """Load and concatenate user skill files from the user skills directory.

    Scans ``SCRIPTS/bfa_coworker_skills/`` for ``.md`` files and returns
    their content as a single block prefixed with ``## User Skills``.
    Returns empty string if no files are found or the directory doesn't
    exist.
    """
    try:
        import bpy  # pylint: disable=import-error
        skills_dir = Path(bpy.utils.user_resource("SCRIPTS")) / _USER_SKILLS_DIR_NAME
    except Exception:
        return ""

    if not skills_dir.is_dir():
        return ""

    parts: list[str] = []
    for fpath in sorted(skills_dir.glob("*.md")):
        text = _read_skill(fpath)
        if text:
            parts.append(text)

    if not parts:
        return ""

    return "## User Skills\n{:s}".format("\n\n---\n\n".join(parts))
