# SPDX-FileCopyrightText: 2026 Blender Authors
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""
Bforartists Coworker add-on that provides an MCP socket bridge-server.
"""

__all__ = (
    "register",
    "unregister",
    "addon_version",
)

import bpy  # pylint: disable=import-error
import os

from . import mcp_to_blender_server
from . import coworker_api  # noqa: F401  (Engine 6: the MCP server's plan / question / digest tools)
from .preferences import _State, _BFACW_Preferences, BFACW_OT_pref_tab_select, BFACW_OT_copy_update_url
from .operators_server import (
    _BFACW_OT_server_start,
    _BFACW_OT_server_stop,
    _autostart_timer,
    _cli_execute_handler,
)
from .operators_llm import (
    _BFACW_OT_download_model,
    _BFACW_OT_cancel_download,
    _BFACW_OT_confirm_model_download,
    _BFACW_OT_start_llm,
    _BFACW_OT_stop_llm,
    _BFACW_OT_download_llama_server,
    _BFACW_OT_remove_llama_server,
    _BFACW_OT_open_llama_server_folder,
    _BFACW_OT_scan_existing_models,
    _BFACW_OT_select_preset,
    _BFACW_OT_select_existing_model,
    _BFACW_OT_open_models_dir,
    _BFACW_OT_download_custom_model,
    _BFACW_OT_set_ctx_preset,
)
from .operators_agent import (
    _BFACW_OT_test_remote_api,
    _BFACW_OT_refresh_remote_models,
    _BFACW_OT_open_model_browser,
    _BFACW_OT_ping_agent,
    _BFACW_OT_check_ports,
    _BFACW_OT_test_step,
    _BFACW_OT_test_step_reset,
    _BFACW_OT_asset_selftest_run,
    _BFACW_OT_asset_selftest_reset,
    BFACW_OT_copy_mcp_config,
    BFACW_OT_install_client_config,
    BFACW_OT_test_mcp_config,
    BFACW_OT_mcp_server_start,
    BFACW_OT_mcp_server_stop,
    BFACW_OT_save_provider,
    BFACW_OT_delete_provider,
    BFACW_OT_load_provider,
    BFACW_OT_test_polyhaven_hdri,
    BFACW_OT_test_polyhaven_texture,
    BFACW_OT_reload_skills,
    BFACW_OT_open_harness_prefs,
    BFACW_OT_open_addon_prefs,
    BFACW_OT_open_url,
    BFACW_OT_open_log,
    BFACW_OT_compare_benchmarks,
)
from .shared import (
    effective_ports,
    get_llm_manager,
    get_agent_controller,
    get_gen_controller,
)

# Store the CLI handle, only for correct register/unregister.
_cli_commands: list[object] = []

_classes = (
    _BFACW_Preferences,
    BFACW_OT_pref_tab_select,
    BFACW_OT_copy_update_url,
    _BFACW_OT_server_start,
    _BFACW_OT_server_stop,
    _BFACW_OT_download_model,
    _BFACW_OT_cancel_download,
    _BFACW_OT_confirm_model_download,
    _BFACW_OT_start_llm,
    _BFACW_OT_stop_llm,
    _BFACW_OT_download_llama_server,
    _BFACW_OT_scan_existing_models,
    _BFACW_OT_select_existing_model,
    _BFACW_OT_select_preset,
    _BFACW_OT_open_models_dir,
    _BFACW_OT_set_ctx_preset,
    _BFACW_OT_download_custom_model,
    _BFACW_OT_test_remote_api,
    _BFACW_OT_refresh_remote_models,
    _BFACW_OT_open_model_browser,
    _BFACW_OT_ping_agent,
    _BFACW_OT_check_ports,
    _BFACW_OT_test_step,
    _BFACW_OT_test_step_reset,
    _BFACW_OT_asset_selftest_run,
    _BFACW_OT_asset_selftest_reset,
    BFACW_OT_copy_mcp_config,
    BFACW_OT_install_client_config,
    BFACW_OT_test_mcp_config,
    BFACW_OT_mcp_server_start,
    BFACW_OT_mcp_server_stop,
    BFACW_OT_save_provider,
    BFACW_OT_delete_provider,
    BFACW_OT_load_provider,
    BFACW_OT_test_polyhaven_hdri,
    BFACW_OT_test_polyhaven_texture,
    BFACW_OT_reload_skills,
    BFACW_OT_open_harness_prefs,
    BFACW_OT_open_addon_prefs,
    BFACW_OT_open_url,
    BFACW_OT_open_log,
    BFACW_OT_compare_benchmarks,
    _BFACW_OT_remove_llama_server,
    _BFACW_OT_open_llama_server_folder,
)


def _migrate_operating_mode() -> None:
    """Migrate legacy agent_mode + llm_mode to the new operating_mode."""
    try:
        prefs = bpy.context.preferences.addons[__package__].preferences
        # Only migrate if operating_mode is still the default (not yet set).
        if prefs.operating_mode != "LOCAL_LLM":
            return
        # Check if agent_mode was explicitly set to EXTERNAL_HARNESS.
        if prefs.agent_mode == "EXTERNAL_HARNESS":
            prefs.operating_mode = "EXTERNAL_HARNESS"
        elif prefs.llm_mode == "remote":
            prefs.operating_mode = "REMOTE_API"
        # else: LOCAL_LLM is already the default, nothing to do.
    except Exception:
        pass  # Best-effort migration.


def register() -> None:
    """Register Coworker, all or nothing (#456).  A failure part way (an icon Blender
    lacks failed a class) used to leave panels registered without the add-on: Blender
    drops a failed add-on from ``preferences.addons``, so every one of them then raised
    a KeyError on draw.  Now what was registered is taken out again and the error stays
    visible, so Blender shows the add-on as failed instead of half there."""
    registered: list[type] = []
    register_class = bpy.utils.register_class

    def _recording(cls):
        register_class(cls)
        registered.append(cls)

    bpy.utils.register_class = _recording
    try:
        _register()
    except Exception:
        import traceback
        print("[Coworker] register failed, rolling back:\n" + traceback.format_exc())
        _rollback(registered)
        raise
    finally:
        bpy.utils.register_class = register_class


def _rollback(registered: list[type]) -> None:
    """Undo a failed ``_register()`` without ``unregister()``'s side effects: nothing
    saved, so the settings backup and the saved chat are left alone (#400)."""
    from . import chat_editor, ui_chat, ui_context_menus
    for step in (ui_context_menus.unregister, chat_editor.unregister, ui_chat.unregister,
                 coworker_api.unregister, mcp_to_blender_server.stop):
        try:
            step()
        except Exception:  # pylint: disable=broad-exception-caught
            pass                # it may not have got that far
    for cmd in _cli_commands:
        try:
            bpy.utils.unregister_cli_command(cmd)
        except (RuntimeError, AttributeError):
            pass
    _cli_commands.clear()
    if bpy.app.timers.is_registered(_after_register_timer):
        bpy.app.timers.unregister(_after_register_timer)
    for cls in reversed(registered):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass                # already taken out by its module


def _register() -> None:
    # Start file-based logging as early as possible so all subsequent
    # print() diagnostics are captured to disk.
    from . import log
    log.install_print_tee()
    # Coalesce Blender 5.3+ "Policy Violation" warnings from vendored deps
    # into a single summary line instead of a console flood.
    log.install_policy_warning_filter()
    # Apply the initial console-suppression state from the saved preference.
    # Default is True (suppress) which matches debug_mode=False (the default).
    try:
        prefs = bpy.context.preferences.addons.get(__package__)
        if prefs is not None:
            log.set_suppress_console(not prefs.preferences.debug_mode)
            from . import session_identity as _si
            _si.set_token_required(prefs.preferences.require_session_token)
    except Exception:  # pylint: disable=broad-exception-caught
        pass  # Preferences not yet available; defaults (suppress ON, token ON) are fine.

    # Migrate vendor/deps/ out of the addon tree BEFORE Blender's sandbox
    # scans it.  Physical presence of top-level package dirs (rich/, click/,
    # httpx/, etc.) inside the addon tree triggers policy violations even if
    # they are never imported.  Moving them to ~/.cache/bfa_coworker/ avoids
    # the scan entirely.
    from . import agent_controller
    agent_controller.migrate_vendor_deps()
    coworker_api.register()           # Engine 6b: notices scene edits after a turn
    # External Harness configs run a launcher at a fixed path; point it at
    # this install so configs survive Coworker moving or updating (#100).
    agent_controller.sync_harness_launcher()

    # Clear stale CLI command handles from a previous registration.
    _cli_commands.clear()

    # Safety unregister in case of stale registration from a previous error.
    for cls in reversed(_classes):
        try:
            if hasattr(bpy.types, cls.__name__):
                bpy.utils.unregister_class(cls)
        except Exception:
            pass

    for cls in _classes:
        bpy.utils.register_class(cls)
    try:
        _cli_commands.append(bpy.utils.register_cli_command("bfa_coworker", _cli_execute_handler))
    except (AttributeError, Exception) as ex:
        print("[Coworker] register_cli_command not available: {:s}".format(str(ex)))

    # Migrate operating_mode from legacy agent_mode + llm_mode.
    _migrate_operating_mode()

    # Register the chat UI modules.
    from . import ui_chat
    ui_chat.register()
    # The Coworker editor and the compact sidebar chat (Tier 4, GPU 4 + 5).
    from . import chat_editor
    chat_editor.register()
    # Coworker in the right-click menus: Explain This, Translate (#290, #42).
    from . import ui_context_menus
    ui_context_menus.register()

    # Discover generative plugins (Tier 5).
    # This scans gen_plugins/ and populates the registry.
    # Safe to call -- discovery is idempotent.
    try:
        from .gen_plugins import discover, PLUGIN_REGISTRY
        discover()
        print("[Coworker] gen_plugins: {:d} plugins registered".format(
            len(PLUGIN_REGISTRY)))
    except Exception as ex:
        print("[Coworker] gen_plugins: discovery skipped -- {:s}".format(str(ex)))

    # Issue #86: a fresh install (e.g. moved into the update repository by the
    # Coworker Installer) restores the previous install's settings once.  Not
    # in here: bpy.data is restricted inside register(), and update callbacks
    # of restored settings touch it (#400).  The timer restores first and then
    # schedules auto-start, which reads the restored settings.
    if not bpy.app.timers.is_registered(_after_register_timer):
        bpy.app.timers.register(_after_register_timer, first_interval=0.0, persistent=True)
    _publish_secrets()      # keys already set; restored ones publish as they are set (#346)


def _after_register_timer() -> None:
    """One-shot, right after ``register()``: restore the settings backup, then auto-start."""
    _restore_settings_backup()
    _publish_secrets()      # the restored keys, whatever their update callbacks did (#346)
    _schedule_autostart()
    return None


def _schedule_autostart() -> None:
    """Defer auto-start so the server does not slow down Blender's startup."""
    if not bpy.app.background:
        if not _State.startup_online_ok_or_error():
            return

        prefs = bpy.context.preferences.addons[__package__].preferences
        if prefs.use_autostart:
            bpy.app.timers.register(
                _autostart_timer,
                first_interval=prefs.autostart_delay,
                persistent=True,
            )

        # If agent autostart is also enabled, schedule the full agent startup.
        if prefs.agent_autostart:
            bpy.app.timers.register(
                _autostart_agent_timer,
                first_interval=prefs.autostart_delay + 2.0,
                persistent=True,
            )


def _autostart_agent_timer() -> None:
    """Deferred timer callback that starts the full agent (MCP server + LLM)."""
    from . import ui_chat

    if bpy.app.background:
        return

    prefs = bpy.context.preferences.addons[__package__].preferences
    _bridge_port, _mcp_port, _llm_port = effective_ports(prefs)

    # In External Harness mode, only the bridge server is needed.
    # The MCP server and LLM are managed externally.
    if prefs.operating_mode == "EXTERNAL_HARNESS":
        print("[Coworker] Agent auto-start: External Harness mode -- bridge only")
        return
    if prefs.operating_mode == "EXTERNAL_AGENT":
        # Starting the agent app is the user's call (Start in the chat).
        print("[Coworker] Agent auto-start: External Agent mode -- press Start to connect")
        return

    print("[Coworker] Agent auto-start: using ports bridge={:d} mcp={:d} llm={:d}".format(
        _bridge_port, _mcp_port, _llm_port))

    # Start the MCP HTTP server.
    _ac = get_agent_controller()
    if not _ac._agent_state.mcp_server_running:
        proc = _ac.start_mcp_server(port=_mcp_port, blender_port=_bridge_port)
        if proc is None:
            print("[Coworker][WARN] Agent auto-start: MCP server failed -- {:s}".format(_ac._agent_state.error))
            return

    # Start local LLM if configured.
    if prefs.operating_mode == "LOCAL_LLM":
        _llm = get_llm_manager()
        _llm_cfg = _llm.get_config()
        _llm_cfg.mode = "local"
        _llm_cfg.llama_source = getattr(prefs, "llama_source", "BUNDLED").lower()
        _llm_cfg.llama_path = prefs.llama_path
        _llm_cfg.model_repo_id = prefs.model_repo_id
        _llm_cfg.model_filename = prefs.model_filename
        _llm_cfg.downloaded_models_dir = prefs.downloaded_models_dir
        _llm_cfg.local_ctx_size = prefs.local_ctx_size
        _llm_cfg.local_max_tokens = prefs.local_max_tokens
        _llm_cfg.thinking_budget_tokens = prefs.thinking_budget_tokens
        _llm_cfg.lock_scene_while_working = getattr(prefs, "lock_scene_while_working", True)
        _llm_cfg.local_port = _llm_port
        _llm.set_config(_llm_cfg)

        llm_state = _llm.get_state()
        if not llm_state.is_running:
            # If an existing model path is set, use it directly.
            existing_path = prefs.existing_model_path
            _probe = existing_path if existing_path and os.path.isfile(existing_path) else None
            # Never download implicitly at startup -- there is no UI here to
            # confirm a multi-GB transfer.  Record it so starting the agent
            # prompts instead.
            _ready, _info = _llm.check_local_model_ready(_probe)
            if _ready:
                if _probe:
                    _llm.start_local_llama(model_path=_probe)
                else:
                    _llm.start_local_llama()
            else:
                _llm.set_pending_model_download(_info)
                print("[Coworker][WARN] Agent auto-start: local model not "
                      "downloaded -- start the Coworker agent to confirm the "
                      "download, or configure a model in Preferences")
    elif prefs.operating_mode == "REMOTE_API":
        # Remote mode -- sync remote prefs to config so chat_send finds them.
        _llm = get_llm_manager()
        _llm_cfg = _llm.get_config()
        _llm_cfg.mode = "remote"
        _llm_cfg.remote_api_url = prefs.remote_api_url
        _llm_cfg.remote_api_key = prefs.remote_api_key
        _llm_cfg.remote_model = prefs.remote_model
        _llm.set_config(_llm_cfg)

    print("[Coworker] Agent auto-start: full agent running on ports bridge={:d} mcp={:d} llm={:d}".format(
        _bridge_port, _mcp_port, _llm_port))


def addon_version() -> str:
    """This install's version, read from its blender_manifest.toml."""
    try:
        import tomllib
        path = os.path.join(os.path.dirname(__file__), "blender_manifest.toml")
        with open(path, "rb") as fh:
            return str(tomllib.load(fh).get("version", ""))
    except Exception:  # pylint: disable=broad-exception-caught
        return ""


def _settings_config_dir() -> str:
    return os.path.join(bpy.utils.user_resource('CONFIG'), "bfa_coworker")


def _save_settings_backup() -> None:
    """Issue #86: keep a copy of the preferences outside the add-on's module path."""
    try:
        from . import settings_transfer
        addon = bpy.context.preferences.addons.get(__package__)
        if addon is not None and addon.preferences is not None:
            version = addon_version()
            settings_transfer.save(addon.preferences, _settings_config_dir(), version)
    except Exception as ex:  # pylint: disable=broad-exception-caught
        print("[Coworker] settings backup skipped: {:s}".format(str(ex)))


def _restore_settings_backup() -> None:
    """Issue #86: a fresh install picks up the settings of the copy it replaced."""
    try:
        from . import settings_transfer
        addon = bpy.context.preferences.addons.get(__package__)
        if addon is None or addon.preferences is None:
            return None
        applied = settings_transfer.restore_once(addon.preferences, _settings_config_dir())
        if applied:
            print("[Coworker] restored {:d} setting(s) from the previous install".format(len(applied)))
            bpy.context.preferences.is_dirty = True
    except Exception as ex:  # pylint: disable=broad-exception-caught
        print("[Coworker] settings restore skipped: {:s}".format(str(ex)))
    return None


def _publish_secrets() -> None:
    """#346: your keys and the session token show as *** in every log, export and Copy.
    (Changing a key in Preferences hands the new one over too.)"""
    try:
        from . import log, session_identity
        from .preferences import publish_secrets
        addon = bpy.context.preferences.addons.get(__package__)
        if addon is not None and addon.preferences is not None:
            publish_secrets(addon.preferences)
        log.set_secret("session_token", session_identity.session_token())
    except Exception as ex:  # pylint: disable=broad-exception-caught
        print("[Coworker] secret redaction setup: {:s}".format(str(ex)))


def unregister() -> None:
    from . import execute_interactive
    from . import ui_chat

    # Until the deferred restore has run (it never does in background mode),
    # this install holds defaults: saving them would overwrite the backup (#400).
    if not bpy.app.timers.is_registered(_after_register_timer):
        _save_settings_backup()
    coworker_api.unregister()
    # Keep the chat first: the cleanup below empties it (it used to be saved after,
    # so quitting overwrote the saved chat with an empty one).
    ui_chat._save_chat_history()

    # Clean up subprocesses.
    get_llm_manager().cleanup()
    get_agent_controller().cleanup()

    # Clean up generative controller (Tier 5).
    try:
        get_gen_controller().cleanup()
    except Exception:
        pass

    # Unregister chat UI (the Coworker editor first: it builds on ui_chat's panels).
    from . import ui_context_menus
    ui_context_menus.unregister()
    from . import chat_editor
    chat_editor.unregister()
    ui_chat.unregister()

    for cmd in _cli_commands:
        try:
            bpy.utils.unregister_cli_command(cmd)
        except RuntimeError:
            pass
    _cli_commands.clear()

    for timer in (_after_register_timer, _autostart_timer):
        if bpy.app.timers.is_registered(timer):
            bpy.app.timers.unregister(timer)

    mcp_to_blender_server.stop()
    if bpy.app.timers.is_registered(execute_interactive.run):
        bpy.app.timers.unregister(execute_interactive.run)
    for cls in reversed(_classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
