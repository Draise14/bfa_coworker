# SPDX-FileCopyrightText: 2026 Blender Authors
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""
Add-on preferences definition and runtime state tracking.
"""

__all__ = (
    "_State",
    "_BFACW_Preferences",
    "BFACW_OT_pref_tab_select",
    "BFACW_OT_copy_update_url",
)

import bpy  # pylint: disable=import-error
from bpy.props import (
    BoolProperty,
    FloatProperty,
    IntProperty,
    StringProperty,
    EnumProperty,
)  # pylint: disable=import-error

import os
from pathlib import Path

from . import mcp_to_blender_server
from . import log as _log_module
from .shared import (
    PORT_MIN,
    PORT_MAX,
    AUTOSTART_DELAY,
    STATE_OFFLINE_ERROR_MESSAGE,
    MODEL_PRESET_ITEMS,
    REMOTE_PROVIDER_ITEMS,
    AGENT_MODE_ITEMS,
    MCP_SERVER_MODE_ITEMS,
    OPERATING_MODE_ITEMS,
    APPROVAL_MODE_ITEMS,
    CHAT_MODE_ITEMS,
    is_debug_mode,
    effective_ports,
    effective_whisper_port,
    get_llm_manager,
    icon as safe_icon,
)


def _download_status_icon(msg: str) -> str:
    """Return a green checkmark icon once a download has completed.

    Completion messages are the only ones that start with these prefixes;
    everything else stays the blue info icon.
    """
    if (
        msg.startswith("Download complete")
        or msg.startswith("Model already downloaded")
        or msg.startswith("llama-server installed")
    ):
        return "CHECKMARK"
    return "INFO"



# The operating mode last switched to, so a refused switch (while running) can
# go back to it -- External Agent shares agent_mode / llm_mode with the others.
_PREVIOUS_MODE: dict[str, str] = {}
# Set while a refused switch writes the previous mode back, so that write's own
# update call does nothing (#489).
_MODE_REVERTING: dict[str, bool] = {"on": False}

# Your keys and tokens: shown as *** in every log, export and Copy (#346).
SECRET_PREFS = ("remote_api_key", "hf_token", "gen_remote_key")


def publish_secrets(prefs) -> None:
    """Hand the current keys to the log's redaction (at start and on every change)."""
    for name in SECRET_PREFS:
        _log_module.set_secret(name, getattr(prefs, name, ""))


def _update_secret(self, _context) -> None:
    publish_secrets(self)

# Translate's languages (#42): (code, name).
_LANGUAGES = (
    ("en", "English"), ("es", "Spanish"), ("fr", "French"), ("de", "German"), ("it", "Italian"),
    ("pt", "Portuguese"), ("nl", "Dutch"), ("pl", "Polish"), ("ru", "Russian"), ("uk", "Ukrainian"),
    ("tr", "Turkish"), ("ar", "Arabic"), ("hi", "Hindi"), ("id", "Indonesian"), ("vi", "Vietnamese"),
    ("th", "Thai"), ("zh_hans", "Chinese (Simplified)"), ("zh_hant", "Chinese (Traditional)"),
    ("ja", "Japanese"), ("ko", "Korean"))


class _State:
    """
    Module-level runtime state that is not persisted across sessions.
    """

    # Communicate to the user if there is a problem.
    # Displayed in the preferences UI when non-empty.
    autostart_error: str = ""

    @classmethod
    def startup_info_set(cls, error: str) -> None:
        """
        Store a startup error message to display in the preferences UI.
        """
        cls.autostart_error = error

    @classmethod
    def startup_info_set_from_exception(cls, ex: Exception) -> None:
        """
        Store a startup exception message to display in the preferences UI
        and print the full traceback to stderr for debugging.
        """
        # NOTE: this is correct but reads like an unhandled exception.
        # import traceback
        # traceback.print_exception(ex)
        cls.autostart_error = str(ex)

    @classmethod
    def startup_info_clear(cls) -> None:
        """
        Clear any startup error so it no longer appears in the preferences UI.
        """
        cls.autostart_error = ""

    @classmethod
    def startup_online_ok_or_error(cls) -> bool:
        """
        Return True when online access is permitted, otherwise store an error and return False.
        """
        if bpy.app.online_access:
            return True
        cls.startup_info_set(STATE_OFFLINE_ERROR_MESSAGE)
        if bpy.app.background:
            print("Error: {:s}".format(STATE_OFFLINE_ERROR_MESSAGE))
            print("  Use --online-mode to enable online access from the command line")
        return False


class _BFACW_Preferences(bpy.types.AddonPreferences):  # type: ignore[misc]
    bl_idname = __package__

    # Issue #86: True once this install restored the settings backup (or found
    # none).  A fresh install -- e.g. Coworker moved into the update repository
    # by the Coworker Installer -- starts False and restores once.
    settings_restored: BoolProperty(  # type: ignore[valid-type]
        name="Settings Restored",
        default=False,
        options={'HIDDEN'},
    )

    host: StringProperty(  # type: ignore[valid-type]
        name="Host",
        default=mcp_to_blender_server.DEFAULT_HOST,
    )
    port: IntProperty(  # type: ignore[valid-type]
        name="Port",
        default=mcp_to_blender_server.DEFAULT_PORT,
        min=PORT_MIN,
        max=PORT_MAX,
    )
    use_autostart: BoolProperty(  # type: ignore[valid-type]
        name="Auto Start",
        description=(
            "Automatically start the MCP bridge server when Blender starts.\n"
            "Without this, you must manually start from the preferences UI.\n"
            "(ignored in background mode)"
        ),
        default=True,
    )
    autostart_delay: FloatProperty(  # type: ignore[valid-type]
        name="Auto Start Delay",
        description=(
            "Seconds to wait after Blender starts before auto-starting the server.\n"
            "Avoids adding overhead to Blender's startup sequence"
        ),
        default=AUTOSTART_DELAY,
        min=0.0,
        max=30.0,
        step=10,
        precision=1,
        subtype="TIME_ABSOLUTE",
    )

    # -- Chat Display ---------------------------------------------

    # The chat input's height (#389): the most text lines it grows to before it scrolls, set by
    # dragging its top edge (or Ctrl+Up / Ctrl+Down in it); one for the sidebars, one for the
    # Coworker editors.  Saved with the preferences, so it stays across sessions.
    chat_input_lines_sidebar: IntProperty(  # type: ignore[valid-type]
        name="Sidebar Input Lines",
        description="Most lines the sidebar chat's input grows to before it scrolls (drag its top edge)",
        default=6, min=2, max=60,
    )
    chat_input_lines_editor: IntProperty(  # type: ignore[valid-type]
        name="Editor Input Lines",
        description="Most lines the Coworker editor's input grows to before it scrolls (drag its top edge)",
        default=6, min=2, max=60,
    )
    # #626: whether the height above was set by hand (then the input keeps exactly that many
    # lines whatever its text) or it still grows with the text (a fresh install; a double-click
    # on the input's top edge goes back to this).
    chat_input_sized_sidebar: BoolProperty(  # type: ignore[valid-type]
        name="Sidebar Input Sized By Hand",
        description="The sidebar chat's input keeps the height you dragged instead of growing with its text",
        default=False,
    )
    chat_input_sized_editor: BoolProperty(  # type: ignore[valid-type]
        name="Editor Input Sized By Hand",
        description="The Coworker editor's input keeps the height you dragged instead of growing with its text",
        default=False,
    )

    # -- Long requests (auto-continue) -----------------------------

    auto_continue_rounds: IntProperty(  # type: ignore[valid-type]
        name="Auto-Continue Rounds",
        description=(
            "Long requests: when the Coworker uses up its step budget for a "
            "turn while still making progress on its plan, it continues "
            "automatically for up to this many extra rounds (older turns are "
            "summarized between rounds). 0 = stop and report progress. Stop "
            "and the 20-minute turn limit always apply"
        ),
        default=3,
        min=0,
        max=6,
    )

    # -- Chats side by side (Threads 3, #359) ------------------------

    chats_at_once: IntProperty(  # type: ignore[valid-type]
        name="Chats Running at Once",
        description=(
            "Remote API and External Agent: how many chat tabs may work at the same "
            "time; more wait for a free slot. The Local LLM runs chats one after "
            "another unless Local Side by Side is on"
        ),
        default=3,
        min=1,
        max=8,
    )

    local_side_by_side: BoolProperty(  # type: ignore[valid-type]
        name="Local Side by Side",
        description=(
            "Local LLM: let chat tabs work at the same time too (up to 4, on the "
            "server's shared context slots). Each chat then runs slower; off, chats "
            "take turns one after another"
        ),
        default=False,
    )

    # -- Debug Mode --------------------------------------------------

    def _update_debug_mode(self, _context: bpy.types.Context) -> None:
        _log_module.set_suppress_console(not self.debug_mode)

    debug_mode: BoolProperty(  # type: ignore[valid-type]
        name="Debug / Diagnostics",
        description=(
            "Show the Diagnostics panel in Preferences with port checking, "
            "benchmark suites, and other developer tools. Also shows the "
            "llama-server console window while the local model starts"
        ),
        default=False,
        update=_update_debug_mode,
    )

    # -- Chat draw trace (#387) ---------------------------------------

    def _update_chat_draw_trace(self, _context: bpy.types.Context) -> None:
        if self.chat_draw_trace:            # a fresh trace from now on
            from .ui_gpu import draw_trace
            draw_trace.TRACE.clear()

    chat_draw_trace: BoolProperty(  # type: ignore[valid-type]
        name="Chat Draw Trace",
        description=(
            "Record the last 300 draws of the chat (where, how big, how long, anything odd), "
            "to find a rare glitch. When the chat glitches, use Copy Chat Draw Trace and paste "
            "it into the issue. Off by default"
        ),
        default=False,
        update=_update_chat_draw_trace,
    )

    # -- Session token (Engine 8) ------------------------------------

    def _update_require_token(self, _context: bpy.types.Context) -> None:
        from . import session_identity
        session_identity.set_token_required(self.require_session_token)

    def _update_magic_wording(self, _context: bpy.types.Context) -> None:
        """Turning the magic wording on or off shows at once in every chat (#528)."""
        from . import ui_chat
        ui_chat._redraw_all_chats()

    def _update_approval_mode(self, _context: bpy.types.Context) -> None:
        from . import ui_chat
        ui_chat.apply_approval_mode(self.approval_mode)

    translate_from: EnumProperty(  # type: ignore[valid-type]
        name="Translate From",
        description="The language the text is in (Translate, in the right-click menus); remembered for next time",
        items=[("auto", "Detect", "Coworker works out which language the text is in", 'VIEWZOOM', 0)]
              + [(code, name, "The text is in " + name, 'NONE', i + 1) for i, (code, name) in enumerate(_LANGUAGES)],
        default="auto",
    )

    translate_language: EnumProperty(  # type: ignore[valid-type]
        name="Translate To",
        description="The language Translate (right-click a text field, a text object or a text strip) "
                    "turns text into; remembered for next time",
        items=[(code, name, "Translate into " + name) for code, name in _LANGUAGES],
        default="en",
    )

    approval_mode: EnumProperty(  # type: ignore[valid-type]
        name="Approval",
        description="How much the chat asks before tools run, on every engine (switching forgets "
                    "every \"Always\")",
        items=APPROVAL_MODE_ITEMS,
        default="ASK",
        update=_update_approval_mode,
    )

    require_session_token: BoolProperty(  # type: ignore[valid-type]
        name="Require Session Token",
        description=(
            "Only run requests that carry your private session token. Keeps web "
            "pages in your browser (which can reach this computer's local ports) "
            "from running code in Blender. Coworker and its External Harness "
            "launcher send the token for you; turn off only if a tool of your "
            "own can't. Restart Coworker after changing it"
        ),
        default=True,
        update=_update_require_token,
    )

    # -- Log Level ---------------------------------------------------

    def _update_log_level(self, _context: bpy.types.Context) -> None:
        mcp_to_blender_server.log_level = self.log_level

    log_level: EnumProperty(  # type: ignore[valid-type]
        name="Log Level",
        description=(
            "Tool-call logging granularity:\n"
            "  Off -- no logging\n"
            "  Errors Only -- log only failed tool calls\n"
            "  All -- log every tool request and response"
        ),
        items=[
            ("OFF", "Off", "No tool-call logging"),
            ("ERRORS_ONLY", "Errors Only", "Log only tool calls that returned errors"),
            ("ALL", "All", "Log every tool request and response"),
        ],
        default="OFF",
        update=_update_log_level,
    )

    def _update_use_log(self, _context: bpy.types.Context) -> None:
        # Legacy bool kept for backward compat; syncs to log_level.
        if self.use_log:
            self.log_level = "ALL"
        else:
            self.log_level = "OFF"

    use_log: BoolProperty(  # type: ignore[valid-type]
        name="Log",
        description="Print every tool request and response status to the terminal",
        default=False,
        update=_update_use_log,
    )

    def _update_timer_interval_active(self, _context: bpy.types.Context) -> None:
        # Cached on the server module because the timer callback may fire
        # many times a second, avoid slower preferences lookups.
        mcp_to_blender_server.timer_internal_vars_calc(active=self.timer_interval_active)

    timer_interval_active: FloatProperty(  # type: ignore[valid-type]
        name="Timer Interval",
        description="Seconds between queue polling ticks in interactive mode",
        default=0.25,
        min=0.05,
        max=5.0,
        step=1,
        precision=2,
        subtype='TIME_ABSOLUTE',
        update=_update_timer_interval_active,
    )

    def _update_timer_interval_idle(self, _context: bpy.types.Context) -> None:
        # Cached on the server module because the timer callback may fire
        # many times a second, avoid slower preferences lookups.
        mcp_to_blender_server.timer_internal_vars_calc(idle=self.timer_interval_idle)

    timer_interval_idle: FloatProperty(  # type: ignore[valid-type]
        name="Timer Interval Idle",
        description="Seconds between queue polling ticks while idle (no pending work)",
        default=1.0,
        min=0.1,
        max=10.0,
        step=10,
        precision=2,
        subtype='TIME_ABSOLUTE',
        update=_update_timer_interval_idle,
    )

    def _update_timer_interval_idle_delay(self, _context: bpy.types.Context) -> None:
        # Cached on the server module because the timer callback may fire
        # many times a second, avoid slower preferences lookups.
        mcp_to_blender_server.timer_internal_vars_calc(idle_delay=self.timer_interval_idle_delay)

    timer_interval_idle_delay: FloatProperty(  # type: ignore[valid-type]
        name="Idle Delay",
        description="Seconds of inactivity before switching to the idle polling interval",
        default=5.0,
        min=1.0,
        max=60.0,
        step=100,
        precision=1,
        subtype='TIME_ABSOLUTE',
        update=_update_timer_interval_idle_delay,
    )

    # -- LLM Configuration Properties ---------------------------------

    def _update_llm_mode(self, _context: bpy.types.Context) -> None:
        """Sync llm_mode to llm_manager config and stop local LLM if switching to remote."""
        llm = get_llm_manager()
        cfg = llm.get_config()
        cfg.mode = self.llm_mode
        cfg.remote_api_url = self.remote_api_url
        cfg.remote_api_key = self.remote_api_key
        cfg.remote_model = self.remote_model
        cfg.llama_source = self.llama_source.lower()
        cfg.llama_path = bpy.path.abspath(self.llama_path)  # "//" is relative to the .blend (#382)
        cfg.llama_backend = self.llama_backend
        cfg.model_repo_id = self.model_repo_id
        cfg.model_filename = self.model_filename
        cfg.downloaded_models_dir = self.downloaded_models_dir
        cfg.local_ctx_size = self.local_ctx_size
        cfg.local_max_tokens = self.local_max_tokens
        cfg.thinking_budget_tokens = self.thinking_budget_tokens
        cfg.local_kv_cache_quant = self.local_kv_cache_quant
        cfg.local_server_verbose = self.local_server_verbose
        cfg.lock_scene_while_working = getattr(self, "lock_scene_while_working", True)
        llm.set_config(cfg)
        # If switching to remote, stop any running local LLM.
        if self.llm_mode == "remote":
            llm.stop_local_llama()

    llm_mode: EnumProperty(  # type: ignore[valid-type]
        name="LLM Mode",
        items=[
            ("local", "Local (llama.cpp)", "Run a local LLM via llama-server"),
            ("remote", "Remote API", "Use a remote API like OpenAI or OpenRouter"),
        ],
        default="local",
        update=_update_llm_mode,
    )

    # -- Unified Operating Mode ------------------------------------------

    def _update_operating_mode(self, _context: bpy.types.Context) -> None:
        """Sync operating_mode to agent_mode and llm_mode, and switch to the relevant tab.

        Rejects the change when the agent is already running -- switching modes
        mid-flight can kill the MCP server and leave the agent in a broken state.
        The user must stop the agent first.
        """
        if _MODE_REVERTING["on"]:
            return      # the refused switch below writing the previous mode back
        from . import agent_controller as _ac
        if _ac._agent_state.mcp_server_running:
            # Revert to the previous mode.  agent_mode / llm_mode still hold
            # it: they are only synced below, after this guard.
            print("[Coworker] operating_mode change rejected -- agent is running. Stop the agent first.")
            if _PREVIOUS_MODE.get("mode"):
                previous = _PREVIOUS_MODE["mode"]
            elif self.agent_mode == "EXTERNAL_HARNESS":
                previous = "EXTERNAL_HARNESS"
            elif self.llm_mode == "remote":
                previous = "REMOTE_API"
            else:
                previous = "LOCAL_LLM"
            # Written through the property: on Blender 5.x a bpy.props value is not an ID
            # property, and self["operating_mode"] = ... raises "id properties not supported
            # for this type" (#489).  The write calls this update again; the flag makes
            # that call a no-op.
            _MODE_REVERTING["on"] = True
            try:
                self.operating_mode = previous
            finally:
                _MODE_REVERTING["on"] = False
            return

        if self.operating_mode == "LOCAL_LLM":
            self.agent_mode = "SELF_CONTAINED"
            self.llm_mode = "local"
            self.pref_tab = "LOCAL_LLM"
        elif self.operating_mode == "REMOTE_API":
            self.agent_mode = "SELF_CONTAINED"
            self.llm_mode = "remote"
            self.pref_tab = "REMOTE_API"
        elif self.operating_mode == "EXTERNAL_HARNESS":
            self.agent_mode = "EXTERNAL_HARNESS"
            # llm_mode stays as-is (not used in harness mode)
            self.pref_tab = "ADVANCED"
        elif self.operating_mode == "EXTERNAL_AGENT":
            # Coworker's own chat; the turn runs in the external agent (Tier 4, Agent 4).
            self.agent_mode = "SELF_CONTAINED"
            self.pref_tab = "ADVANCED"
        _PREVIOUS_MODE["mode"] = self.operating_mode

    operating_mode: EnumProperty(  # type: ignore[valid-type]
        name="Operating Mode",
        # One line: each mode's tab adds its own description (#233).
        description="Where the chat and the model run (stop Coworker to switch)",
        items=OPERATING_MODE_ITEMS,
        default="LOCAL_LLM",
        update=_update_operating_mode,
    )

    def _update_llama_path(self, _context: bpy.types.Context) -> None:
        """Sync llama_path to llm_manager config and re-search for the binary."""
        llm = get_llm_manager()
        cfg = llm.get_config()
        cfg.llama_path = bpy.path.abspath(self.llama_path)  # "//" is relative to the .blend (#382)
        llm.set_config(cfg)
        # Re-run detection so the UI reflects the new path immediately.
        llm.invalidate_llama_server_cache()

    llama_path: StringProperty(  # type: ignore[valid-type]
        name="llama-server Path",
        default="",
        subtype='FILE_PATH',
        description=(
            "Path to a custom llama-server.exe. Leave empty to use the bundled version.\n"
            "To add a custom llama.cpp installation to PATH:\n"
            "  Windows: System Properties -> Environment Variables -> Path -> add the folder\n"
            "  macOS/Linux: export PATH=\"/path/to/llama.cpp/build/bin:$PATH\"\n"
            "The addon bundles its own copy -- only set this if you need a specific build."
        ),
        update=_update_llama_path,
    )

    def _update_llama_source(self, _context: bpy.types.Context) -> None:
        """Sync llama_source to llm_manager config and re-search for the binary."""
        llm = get_llm_manager()
        cfg = llm.get_config()
        cfg.llama_source = self.llama_source.lower()
        llm.set_config(cfg)
        # Re-run detection so the UI reflects the new source immediately.
        llm.invalidate_llama_server_cache()

    llama_source: EnumProperty(  # type: ignore[valid-type]
        name="llama-server Source",
        description=(
            "Where llama-server comes from.\n"
            "  Bundled -- the addon downloads and manages its own copy\n"
            "            (Download / Update / Remove buttons are shown).\n"
            "  Custom -- you provide your own llama.cpp build via a path.\n"
            "            The addon never modifies or updates it."
        ),
        items=[
            ("BUNDLED", "Bundled (auto-managed)", "The addon downloads and manages llama-server automatically"),
            ("CUSTOM", "Custom (user-provided)", "Use your own llama.cpp build -- the addon never modifies it"),
        ],
        default="BUNDLED",
        update=_update_llama_source,
    )

    def _update_llama_backend(self, _context: bpy.types.Context) -> None:
        """Sync llama_backend to llm_manager config."""
        llm = get_llm_manager()
        cfg = llm.get_config()
        cfg.llama_backend = self.llama_backend
        llm.set_config(cfg)
        # Invalidate the find_llama_server cache so the new backend binary is found.
        llm.invalidate_llama_server_cache()

    llama_backend: EnumProperty(  # type: ignore[valid-type]
        name="GPU Backend",
        description=(
            "Select the GPU backend for llama-server.\n"
            "  Auto -- detect NVIDIA (CUDA), AMD/Intel (Vulkan), or CPU\n"
            "  CUDA -- NVIDIA GPUs (RTX 20xx+; 3090/4090/5090 recommended)\n"
            "  Vulkan -- AMD Radeon, Intel Arc, or NVIDIA fallback\n"
            "  CPU -- no GPU acceleration\n"
            "\n"
            "WARN  Cannot be changed while the agent is running.\n"
            "Stop the agent first, then change the backend."
        ),
        items=[
            ("auto", "Auto (Detect)", "Auto-detect the best backend for your GPU"),
            ("cuda", "CUDA 12.4", "NVIDIA GPUs -- RTX 20xx+ (3090/4090/5090 recommended)"),
            ("vulkan", "Vulkan", "AMD Radeon, Intel Arc, or NVIDIA fallback"),
            ("cpu", "CPU", "No GPU acceleration -- runs on CPU only"),
        ],
        default="auto",
        update=_update_llama_backend,
    )

    model_repo_id: StringProperty(  # type: ignore[valid-type]
        name="Model Repo ID",
        default="unsloth/gpt-oss-20b-GGUF",
    )

    model_filename: StringProperty(  # type: ignore[valid-type]
        name="Model Filename",
        default="gpt-oss-20b-Q4_K_M.gguf",
    )

    downloaded_models_dir: StringProperty(  # type: ignore[valid-type]
        name="Models Directory",
        default=str(Path.home() / "bfa_coworker_models"),
        subtype='DIR_PATH',
    )

    # -- Model Preset -------------------------------------------------

    def _update_model_preset(self, _context: bpy.types.Context) -> None:
        """When user picks a preset, auto-fill repo_id, filename, ctx_size, and max_tokens."""
        llm = get_llm_manager()
        preset = llm.get_preset_by_id(self.model_preset)
        if preset is not None:
            self.model_repo_id = preset.repo_id
            self.model_filename = preset.filename
            # Auto-set context window: hardware-aware recommendation, capped by
            # the model's own context window. See _apply_recommended_ctx().
            self._apply_recommended_ctx(preset)
            # Auto-set max output tokens from preset.
            self.local_max_tokens = preset.max_tokens
            # Clear existing model path -- using preset now.
            self.existing_model_path = ""
            # Build info string for display (memory texts generated, #558).
            self.model_preset_info = llm.preset_info_text(preset)
            # Sync to llm_manager config immediately.
            cfg = llm.get_config()
            cfg.model_repo_id = preset.repo_id
            cfg.model_filename = preset.filename
            cfg.downloaded_models_dir = self.downloaded_models_dir
            cfg.local_ctx_size = self.local_ctx_size
            cfg.local_max_tokens = self.local_max_tokens
            cfg.thinking_budget_tokens = self.thinking_budget_tokens
            cfg.hf_token = self.hf_token
            cfg.llama_backend = self.llama_backend
            llm.set_config(cfg)
        else:
            self.model_preset_info = ""

    def _current_model_gb(self, preset: "ModelPreset | None" = None) -> float:
        """Estimate the model file size in GB (real file size when present)."""
        if self.existing_model_path and os.path.isfile(self.existing_model_path):
            try:
                return os.path.getsize(self.existing_model_path) / (1024 ** 3)
            except OSError:
                pass
        if preset is not None and getattr(preset, "file_bytes", 0):
            # The model file's size, read from its header with the preset (#558).
            return preset.file_bytes / (1024 ** 3)
        if self.model_filename:
            models_dir = Path(self.downloaded_models_dir) if self.downloaded_models_dir else (
                Path.home() / "bfa_coworker_models")
            candidate = models_dir / self.model_filename
            if candidate.is_file():
                try:
                    return candidate.stat().st_size / (1024 ** 3)
                except OSError:
                    pass
        return 0.0

    def _model_sizing_kwargs(self, preset: "ModelPreset | None" = None) -> dict:
        """What the memory plan needs about the chosen model (#543): the file
        when it is on disk (its header and projector), else the preset's estimates."""
        llm = get_llm_manager()
        kwargs: dict = {"kv_q8_forced": bool(self.local_kv_cache_quant)}
        path = ""
        if self.existing_model_path and os.path.isfile(self.existing_model_path):
            path = self.existing_model_path
        elif self.model_filename:
            models_dir = Path(self.downloaded_models_dir) if self.downloaded_models_dir else (
                Path.home() / "bfa_coworker_models")
            if (models_dir / self.model_filename).is_file():
                path = str(models_dir / self.model_filename)
        if path:
            kwargs["model_path"] = path
        elif preset is not None and llm.preset_profile(preset) is not None:
            # Not downloaded yet: the preset's own header numbers (#558).
            kwargs["projector_bytes"] = float(preset.projector_bytes)
            kwargs["profile"] = llm.preset_profile(preset)
        elif preset is not None and preset.vision:
            kwargs["projector_bytes"] = float(llm._FALLBACK_PROJECTOR_BYTES)
        if preset is not None:
            kwargs["ctx_cap"] = preset.context_window
        return kwargs

    def _apply_recommended_ctx(self, preset: "ModelPreset | None" = None) -> None:
        """Set the context window to a recommendation from the free VRAM and the
        model's own needs, never below the first request (#543)."""
        llm = get_llm_manager()
        model_gb = self._current_model_gb(preset)
        recommended = llm.recommend_context_size(
            model_gb=model_gb,
            backend=self.llama_backend,
            **self._model_sizing_kwargs(preset),
        )
        cap = preset.context_window if preset is not None else 131072
        recommended = min(recommended, cap)
        # Snap down again in case the model cap landed off a standard size.
        fitting = [s for s in llm.ctx_preset_sizes if s <= recommended]
        recommended = fitting[-1] if fitting else llm.ctx_preset_sizes[0]
        self.local_ctx_size = recommended
        self.local_ctx_preset = str(recommended)

    model_preset: EnumProperty(  # type: ignore[valid-type]
        name="Recommended Model",
        description="Select a curated model preset. Picking one auto-fills the repo and filename below",
        items=MODEL_PRESET_ITEMS,
        update=_update_model_preset,
        default="gpt_oss_20b_q4",
    )

    model_preset_info: StringProperty(  # type: ignore[valid-type]
        name="",
        default="",
    )

    show_more_models: BoolProperty(  # type: ignore[valid-type]
        name="Show More Models",
        default=False,
    )

    # -- Existing Model Selector --------------------------------------

    existing_model_path: StringProperty(  # type: ignore[valid-type]
        name="Existing Model Path",
        description=(
            "When set, this absolute path is used directly instead of "
            "resolving via repo/filename. Set by selecting an existing model."
        ),
        default="",
        subtype='FILE_PATH',
    )
    custom_model_url: StringProperty(  # type: ignore[valid-type]
        name="Custom Model URL",
        description="HuggingFace URL or direct .gguf link to download",
        default="",
    )

    remote_api_url: StringProperty(  # type: ignore[valid-type]
        name="API URL",
        default="https://openrouter.ai/api",
        description="Base URL for the OpenAI-compatible API endpoint",
    )

    remote_api_key: StringProperty(  # type: ignore[valid-type]
        name="API Key",
        default="",
        subtype='PASSWORD',
        description="Your API key. Get one at openrouter.ai/keys",
        update=_update_secret,
    )

    # -- Remote Provider --------------------------------------------

    def _update_remote_provider(self, _context: bpy.types.Context) -> None:
        """When user picks a provider, auto-fill the API URL."""
        llm = get_llm_manager()
        provider = llm.get_remote_provider_by_id(self.remote_provider)
        if provider is not None:
            self.remote_api_url = provider.base_url
            # Sync to llm_manager config.
            cfg = llm.get_config()
            cfg.remote_api_url = provider.base_url
            llm.set_config(cfg)

    remote_provider: EnumProperty(  # type: ignore[valid-type]
        name="Provider",
        description="Select a remote API provider. Auto-fills the API URL",
        items=REMOTE_PROVIDER_ITEMS,
        update=_update_remote_provider,
        default="openrouter",
    )

    # -- Remote Model -----------------------------------------------

    remote_model: StringProperty(  # type: ignore[valid-type]
        name="Model Name",
        default="",
        description=(
            "Model ID to use for completions (e.g. 'openai/gpt-4o').\n"
            "Browse models at openrouter.ai/models"
        ),
    )

    remote_accepts_images: BoolProperty(  # type: ignore[valid-type]
        name="Model Sees Images",
        default=True,
        description=(
            "The remote model takes pictures (most current cloud models do). "
            "Pictures a tool makes (screenshots, renders) are then shown to it; "
            "off, it gets a short note with where the picture is instead"
        ),
    )

    remote_models_count: IntProperty(  # type: ignore[valid-type]
        name="Models Available",
        default=0,
    )

    remote_models_fetch_error: StringProperty(  # type: ignore[valid-type]
        name="",
        default="",
    )

    agent_autostart: BoolProperty(  # type: ignore[valid-type]
        name="Auto-Start Coworker",
        default=False,
    )

    port_offset: IntProperty(  # type: ignore[valid-type]
        name="Port Offset",
        description=(
            "Offset added to all default ports (bridge: 9876, MCP: 9191, LLM: 8081).\n"
            "Increase by 1, 2, 3... if another app is using the same ports"
        ),
        default=0,
        min=0,
        max=100,
    )

    # -- Individual Port Overrides ---------------------------------

    bridge_port: IntProperty(  # type: ignore[valid-type]
        name="Bridge Port",
        description=(
            "Override the bridge server port. "
            "0 = use default (9876) + offset"
        ),
        default=0,
        min=0,
        max=65535,
    )
    mcp_port: IntProperty(  # type: ignore[valid-type]
        name="MCP Port",
        description=(
            "Override the MCP HTTP server port. "
            "0 = use default (9191) + offset"
        ),
        default=0,
        min=0,
        max=65535,
    )
    llm_port: IntProperty(  # type: ignore[valid-type]
        name="LLM Port",
        description=(
            "Override the LLM server port. "
            "0 = use default (8081) + offset"
        ),
        default=0,
        min=0,
        max=65535,
    )
    whisper_port: IntProperty(  # type: ignore[valid-type]
        name="Speech Port",
        description=(
            "Override the speech server (whisper-server) port. "
            "0 = use default (8481) + offset"
        ),
        default=0,
        min=0,
        max=65535,
    )

    # -- Speech (whisper.cpp, #375) ----------------------------------------
    speech_device: EnumProperty(  # type: ignore[valid-type]
        name="Device",
        description="Where whisper-server runs",
        items=[
            ("AUTO", "Auto", "CUDA with an NVIDIA GPU, else the CPU"),
            ("CPU", "CPU", "The CPU build (9 MB download)"),
            ("CUDA", "CUDA", "The NVIDIA CUDA 12 build (about 690 MB download)"),
        ],
        default="AUTO",
    )
    speech_model: EnumProperty(  # type: ignore[valid-type]
        name="Model",
        description="The speech model whisper-server loads",
        items=[
            ("AUTO", "Auto", "Small on the CPU, Large v3 Turbo with CUDA"),
            ("tiny", "Tiny (78 MB)", "Smallest and fastest; not measured"),
            ("base", "Base (148 MB)", "Fast on the CPU"),
            ("small", "Small (488 MB)", "The CPU default"),
            ("medium", "Medium (1.5 GB)", "Not measured"),
            ("large-v3-turbo", "Large v3 Turbo (1.6 GB)", "The CUDA default; slow on the CPU"),
        ],
        default="AUTO",
    )
    speech_language: EnumProperty(  # type: ignore[valid-type]
        name="Language",
        description="The spoken language (Auto detects it)",
        items=[
            ("auto", "Auto", "Detect the language"),
            ("en", "English", ""), ("es", "Spanish", ""), ("fr", "French", ""), ("de", "German", ""),
            ("it", "Italian", ""), ("pt", "Portuguese", ""), ("nl", "Dutch", ""), ("pl", "Polish", ""),
            ("ru", "Russian", ""), ("uk", "Ukrainian", ""), ("tr", "Turkish", ""), ("sv", "Swedish", ""),
            ("ja", "Japanese", ""), ("zh", "Chinese", ""), ("ko", "Korean", ""), ("hi", "Hindi", ""),
            ("ar", "Arabic", ""),
        ],
        default="auto",
    )
    speech_prompt: StringProperty(  # type: ignore[valid-type]
        name="Names",
        description=("Names and terms to spell right, comma separated "
                     "(e.g. Bforartists, Blender): sent to whisper as its prompt"),
        default="",
    )
    speech_use_remote: BoolProperty(  # type: ignore[valid-type]
        name="Use Remote for speech",
        description=("Send the audio to the Remote provider's OpenAI-compatible "
                     "/v1/audio/transcriptions (with the Remote API key) instead of "
                     "transcribing on this computer"),
        default=False,
    )
    speech_remote_model: StringProperty(  # type: ignore[valid-type]
        name="Remote Model",
        description="The provider's transcription model (e.g. whisper-1)",
        default="whisper-1",
    )

    local_ctx_size: IntProperty(  # type: ignore[valid-type]
        name="Context Window Size",
        description=(
            "Context window size (in tokens) passed to llama-server via --ctx-size.\n"
            "Larger values allow longer conversations but use much more RAM/VRAM.\n"
            "Prefer the preset buttons above the Custom slider -- a context that is "
            "too large for your memory is the most common startup crash.\n"
            "Default 32768 works for most models. Gemma 4 supports up to 262144."
        ),
        default=32768,
        min=16384,
        max=262144,
        step=1024,
        subtype='UNSIGNED',
    )

    def _update_server_pref(self, _context: bpy.types.Context) -> None:
        """Sync the preferences that shape the server command line (#543)."""
        llm = get_llm_manager()
        llm.set_config(llm.apply_server_prefs(llm.get_config(), self, bpy.path.abspath))

    local_kv_cache_quant: BoolProperty(  # type: ignore[valid-type]
        name="Quantize KV Cache (q8_0)",
        description=(
            "Always store the KV cache in 8-bit instead of 16-bit -- roughly halves "
            "its memory. Off, Coworker still uses 8-bit when 16-bit would not fit "
            "the free VRAM at start. Slight quality cost. GPU backends only; "
            "applies on next server start."
        ),
        default=False,
        update=_update_server_pref,
    )

    local_server_verbose: BoolProperty(  # type: ignore[valid-type]
        name="Verbose Server Log",
        description=(
            "Log every prompt and token in the llama-server log. For "
            "troubleshooting only -- it slows requests and the log grows "
            "quickly. Applies on next server start."
        ),
        default=False,
        update=_update_server_pref,
    )

    lock_scene_while_working: BoolProperty(  # type: ignore[valid-type]
        name="Lock Scene While Working",
        description=(
            "While the coworker is running a turn, temporarily make the objects "
            "and collections it created or touched un-selectable, so they cannot "
            "be re-targeted in the viewport mid-turn. Everything is restored when "
            "the turn ends. Turn this off to allow full selection during a turn"
        ),
        default=True,
    )

    reset_scene_on_failure: BoolProperty(  # type: ignore[valid-type]
        name="Reset Scene On Benchmark Step Failure",
        description=(
            "When a benchmark step FAILS, delete the objects it left behind and "
            "return to object mode, so one bad step cannot corrupt the next one "
            "(duplicate geometry, .001 name drift). Only affects the test suites"
        ),
        default=True,
    )

    def _update_ctx_preset(self, _context: bpy.types.Context) -> None:
        """Sync the context preset button to the numeric context size."""
        if self.local_ctx_preset != "custom":
            try:
                self.local_ctx_size = int(self.local_ctx_preset)
            except ValueError:
                pass

    local_ctx_preset: EnumProperty(  # type: ignore[valid-type]
        name="Context Window Preset",
        description=(
            "One-click context window sizes. The recommended size for your "
            "hardware is suggested automatically when you pick a model. "
            "Custom reveals a manual slider for fine control."
        ),
        items=[
            # The numbers are the items' positions before 4K / 8K went (#631): Blender stores
            # an enum as that number, so the kept presets still read as themselves.
            ("16384", "16K", "16384 tokens -- the smallest offered; tight for agent work", 2),
            ("32768", "32K", "32768 tokens -- recommended default", 3),
            ("65536", "64K", "65536 tokens -- long conversations, needs lots of memory", 4),
            ("131072", "128K", "131072 tokens -- only on high-end hardware", 5),
            ("custom", "Custom", "Manually set the context size with a slider", 6),
        ],
        default="32768",
        update=_update_ctx_preset,
    )

    local_max_tokens: IntProperty(  # type: ignore[valid-type]
        name="Max Output Tokens",
        description=(
            "Maximum tokens per LLM API call (reasoning + content + tool calls).\n"
            "Reasoning models need more headroom. If output gets cut off, raise this.\n"
            "Auto-continue will retry if the model hits this limit mid-generation."
        ),
        default=16384,
        min=512,
        max=131072,
        step=1024,
        subtype='UNSIGNED',
    )

    def _update_reasoning_effort(self, _context: bpy.types.Context) -> None:
        """Map the Reasoning Effort preset to a numeric token budget."""
        if self.reasoning_effort != "custom":
            try:
                self.thinking_budget_tokens = int(self.reasoning_effort)
            except ValueError:
                pass

    reasoning_effort: EnumProperty(  # type: ignore[valid-type]
        name="Reasoning Effort",
        description=(
            "How hard the model thinks before it answers -- a friendly name "
            "for the token budget sent to llama-server as "
            "thinking_budget_tokens. Custom reveals the exact number."
        ),
        items=[
            ("0", "Off", "No cap -- the model thinks as long as it needs (slowest replies)"),
            ("512", "Low", "Light thinking ~ 512 tokens -- snappy replies, simple tasks"),
            ("1024", "Medium", "Balanced ~ 1024 tokens -- good default for most work"),
            ("2048", "High", "Deep thinking ~ 2048 tokens -- complex, multi-step tasks"),
            ("custom", "Custom", "Set the exact token budget with a slider"),
        ],
        default="1024",
        update=_update_reasoning_effort,
    )

    thinking_budget_tokens: IntProperty(  # type: ignore[valid-type]
        name="Thinking Budget",
        description=(
            "Maximum tokens for chain-of-thought reasoning per API call.\n"
            "Limits how long the model thinks before responding.\n"
            "Lower values = faster responses, higher values = better reasoning.\n"
            "Set to 0 to disable (no limit on reasoning tokens)."
        ),
        default=1024,
        min=0,
        max=8192,
        step=256,
        subtype='UNSIGNED',
    )

    hf_token: StringProperty(  # type: ignore[valid-type]
        name="HuggingFace Token",
        default="",
        subtype='PASSWORD',
        description=(
            "Optional HuggingFace token for gated models.\n"
            "Get one at https://huggingface.co/settings/tokens\n"
            "Only needed for models that require authentication."
        ),
        update=_update_secret,
    )

    # -- Generation (Tier 5) Properties ------------------------------

    gen_backend: EnumProperty(  # type: ignore[valid-type]
        name="Generation Backend",
        description="Which backend to use for image/video/audio generation",
        items=[
            ("local", "Local (Built-in)", "Run generative models locally via diffusers/torch"),
            ("pallaidium", "Pallaidium Bridge", "Bridge to Pallaidium addon if installed"),
            ("comfyui", "ComfyUI", "Connect to a local ComfyUI server"),
            ("remote", "Remote API", "Use a remote OpenAI-compatible generation API"),
        ],
        default="local",
    )

    gen_models_dir: StringProperty(  # type: ignore[valid-type]
        name="Gen Models Directory",
        description="Directory where generative models are downloaded and cached",
        default=str(Path.home() / "bfa_coworker_gen_models"),
        subtype='DIR_PATH',
    )

    gen_output_dir: StringProperty(  # type: ignore[valid-type]
        name="Output Directory",
        description="Directory where generated media (images, videos, audio) is saved",
        default=str(Path.home() / "bfa_coworker_generated"),
        subtype='DIR_PATH',
    )

    gen_auto_download: BoolProperty(  # type: ignore[valid-type]
        name="Auto-Download Models",
        description="Automatically download generative models when first used",
        default=True,
    )

    gen_comfyui_url: StringProperty(  # type: ignore[valid-type]
        name="ComfyUI URL",
        description="URL of the ComfyUI server (default: http://127.0.0.1:8188)",
        default="http://127.0.0.1:8188",
    )

    gen_remote_url: StringProperty(  # type: ignore[valid-type]
        name="Remote Gen API URL",
        description="Base URL for the remote generation API (OpenAI /v1 dialect)",
        default="",
    )

    gen_remote_key: StringProperty(  # type: ignore[valid-type]
        name="Remote Gen API Key",
        default="",
        subtype='PASSWORD',
        description="API key for the remote generation service",
        update=_update_secret,
    )

    # -- Poly Haven Resolution -------------------------------------------

    polyhaven_resolution: EnumProperty(  # type: ignore[valid-type]
        name="Poly Haven Resolution",
        description=(
            "Default download resolution for Poly Haven textures and HDRIs. "
            "Lower resolutions are faster to download and use less memory."
        ),
        items=lambda self, _context: [
            ("512", "512 - Preview", "Tiny textures for prototyping"),
            ("1k", "1k - Lightweight", "Good for background objects"),
            ("2k", "2k - Balanced (Recommended)", "Best balance of quality and performance"),
            ("4k", "4k - Production", "High quality for close-up shots"),
            ("8k", "8k - Maximum", "Largest files, highest detail"),
        ],
        default=2,
    )

    # -- Preferences Tab --------------------------------------------------

    pref_tab: EnumProperty(  # type: ignore[valid-type]
        name="Tab",
        items=[
            ("LOCAL_LLM", "Local LLM", "Configure and download local models", 'CONSOLE', 0),
            ("REMOTE_API", "Remote API", "Configure remote API access", 'WORLD', 1),
            ("GENERATIVE", "Generative", "Image/video/audio generation backends", 'RENDER_RESULT', 2),
            ("ADVANCED", "Advanced", "External harness, ports, and diagnostics", 'SETTINGS', 3),
            ("SPEECH", "Speech", "Speech to text with whisper.cpp (Sequencer transcripts)", 'SPEAKER', 4),
        ],
        default="LOCAL_LLM",
    )

    # -- Agent Mode -------------------------------------------------------

    agent_mode: EnumProperty(  # type: ignore[valid-type]
        name="Coworker Mode",
        description="How the Coworker agent operates",
        items=AGENT_MODE_ITEMS,
        default="SELF_CONTAINED",
    )

    # -- MCP Server Mode (for External Harness) ---------------------------

    mcp_server_mode: EnumProperty(  # type: ignore[valid-type]
        name="MCP Server Mode",
        description="How the MCP server is launched in External Harness mode",
        items=MCP_SERVER_MODE_ITEMS,
        default="STDIO",
    )

    # -- MCP Server Network Settings --------------------------------------

    mcp_server_host: StringProperty(  # type: ignore[valid-type]
        name="MCP Server Host",
        description="Host for the MCP HTTP server in Network mode",
        default="127.0.0.1",
    )

    mcp_server_port_override: IntProperty(  # type: ignore[valid-type]
        name="MCP Server Port",
        description="Port for the MCP HTTP server in Network mode (0 = use default 9191 + offset)",
        default=0,
        min=0,
        max=65535,
    )

    # -- Harness Configuration -----------------------------------------

    use_blender_python_for_harness: BoolProperty(  # type: ignore[valid-type]
        name="Use Blender's Python",
        description=(
            "When ON, harness configs use Blender's bundled Python with "
            "vendor dependencies -- no pip install needed.\n"
            "When OFF, uses system 'python' (requires pip-installed "
            "bfa-coworker-mcp)"
        ),
        default=True,
    )

    external_agent_preset: EnumProperty(  # type: ignore[valid-type]
        name="Agent",
        description=("The agent app on this computer that does the work in External Agent mode. "
                     "You chat in Coworker; it uses your own login / subscription for that agent"),
        items=lambda self, _context: self._get_external_agent_items(),
        default=0,
    )

    external_agent_only_coworker_tools: BoolProperty(  # type: ignore[valid-type]
        name="Only Coworker Tools",
        description=("The agent may only use Coworker's Blender tools: its own shell and file "
                     "tools are refused, and it doesn't load your other agent setups (skills, "
                     "rules). Off: it asks you in the chat before using one of its own tools "
                     "(Allow once, Always, Deny)"),
        default=True,
    )

    auto_max_hours: FloatProperty(  # type: ignore[valid-type]
        name="Auto: Hours",
        description="Auto mode stops after this many hours",
        default=8.0, min=0.25, max=48.0, step=25,
    )

    auto_max_turns: IntProperty(  # type: ignore[valid-type]
        name="Auto: Turns",
        description="Auto mode stops after sending this many turns itself",
        default=30, min=1, max=500,
    )

    helpers_per_turn: IntProperty(  # type: ignore[valid-type]
        name="Helpers per Turn",
        description=("The most helper chats one chat may start in a turn (delegate_task, #479). "
                     "Helpers can't start helpers of their own"),
        default=4, min=1, max=12,
    )

    magic_wording: BoolProperty(  # type: ignore[valid-type]
        name="Magic Wording",
        description=("Show the agent as a Wizard, helper chats as mages, wizards and magicians, and a word "
                     "about magic while the model thinks. Only what you see changes: what is sent to the model stays "
                     "as it is. Off: plain \"Coworker\", \"Helper\" and \"Thinking\""),
        default=True,
        update=_update_magic_wording,
    )

    external_agent_tools_on_demand: BoolProperty(  # type: ignore[valid-type]
        name="Load Tools When Needed",
        description=("Give the agent Coworker's basic tools first (scene, code, docs, screenshots, "
                     "plan, questions) and the specialised ones (materials, nodes, assets, animation...) "
                     "when it asks for them. Saves about 10K tokens on every request. Off: all tools "
                     "from the start"),
        default=True,
    )

    external_agent_command: StringProperty(  # type: ignore[valid-type]
        name="Command",
        description=("For a custom agent: the command that starts it in ACP mode "
                     "(e.g. `myagent --acp`)"),
        default="",
    )

    def _get_external_agent_items(self) -> list[tuple[str, str, str]]:
        from .acp_presets import PRESETS
        items = [(p.id, p.name + ("" if p.maturity == "supported" else " (preview)"),
                  " ".join(x for x in (p.account, ("Needs: " + p.install_hint) if p.install_hint else "")
                           if x)) for p in PRESETS]
        items.append(("custom", "Custom Command",
                      "Any other agent that speaks ACP (Agent Client Protocol): type the command that "
                      "starts it in ACP mode"))
        return items

    harness_preset: EnumProperty(  # type: ignore[valid-type]
        name="Harness Preset",
        description="Select an external MCP client to configure",
        items=lambda self, _context: self._get_harness_preset_items(),
        default=0,
    )

    def _get_harness_preset_items(self) -> list[tuple[str, str, str]]:
        """Return harness preset items, importing lazily to avoid circular deps."""
        from .shared import HARNESS_PRESET_ITEMS
        return HARNESS_PRESET_ITEMS

    # -- Skills (Tier 6) ------------------------------------------------

    custom_skills_text: StringProperty(  # type: ignore[valid-type]
        name="Custom Skills",
        description=(
            "Extra instructions or skills injected into every conversation.\n"
            "Use for project-specific conventions, tool preferences,\n"
            "or custom workflow rules. Markdown format supported."
        ),
        default="",
    )

    # -- Text Editor Memory Bank ----------------------------------------

    save_code_to_text_editor: BoolProperty(  # type: ignore[valid-type]
        name="Save Executed Code to Text Editor",
        description=(
            "After each successful execute_blender_code call, save the code\n"
            "to a new text datablock (Coworker_HH-MM-SS) for review and reuse"
        ),
        default=True,
    )

    # -- BYOK Provider Profiles (Tier 2) ---------------------------------

    saved_providers_json: StringProperty(  # type: ignore[valid-type]
        name="Saved Providers",
        description="JSON-serialized list of saved provider profiles",
        default="[]",
    )

    def _get_saved_providers(self) -> list[dict]:
        """Deserialize saved provider profiles from JSON."""
        import json as _json
        try:
            return _json.loads(self.saved_providers_json)
        except (_json.JSONDecodeError, TypeError):
            return []

    def _set_saved_providers(self, providers: list[dict]) -> None:
        """Serialize saved provider profiles to JSON."""
        import json as _json
        self.saved_providers_json = _json.dumps(providers)

    def _draw_effective_ports(self, box) -> None:
        """Draw the current effective port values as read-only labels."""
        bridge, mcp, llm = effective_ports(self)
        col = box.column(align=True)
        col.label(text="Effective:  Bridge {:d}  |  MCP {:d}  |  LLM {:d}  |  Speech {:d}".format(
            bridge, mcp, llm, effective_whisper_port(self)))

    # -- Diagnostics (debug only, behind flag) ---------------------------

    def _draw_diagnostics(self, layout) -> None:
        """Draw the diagnostics panel below all tabs when debug mode is enabled."""
        if not is_debug_mode():
            return
        diag_box = layout.box()
        diag_box.label(text="\U0001f6e0\ufe0f Diagnostics", icon='INFO')
        diag_box.label(
            text="Temporary debug tools -- hidden when Debug mode is off",
            icon='BLANK1',
        )
        # -- Open Log button -----------------------------------------
        diag_box.operator(
            "bfacw.open_log",
            icon='CONSOLE',
            text="Open Log",
        )
        diag_box.prop(self, "local_server_verbose")
        row = diag_box.row()
        row.operator("bfacw.check_ports", icon="FILE_REFRESH", text="Check Ports")
        row.operator("bfacw.ping_agent", icon="FILE_REFRESH", text="Diagnose")
        # Harness config preflight -- only meaningful in External Harness mode.
        if self.operating_mode == "EXTERNAL_HARNESS":
            row = diag_box.row()
            row.operator("bfacw.test_mcp_config", icon="CHECKMARK", text="Test Harness Config")
        # -- Multi-Step Test Suites ------------------------------------
        diag_box.label(text="Test Suites (multi-step artist workflows)", icon='RENDER_RESULT')
        diag_box.label(
            text="Click any step to run it (steps build on each other). "
                 "Use Reset to start over.",
            icon='BLANK1',
        )
        # Reset-on-failure keeps one bad step from corrupting the next.
        diag_box.prop(self, "reset_scene_on_failure", icon='TRASH')

        # Six core benchmarks plus three quick challenges (#104).
        _SUITE_GROUPS = (
            ("Core benchmarks", [
                ("scene",      "Scene",      'MESH_CUBE'),
                ("animation",  "Animation",  'ANIM'),
                ("modeling",   "Modeling",   'MODIFIER'),
                ("nodes",      "Nodes",      'NODETREE'),
                ("assets",     "Assets",     'ASSET_MANAGER'),
                ("vision",     "Vision",     'CAMERA_DATA'),
            ]),
            ("Quick challenges", [
                ("quick_2d",        "2D Editors", 'SEQUENCE'),
                ("quick_sanity",    "Sanity",     'CONSOLE'),
                ("quick_judgement", "Judgement",  'ERROR'),
            ]),
        )

        from . import operators_agent as _oa_suite

        for group_label, group_suites in _SUITE_GROUPS:
            diag_box.label(text=group_label, icon='DISCLOSURE_TRI_RIGHT')
            # Grid layout: 3 columns.
            grid = diag_box.grid_flow(row_major=True, columns=3, even_columns=True, even_rows=True)
            for suite_key, suite_label, suite_icon in group_suites:
                suite_box = grid.box()
                suite_header = suite_box.row()
                suite_header.label(text=suite_label, icon=suite_icon)

                # Show progress using actual suite length.
                suite = _oa_suite._TEST_SUITES.get(suite_key, [])
                total_steps = len(suite)
                step_idx = _oa_suite._test_suite_progress.get(suite_key, 0)
                suite_header.label(
                    text="Step {:d}/{:d}".format(step_idx, total_steps),
                    icon='INFO',
                )
                # Surface failures at the suite level so a broken run is obvious
                # at a glance instead of looking like a fast, successful one.
                _failed = _oa_suite._suite_failure_count(suite_key)
                if _failed:
                    suite_header.label(
                        text="{:d} failed".format(_failed),
                        icon='ERROR',
                    )

                # Step buttons in a column.
                for step_i, (s_num, s_label, _) in enumerate(suite):
                    step_row = suite_box.row(align=True)
                    is_done = step_i < step_idx
                    is_current = step_i == step_idx
                    _status = _oa_suite._test_suite_status.get((suite_key, s_num))
                    if _status == "failed":
                        step_icon = 'CANCEL'
                    elif is_done:
                        step_icon = 'CHECKBOX_HLT'
                    elif is_current:
                        step_icon = 'RADIOBUT_ON'
                    else:
                        step_icon = 'RADIOBUT_OFF'
                    op = step_row.operator(
                        "bfacw.test_step",
                        text="{:d}. {:s}".format(s_num, s_label),
                        icon=step_icon,
                    )
                    op.suite = suite_key
                    # Show elapsed time for completed steps.
                    elapsed = _oa_suite._test_suite_timings.get((suite_key, s_num))
                    if elapsed is not None:
                        step_row.label(text="{:.1f}s".format(elapsed))

                    # Show the failure reason inline.  Without this the error was
                    # only written to _agent_state.error, which this panel never
                    # displayed -- so a failed step showed nothing but a timing.
                    _err = _oa_suite._test_suite_errors.get((suite_key, s_num))
                    if _err:
                        _err_row = suite_box.row()
                        _err_row.scale_y = 0.8
                        _err_row.label(
                            text="\u26a0 {:s}".format(_err.split("\n")[0][:90]),
                            icon='ERROR',
                        )

                # Reset button at the bottom of each suite.
                reset_row = suite_box.row(align=True)
                reset_op = reset_row.operator(
                    "bfacw.test_step_reset",
                    icon='LOOP_BACK',
                    text="Reset",
                )
                reset_op.suite = suite_key

        from . import asset_selftests as _ast

        # -- Asset Tool Self-Tests (deterministic, no LLM) -------------
        selftest_box = diag_box.box()
        header = selftest_box.row()
        header.label(text="Asset Tool Self-Tests (no LLM)", icon='ASSET_MANAGER')
        header.operator(
            "bfacw.asset_selftest_run",
            icon='PLAY',
            text="Run All Auto",
        )
        header.operator(
            "bfacw.asset_selftest_reset",
            icon='LOOP_BACK',
            text="Reset",
        )
        if _ast.is_running():
            selftest_box.label(
                text="Running... (results update as steps finish)", icon='RADIOBUT_ON')
        elif _ast.last_error():
            selftest_box.label(
                text="Error: {:s}".format(_ast.last_error())[:120], icon='ERROR')
        selftest_box.label(
            text="Runs every asset tool against a throwaway fixture library -- "
                 "no MCP server or LLM needed.",
            icon='BLANK1',
        )
        for step in _ast.get_results():
            row = selftest_box.row(align=True)
            icon = 'CHECKBOX_HLT' if step.get("ok") else 'CANCEL'
            row.label(
                text=step.get("label", "?"),
                icon=icon,
            )
            row.label(
                text="{:.1f}s".format(step.get("elapsed", 0.0)),
                icon='TIME',
            )
            if step.get("detail"):
                row2 = selftest_box.row()
                row2.label(text=str(step.get("detail", ""))[:100], icon='BLANK1')

        # Manual steps (cannot be automated headless).
        man_box = selftest_box.box()
        man_box.label(text="Manual Steps (need the UI)", icon='HAND')
        for _key, m_label, m_text in _ast.MANUAL_STEPS:
            man_box.label(text="* {:s}".format(m_label), icon='BLANK1')
            man_box.label(text="    {:s}".format(m_text)[:140], icon='BLANK1')

        # Compare button for benchmark results.
        diag_box.separator()
        diag_box.operator("bfacw.compare_benchmarks", icon='FILE_REFRESH', text="Compare Results")

        # Show check_ports results inline.
        from . import operators_agent as _oa_check
        check_result = getattr(_oa_check._BFACW_OT_check_ports, "_result", None)
        if check_result:
            for label_key in [("bridge", "Bridge"), ("mcp", "MCP"), ("llm", "LLM")]:
                available = check_result.get(label_key[0], False)
                diag_box.label(
                    text="{:s}: {:s}".format(
                        label_key[1],
                        "Available" if available else "In Use",
                    ),
                    icon="CHECKMARK" if available else "ERROR",
                )
        # Show ping results inline (same as Agent Control).
        from . import operators_agent as _oa
        ping = _oa._BFACW_OT_ping_agent._result
        if ping:
            is_harness = (self.operating_mode == "EXTERNAL_HARNESS")
            status_icon = "CHECKMARK" if ping.get("all_ok") else "ERROR"
            for key, label in [
                ("bridge_server", "Bridge"),
                ("mcp_server", "MCP"),
                ("llm_health", "LLM"),
                ("llm_chat", "Chat"),
            ]:
                val = ping.get(key, "--")
                # In harness mode, N/A is not an error.
                is_ok = val.startswith("OK") or (is_harness and val.startswith("N/A"))
                diag_box.label(
                    text="{:<6s} {:s}".format(label + ":", val),
                    icon=status_icon if is_ok else "ERROR",
                )

    def draw(self, context: bpy.types.Context) -> None:
        layout = self.layout

        # -- Operating Mode selector (top-level, always visible) ---------
        # Disable while the agent is running to prevent premature stops.
        from . import agent_controller as _ac
        agent_running = _ac._agent_state.mcp_server_running

        box = layout.box()
        box.label(text="Operating Mode", icon='TOOL_SETTINGS')
        from . import ui_chat as _uc_modes
        mode_row = _uc_modes.draw_mode_switcher(box, self, full_names=True)
        if agent_running:
            mode_row.enabled = False
            box.label(
                text="Stop the agent before switching modes",
                icon='ERROR',
            )
        if self.operating_mode == "EXTERNAL_AGENT":
            from . import ui_chat as _uc
            box.label(text="Chat in Coworker; the agent app below does the work with Coworker's tools.",
                      icon='LINKED')
            _uc.draw_external_agent_setup(box, context)
        layout.separator()

        # -- Tab selector row --------------------------------------------
        row = layout.row(align=True)
        row.scale_y = 1.3
        for tab_id, tab_label, tab_icon in [
            ("LOCAL_LLM", "Local Settings", 'CONSOLE'),
            ("REMOTE_API", "Remote Settings", 'WORLD'),
            ("GENERATIVE", "Generative", 'RENDER_RESULT'),
            ("SPEECH", "Speech", 'SPEAKER'),
            ("ADVANCED", "Advanced", 'SETTINGS'),
        ]:
            # Hide irrelevant tabs based on operating mode.
            if self.operating_mode == "LOCAL_LLM" and tab_id == "REMOTE_API":
                continue
            if self.operating_mode == "REMOTE_API" and tab_id == "LOCAL_LLM":
                continue
            if self.operating_mode in ("EXTERNAL_HARNESS", "EXTERNAL_AGENT") and                     tab_id in ("LOCAL_LLM", "REMOTE_API"):
                continue
            is_active = (self.pref_tab == tab_id)
            op = row.operator(
                "bfacw.pref_tab_select",
                text=tab_label,
                icon=tab_icon,
                depress=is_active,
            )
            op.tab_id = tab_id

        layout.separator()

        # -- Draw the active tab -----------------------------------------
        if self.pref_tab == 'LOCAL_LLM':
            if self.operating_mode == "LOCAL_LLM":
                self._draw_tab_local_llm(context)
            else:
                self.pref_tab = "ADVANCED"
        elif self.pref_tab == 'REMOTE_API':
            if self.operating_mode == "REMOTE_API":
                self._draw_tab_remote_api(context)
            else:
                self.pref_tab = "ADVANCED"
        elif self.pref_tab == 'GENERATIVE':
            self._draw_tab_generative_ai(context)
        elif self.pref_tab == 'SPEECH':
            self._draw_tab_speech(context)
        elif self.pref_tab == 'ADVANCED':
            self._draw_tab_advanced(context)

        # -- Diagnostics (debug only, behind flag) -----------------------
        self._draw_diagnostics(layout)

    # -- Tab: Local LLM -------------------------------------------------

    def _draw_tab_local_llm(self, context: bpy.types.Context) -> None:
        del context
        layout = self.layout

        # -- LLM Configuration (Local mode only) ------------------------
        box = layout.box()
        box.label(text="1. Configure Local LLM Backend", icon='CONSOLE')

        # -- llama-server source toggle ----------------------------
        #   Bundled -- the addon downloads & manages its own copy.
        #   Custom  -- you provide your own llama.cpp build; the addon
        #             never modifies or updates it.
        box.prop(self, "llama_source", expand=True)

        llm = get_llm_manager()
        llm_state = llm.get_state()

        if self.llama_source == "CUSTOM":
            # -- Custom (user-provided) binary ----------------------
            box.prop(self, "llama_path", text="Path")
            llama_found = llm.find_llama_server()
            # Validate that the cached result still exists on disk;
            # an external uninstall or file move would leave stale cache.
            if llama_found and not os.path.isfile(llama_found):
                llm.invalidate_llama_server_cache()
                llama_found = llm.find_llama_server()
            row = box.row(align=True)
            if llama_found:
                _ver = llm._llama_server_version(llama_found)
                _build = llm._parse_llama_build_number(_ver)
                _build_str = "build {:d}".format(_build) if _build else "unknown build"
                row.label(
                    text="llama-server: Found ({:s})".format(_build_str),
                    icon='CHECKMARK',
                )
                # Show path and open-folder button for custom binary.
                _path_row = box.row(align=True)
                _path_row.label(
                    text="Location: {:s}".format(llama_found),
                    icon='FILE_FOLDER',
                )
                _path_row.operator(
                    "bfacw.open_llama_server_folder",
                    icon='FILE_FOLDER',
                    text="Open Folder",
                )
            else:
                row.label(
                    text="llama-server: Not found -- check the path above",
                    icon='ERROR',
                )
                _problem = llm.llama_custom_problem()
                if _problem:        # say why (#382): no such file, no llama-server in that folder...
                    box.label(text=_problem[:1].upper() + _problem[1:])
            box.label(
                text="Your custom binary -- the addon will not modify or update it.",
                icon='INFO',
            )
        else:
            # -- Bundled (addon-managed) binary ---------------------
            llama_found = llm.find_llama_server()
            # Validate that the cached result still exists on disk;
            # an external uninstall or file move would leave stale cache.
            if llama_found and not os.path.isfile(llama_found):
                llm.invalidate_llama_server_cache()
                llama_found = llm.find_llama_server()
            row = box.row(align=True)
            if llama_found:
                # Check version - warn if too old for Qwen3 SSM models.
                _ver = llm._llama_server_version(llama_found)
                _build = llm._parse_llama_build_number(_ver)
                _outdated = _build and _build < llm._MIN_SUPPORTED_BUILD
                # Detect source: bundled vs PATH/System.
                _bundled_dir = str(llm._get_bundled_llama_dir())
                _is_bundled = llama_found.startswith(_bundled_dir)
                _source = "bundled" if _is_bundled else "system"
                if _outdated:
                    row = box.row(align=True)
                    row.label(
                        text="OUTDATED -- build {:d} (min {:d}) [{:s}]".format(
                            _build, llm._MIN_SUPPORTED_BUILD, _source),
                        icon='ERROR',
                    )
                    row.operator(
                        "bfacw.download_llama_server",
                        icon="FILE_REFRESH",
                        text="Update",
                    ).force = True
                    row.operator(
                        "bfacw.remove_llama_server",
                        icon="TRASH",
                        text="Remove",
                    )
                elif not _build:
                    # Unknown build -- the version string could not be
                    # parsed. Offer Update so the user can force a fresh
                    # download instead of being stuck with no way forward.
                    row = box.row(align=True)
                    row.label(
                        text="llama-server: Installed (unknown build, {:s})".format(_source),
                        icon=safe_icon('WARNING'),
                    )
                    row.operator(
                        "bfacw.download_llama_server",
                        icon="FILE_REFRESH",
                        text="Update",
                    ).force = True
                    row.operator(
                        "bfacw.remove_llama_server",
                        icon="TRASH",
                        text="Remove",
                    )
                else:
                    row = box.row(align=True)
                    row.label(
                        text="llama-server: Installed (build {:d}, {:s})".format(_build, _source),
                        icon='CHECKMARK',
                    )
                    row.operator(
                        "bfacw.remove_llama_server",
                        icon="TRASH",
                        text="Remove",
                    )
                    if not _is_bundled:
                        # PATH binary: offer to override with bundled version.
                        row.operator(
                            "bfacw.download_llama_server",
                            icon="IMPORT",
                            text="Override",
                        ).force = True
                # Show the detected path and a button to open the folder.
                _path_row = box.row(align=True)
                _path_row.label(
                    text="Location: {:s}".format(llama_found),
                    icon='FILE_FOLDER',
                )
                _path_row.operator(
                    "bfacw.open_llama_server_folder",
                    icon='FILE_FOLDER',
                    text="Open Folder",
                )
            else:
                row = box.row(align=True)
                row.label(text="llama-server: Not installed", icon='ERROR')
                row.operator(
                    "bfacw.download_llama_server",
                    icon="IMPORT",
                    text="Download",
                )
                # Show the bundled directory so the user knows where it
                # will be installed.
                box.label(
                    text="Install to: {:s}".format(str(llm._get_bundled_llama_dir())),
                    icon='FILE_FOLDER',
                )
            # GPU backend selector -- disabled while agent is running
            # (changing backend requires restarting llama-server).
            from . import agent_controller as _ac_backend
            _backend_row = box.row()
            _backend_row.prop(self, "llama_backend")
            if _ac_backend._agent_state.mcp_server_running:
                _backend_row.enabled = False
            # Unified progress block for llama-server download.
            if llm_state.download_kind == "llama_server":
                if llm_state.download_progress:
                    box.label(
                        text=llm_state.download_progress,
                        icon=_download_status_icon(llm_state.download_progress),
                    )
                pct = llm_state.download_progress_pct
                if pct > 0:
                    row = box.row(align=True)
                    row.progress(factor=pct / 100.0, type='BAR')
                if llm_state.download_active:
                    row = box.row(align=True)
                    # Icon-only (text="") -- the operator's bl_label shows as tooltip.
                    row.operator("bfacw.cancel_download", icon='CANCEL', text="")

        # -- Model Selection (restructured) --------------------------------
        # Primary model family: Qwen3.8-27B with quant tiers
        box.label(text="2. Pick a Large Language Model", icon='VIEWZOOM')

        # System info
        import platform
        try:
            import psutil
            ram_gb = psutil.virtual_memory().total / (1024**3)
        except ImportError:
            ram_gb = 0
        sys_info = "{:.0f} GB RAM".format(ram_gb) if ram_gb > 0 else ""
        if self.llama_backend == "cuda":
            sys_info += " * CUDA"
        elif self.llama_backend == "vulkan":
            sys_info += " * Vulkan"
        elif self.llama_backend == "metal":
            sys_info += " * Metal"
        if sys_info:
            box.label(text=sys_info, icon='INFO')

        # Primary family header
        pri_box = box.box()
        pri_box.label(
            text="Recommended -- Qwen3.8-27B (vision + agentic)",
            icon='HIDE_OFF',
        )

        all_presets = llm.get_presets()
        primary_ids = ["qwen38_27b_q4", "qwen38_27b_q8"]
        primary_presets = [p for p in all_presets if p.identifier in primary_ids]

        for preset in primary_presets:
            row = pri_box.row(align=True)
            is_active = self.model_preset == preset.identifier
            icon = 'IMAGE_DATA' if preset.vision else 'VIEWZOOM'
            op = row.operator(
                "bfacw.select_preset",
                text=preset.name,
                icon=icon,
                depress=is_active,
            )
            op.preset_id = preset.identifier
            col = row.column(align=True)
            col.scale_y = 0.8
            col.label(text="| {:s}".format(preset.hardware_note))
            col.label(text="- {:s}".format(preset.why))

        pri_box.label(
            text="Vision is built-in with these models and downloaded additionally",
            icon='INFO',
        )

        # -- More Models (collapsible) -------------------------------------
        more_box = pri_box.box()
        more_box.prop(
            self,
            "show_more_models",
            text="More Models (curated presets)",
            icon='TRIA_DOWN' if self.show_more_models else 'TRIA_RIGHT',
            emboss=True,
        )
        if self.show_more_models:
            more_presets = [p for p in all_presets if p.identifier not in primary_ids]
            _MORE_CATEGORIES = [
                ("flagship", "Flagship", 'SORT_ASC'),
                ("mid_range", "Mid-Range", 'VIEWZOOM'),
                ("lightweight", "Lightweight", 'LIGHT_SUN'),
            ]
            for cat_id, cat_label, cat_icon in _MORE_CATEGORIES:
                cat_presets = [p for p in more_presets if p.category == cat_id]
                if not cat_presets:
                    continue
                more_box.label(text=cat_label, icon=cat_icon)
                for preset in cat_presets:
                    row = more_box.row(align=True)
                    icon = 'IMAGE_DATA' if preset.vision else 'VIEWZOOM'
                    op = row.operator(
                        "bfacw.select_preset",
                        text=preset.name,
                        icon=icon,
                        depress=self.model_preset == preset.identifier,
                    )
                    op.preset_id = preset.identifier
                    col = row.column(align=True)
                    col.scale_y = 0.8
                    col.label(text="| {:s}".format(preset.hardware_note))
                    col.label(text="- {:s}".format(preset.why))

        # -- Or use a local file -------------------------------------------
        local_box = box.box()
        local_box.label(text="3. Set the downloaded location", icon='FILE_FOLDER')
        row = local_box.row(align=True)
        row.label(
            text="This is where you will store the downloaded or select an existing GGUF file. ",
            icon='INFO',
        )
        row = local_box.row(align=True)
        row.operator("bfacw.scan_existing_models", icon="FILE_REFRESH", text="Scan Folder")
        row.operator("bfacw.open_models_dir", icon="FILE_FOLDER", text="Open Folder")
        local_box.prop(self, "downloaded_models_dir")
        if self.existing_model_path:
            local_box.label(
                text="Selected: {:s}".format(os.path.basename(self.existing_model_path)),
                icon='CHECKMARK',
            )

        # -- Custom model entry --------------------------------------------
        local_box.prop(self, "model_preset", text="Your Selected Model Preset")
        local_box.label(text="This defines what will download, either a preset, or custom Hugging Face model", icon='INFO')
        if self.model_preset != "_custom" and self.model_preset_info:
            info_box = local_box.box()
            info_box.label(text="Model Preset Information", icon='INFO')
            # Generated now, not the text saved when it was picked (#558).
            _preset = llm.get_preset_by_id(self.model_preset)
            _info = llm.preset_info_text(_preset) if _preset is not None else self.model_preset_info
            for line in _info.split("\n"):
                info_box.label(text=line)
        else:
            info_box = local_box.box()
            info_box.label(text="Custom Hugging Face model to download", icon='INFO')
            info_box.prop(self, "model_repo_id")
            info_box.prop(self, "model_filename")


        # -- Download current preset ---------------------------------------
        llm_state = llm.get_state()
        models_dir = Path(self.downloaded_models_dir) if self.downloaded_models_dir else (Path.home() / "bfa_coworker_models")
        model_file = models_dir / self.model_filename if self.model_filename else None
        model_exists = model_file and model_file.exists()

        if llm_state.download_active:
            btn_text = "Downloading ..."
            btn_icon = 'FILE_REFRESH'
            btn_enabled = False
        elif model_exists:
            btn_text = "Already Downloaded"
            btn_icon = 'CHECKMARK'
            btn_enabled = False
        elif llm_state.is_running:
            btn_text = "Model Running"
            btn_icon = 'CONSOLE'
            btn_enabled = False
        else:
            btn_text = "4. Download Model"
            btn_icon = "IMPORT"
            btn_enabled = True

        dl_row = box.row(align=True)
        dl_row.scale_y = 1.8
        dl_row.operator("bfacw.download_model", icon=btn_icon, text=btn_text)
        if not btn_enabled:
            dl_row.enabled = False

        if llm_state.download_active and llm_state.download_kind == "model" and llm_state.download_progress_pct <= 0:
            cancel_row = box.row(align=True)
            cancel_row.operator("bfacw.cancel_download", icon='CANCEL', text="")

        if llm_state.download_kind == "model":
            if llm_state.error:
                err_lines = llm_state.error.split("\n")
                for i, line in enumerate(err_lines):
                    box.label(text=line, icon="ERROR" if i == 0 else 'NONE')
            if llm_state.download_progress:
                prog_text = llm_state.download_progress
                if llm_state.download_progress_eta:
                    prog_text = "{:s}  |  {:s}".format(prog_text, llm_state.download_progress_eta)
                box.label(
                    text=prog_text,
                    icon=_download_status_icon(llm_state.download_progress),
                )
                pct = llm_state.download_progress_pct
                if pct > 0:
                    row = box.row(align=True)
                    row.progress(factor=pct / 100.0, type='BAR')
                    if llm_state.download_active:
                        row.operator("bfacw.cancel_download", icon='CANCEL', text="")


        # -- Advanced Settings ------------------------------------------------
        box.label(text="Advanced", icon='SETTINGS')
        # -- Context Window ------------------------------------------------
        ctx_box = box.box()
        ctx_box.label(
            text="Context Window (how much the model remembers per reply)",
            icon='MEMORY',
        )
        # The window (and the KV-cache quantization) is fixed when
        # llama-server loads the model; changing it while the model runs
        # would silently disagree with the server.  Lock the controls while
        # it runs and offer the one action that applies a change.
        _model_loaded = bool(getattr(llm_state, "is_running", False))
        if _model_loaded:
            lock_row = ctx_box.row(align=True)
            lock_row.label(
                text="Fixed while the model is loaded -- stop it to change",
                icon='LOCKED',
            )
            lock_row.operator("bfacw.stop_llm", text="Stop Model", icon='PAUSE')
        row = ctx_box.row(align=True)
        row.enabled = not _model_loaded
        active_ctx = self.local_ctx_size
        is_custom = (self.local_ctx_preset == "custom") or (
            active_ctx not in llm.ctx_preset_sizes)
        for value in llm.ctx_preset_sizes:
            op = row.operator(
                "bfacw.set_ctx_preset",
                text=llm.ctx_preset_label(value),
                depress=(active_ctx == value),
            )
            op.value = value
        op = row.operator(
            "bfacw.set_ctx_preset",
            text="Custom",
            depress=is_custom,
        )
        op.value = 0
        if is_custom:
            _custom_row = ctx_box.row()
            _custom_row.enabled = not _model_loaded
            _custom_row.prop(self, "local_ctx_size")
        _preset = llm.get_preset_by_id(self.model_preset)
        model_gb = self._current_model_gb(_preset)
        _sizing = self._model_sizing_kwargs(_preset)
        ctx_box.label(
            text=llm.hardware_context_hint(model_gb, self.llama_backend, **_sizing),
            icon='INFO',
        )
        # Startup-only hardware validation (Tier 3 Phase 2, D4): warn when
        # the chosen context cannot hold the first request, or the server
        # would not fit the free memory (#543).
        _ctx_warning = llm.validate_ctx_against_hardware(
            model_gb, self.llama_backend, self.local_ctx_size, **_sizing)
        if _ctx_warning:
            ctx_box.label(text="Context may not fit your hardware:", icon='ERROR')
            for _wline in _ctx_warning.split("\n"):
                ctx_box.label(text=_wline, icon='BLANK1')
        # KV-cache quantization -- pairs with the context size choice.
        if self.llama_backend != "cpu":
            _kv_row = ctx_box.row()
            _kv_row.enabled = not _model_loaded
            _kv_row.prop(self, "local_kv_cache_quant")

        # -- Reasoning Effort (next to the Context Window row) -------
        ctx_box.separator()
        ctx_box.label(
            text="Reasoning Effort (how hard the model thinks per reply)",
            icon='SOLO_ON',
        )
        ctx_box.label(
            text="Sent with every request -- change it any time (also in the "
                 "chat panel); it applies from your next message.",
            icon='INFO',
        )
        row = ctx_box.row(align=True)
        row.prop(self, "reasoning_effort", expand=True)
        if self.reasoning_effort == "custom":
            ctx_box.prop(self, "thinking_budget_tokens")
        _budget = self.thinking_budget_tokens
        ctx_box.label(
            text="Current: {:s}".format(
                "no cap -- the model thinks freely" if _budget <= 0
                else "{:d} tokens of thinking per reply".format(_budget)),
            icon='BLANK1',
        )

        # -- Startup / runtime errors --------------------------------------
        if llm_state.error and llm_state.download_kind != "model":
            err_lines = llm_state.error.split("\n")
            for i, line in enumerate(err_lines):
                box.label(text=line, icon="ERROR" if i == 0 else 'NONE')

        # -- Current model status ------------------------------------------
        if llm_state.is_running:
            box.label(
                text="Active model: {:s}".format(llm_state.model_name or "Unknown"),
                icon='CONSOLE',
            )


        box.separator()
        box.prop(self, "local_max_tokens")
        box.prop(self, "hf_token")

    # -- Tab: Remote API ------------------------------------------------

    def _draw_tab_remote_api(self, context: bpy.types.Context) -> None:
        del context
        layout = self.layout

        # -- Remote API Configuration ------------------------------------
        box = layout.box()
        box.label(text="Remote API Configuration", icon='WORLD')

        llm = get_llm_manager()

        # -- Remote Provider -------------------------------------
        box.label(text="Provider", icon='WORLD')
        box.prop(self, "remote_provider")

        # Show provider description when a known provider is selected.
        if self.remote_provider != "_custom":
            provider = llm.get_remote_provider_by_id(self.remote_provider)
            if provider is not None:
                for line in provider.description.split("\n"):
                    box.label(text=line, icon='INFO')

        # -- API URL & Key ---------------------------------------
        box.prop(self, "remote_api_url")
        box.prop(self, "remote_api_key")
        # Where the key goes (#346): the settings backup keeps it, privately; logs never do.
        box.label(text="Shown as *** in logs and copies. The settings backup keeps it, readable by you only.",
                  icon='LOCKED')

        row = box.row(align=True)
        row.label(text="API Key Help:", icon='HELP')
        if self.remote_provider != "_custom":
            provider = llm.get_remote_provider_by_id(self.remote_provider)
            if provider is not None:
                row.label(text=provider.api_key_help)
            else:
                row.label(text="Enter your API key for the remote service")
        else:
            row.label(text="Enter your API key for the remote service")

        # -- Model -----------------------------------------------
        box.label(text="Model", icon='VIEWZOOM')
        box.prop(self, "remote_model")
        box.prop(self, "remote_accepts_images")
        row = box.row(align=True)
        row.operator("bfacw.refresh_remote_models", icon="FILE_REFRESH", text="Refresh Models")
        row.operator("bfacw.open_model_browser", icon="URL", text="Browse Models")

        # Show fetch status.
        if self.remote_models_count > 0:
            box.label(
                text="{:d} models available from the API".format(self.remote_models_count),
                icon='CHECKMARK',
            )
        if self.remote_models_fetch_error:
            box.label(text=self.remote_models_fetch_error, icon='ERROR')

        # -- Test Connection -------------------------------------
        row = box.row()
        row.operator("bfacw.test_remote_api", icon="URL")

        # -- Saved Provider Profiles (BYOK, Tier 2) --------------
        box.separator()
        box.label(text="Saved Provider Profiles", icon='BOOKMARKS')
        providers = self._get_saved_providers()
        if providers:
            for p in providers:
                row = box.row(align=True)
                op = row.operator(
                    "bfacw.load_provider",
                    text="{:s} ({:s})".format(p.get("name", "?"), p.get("model", "?")),
                    icon='FILE_TICK',
                )
                op.profile_name = p.get("name", "")
                op = row.operator(
                    "bfacw.delete_provider",
                    text="",
                    icon='X',
                )
                op.profile_name = p.get("name", "")
        else:
            box.label(text="No saved profiles. Configure above and save.", icon='INFO')
        row = box.row()
        row.operator("bfacw.save_provider", icon="ADD", text="Save Current as Profile")

    # -- Tab: Generative ---------------------------------------------

    def _draw_tab_generative_ai(self, context: bpy.types.Context) -> None:
        del context
        layout = self.layout

        # -- Generation (Tier 5) ----------------------------------------
        gen_box = layout.box()
        gen_box.label(text="Generative (Image / Video / Audio)", icon='RENDER_RESULT')
        gen_box.label(text="Experimental (WIP)", icon=safe_icon('WARNING'))
        gen_box.prop(self, "gen_backend")

        if self.gen_backend == "local":
            gen_box.label(
                text="Models are downloaded from HuggingFace on first use.",
                icon='INFO',
            )
            gen_box.prop(self, "gen_auto_download")
            gen_box.prop(self, "gen_models_dir")
            gen_box.prop(self, "gen_output_dir")

            # Show available plugins.
            try:
                from .gen_plugins import get_plugins_by_type
                for mtype, label, icon in [
                    ("image", "Image Models", 'IMAGE_DATA'),
                    ("video", "Video Models", 'SEQUENCE'),
                    ("audio", "Audio Models", 'SPEAKER'),
                    ("text", "Text Models", 'TEXT'),
                ]:
                    plugins = get_plugins_by_type(mtype)
                    if plugins:
                        gen_box.label(
                            text="{:s}: {:d} available".format(label, len(plugins)),
                            icon=icon,
                        )
            except Exception:
                pass

        elif self.gen_backend == "pallaidium":
            gen_box.label(
                text="Pallaidium addon must be installed and enabled separately.",
                icon='INFO',
            )
            gen_box.label(
                text="Models will be discovered from Pallaidium's plugin registry.",
                icon='BLANK1',
            )

        elif self.gen_backend == "comfyui":
            gen_box.prop(self, "gen_comfyui_url")
            gen_box.label(
                text="ComfyUI must be running with API enabled.",
                icon='INFO',
            )

        elif self.gen_backend == "remote":
            gen_box.prop(self, "gen_remote_url")
            gen_box.prop(self, "gen_remote_key")

        # -- Poly Haven Asset Download (Tier 1) ------------------------
        ph_box = layout.box()
        ph_box.label(text="Poly Haven Asset Download", icon='WORLD')
        ph_box.label(
            text="Download free CC0 HDRIs, textures, and models from Poly Haven.",
            icon='INFO',
        )
        # Resolution selector.
        ph_row = ph_box.row(align=True)
        ph_row.prop(self, "polyhaven_resolution", text="Resolution")
        # Test buttons.
        row = ph_box.row(align=True)
        row.operator("bfacw.test_polyhaven_hdri", icon='WORLD', text="Download Test HDRI")
        row.operator("bfacw.test_polyhaven_texture", icon='TEXTURE', text="Download Test Texture")

    # -- Tab: Speech (#375) ---------------------------------------------

    def _draw_tab_speech(self, context: bpy.types.Context) -> None:
        """Speech to text: whisper-server download, model, device, language, start / stop."""
        del context
        from . import whisper_manager as wm
        layout = self.layout
        st = wm.get_state()

        box = layout.box()
        box.label(text="Speech to Text (whisper.cpp)", icon='SPEAKER')
        box.label(text="Transcribes Sequencer strips on this computer: the audio never leaves it.", icon='INFO')

        def lines(col, text: str, icon: str = 'NONE') -> None:
            for i, line in enumerate(str(text).splitlines()[:6]):
                col.label(text=line[:160], icon=icon if i == 0 else 'BLANK1')

        def progress(col, kind: str) -> None:
            if st.download_active and st.download_kind == kind:
                lines(col, st.download_text, 'IMPORT')
                row = col.row(align=True)
                row.progress(factor=max(0.0, min(1.0, st.download_pct / 100.0)), type='BAR',
                             text="{:.0f}%".format(st.download_pct))
                row.operator("bfacw.speech_cancel_download", text="Cancel", icon='CANCEL')

        problem = wm.platform_problem()
        if problem:
            lines(box, problem, 'ERROR')
        else:
            # 1. The server
            sub = box.box()
            sub.label(text="1. Speech Server", icon='CONSOLE')
            sub.row().prop(self, "speech_device", expand=True)
            nvidia = wm.nvidia_found()
            if self.speech_device == "AUTO":
                sub.label(text={True: "Auto: CUDA (an NVIDIA GPU was found), with the CPU build as a fallback",
                                False: "Auto: the CPU (no NVIDIA GPU found)",
                                None: "Auto: looking for an NVIDIA GPU ..."}[nvidia])
            installed = wm.installed_builds()
            if installed:
                names = []
                for b in installed:
                    tag = wm.build_info(b).get("tag") or "existing files"
                    names.append("{:s} ({:s})".format(wm.BUILD_LABELS[b], tag))
                sub.label(text="whisper-server: " + ", ".join(names), icon='CHECKMARK')
            missing = wm.builds_to_download(self.speech_device, bool(nvidia))
            if missing and not (st.download_active and st.download_kind == "server"):
                row = sub.row(align=True)
                row.label(text="Not downloaded: " + ", ".join(
                    "{:s} ({:s})".format(wm.BUILD_LABELS[b], "9 MB" if b == "cpu" else "690 MB") for b in missing),
                    icon='ERROR' if not installed else 'INFO')
                row.operator("bfacw.speech_download_server", text="Download", icon='IMPORT')
            if installed or missing:
                row = sub.row(align=True)
                row.label(text="Folder: {:s}".format(str(wm.data_dir())), icon='FILE_FOLDER')
                row.operator("bfacw.speech_open_folder", text="Open Folder", icon='FILE_FOLDER')
            progress(sub, "server")

            # 2. The model
            build = wm.resolve_build(self.speech_device, bool(nvidia))
            chosen = wm.resolve_model(self.speech_model, build)
            sub = box.box()
            sub.label(text="2. Model", icon='OUTLINER_DATA_SPEAKER')
            sub.prop(self, "speech_model")
            col = sub.column(align=True)
            for preset in wm.MODEL_PRESETS:
                status = wm.model_status(preset.identifier)
                row = col.row(align=True)
                split = row.split(factor=0.34, align=True)
                split.label(text="{:s}  {:s}{:s}".format(
                    preset.label, wm._fmt_bytes(preset.size), "  (in use)" if preset.identifier == chosen else ""),
                    icon='CHECKMARK' if status == "ready" else 'BLANK1')
                rest = split.row(align=True)
                rest.label(text=preset.note if status != "incomplete" else "Incomplete: download it again")
                if status != "ready":
                    op = rest.operator("bfacw.speech_download_model", text="Download", icon='IMPORT')
                    op.model_id = preset.identifier
                    rest.enabled = not st.download_active
            progress(sub, "model")
            if not st.download_active and st.download_text:
                lines(sub, st.download_text, 'ERROR' if st.error else 'INFO')

            # 3. Language
            sub = box.box()
            sub.label(text="3. Language", icon='FILE_TEXT')
            sub.prop(self, "speech_language")
            sub.prop(self, "speech_prompt")

            # 4. Start / stop
            sub = box.box()
            sub.label(text="4. Server", icon='PLAY')
            running = st.proc is not None and st.proc.poll() is None
            row = sub.row(align=True)
            if running:
                row.label(text=st.status_text or "Running", icon='CHECKMARK' if st.ready else 'SORTTIME')
                row.operator("bfacw.speech_stop", text="Stop", icon='CANCEL')
            else:
                row.label(text="Stopped (it starts by itself when a strip is transcribed)", icon='X')
                row.operator("bfacw.speech_start", text="Start", icon='PLAY')
            if st.error and not st.download_text:
                lines(sub, st.error, 'ERROR')

        # Remote
        rbox = layout.box()
        rbox.label(text="Remote", icon='WORLD')
        rbox.prop(self, "speech_use_remote")
        if self.speech_use_remote:
            rbox.prop(self, "speech_remote_model")
            rbox.label(text="Sends the audio to {:s} (/v1/audio/transcriptions, the Remote API key).".format(
                self.remote_api_url or "the Remote API URL"), icon='INFO')
            rbox.label(text="Only providers with an OpenAI-compatible transcription endpoint support this.",
                       icon='BLANK1')

    # -- Tab: Advanced --------------------------------------------------

    def _draw_updates(self, layout: bpy.types.UILayout) -> None:
        """Where updates come from: the Coworker extension repository (#86)."""
        from .shared import UPDATE_REPO_URL, update_repo_of_this_install
        from . import addon_version
        box = layout.box()
        box.label(text="Updates -- Coworker {:s}".format(addon_version() or ""), icon='FILE_REFRESH')
        repo = update_repo_of_this_install()
        col = box.column(align=True)
        if repo is not None:
            col.label(text="Automatic: installed from the \"{:s}\" repository".format(repo.name), icon='CHECKMARK')
            sub = col.column(align=True)
            sub.scale_y = 0.8
            sub.label(text="New versions show up in Get Extensions; use Check for Updates there.")
            if not repo.use_sync_on_startup:
                sub.label(text="Tip: enable \"Check for Updates on Startup\" for that repository.", icon='INFO')
        else:
            col.label(text="Off: this copy was installed from a file", icon='INFO')
            sub = col.column(align=True)
            sub.scale_y = 0.8
            sub.label(text="Install the Coworker Installer (one download from the Releases page),")
            sub.label(text="or add this repository in Get Extensions > Repositories > Add Remote:")
            row = box.row(align=True)
            row.label(text=UPDATE_REPO_URL)
            row.operator("bfacw.copy_update_url", text="", icon='COPYDOWN')

    def _draw_tab_advanced(self, context: bpy.types.Context) -> None:
        del context
        layout = self.layout

        # -- Mode hint --------------------------------------------------
        mode_labels = {
            "LOCAL_LLM": "Local LLM mode -- some settings are hidden",
            "REMOTE_API": "Remote API mode -- some settings are hidden",
            "EXTERNAL_HARNESS": "External Harness mode -- some settings are hidden",
        }
        hint = mode_labels.get(self.operating_mode, "")
        if hint:
            hint_row = layout.row()
            hint_row.label(text=hint, icon='INFO')
            hint_row.scale_y = 0.6

        # -- Updates (issue #86) ---------------------------------------
        self._draw_updates(layout)

        # -- Bridge Server (always visible) ----------------------------
        bridge_box = layout.box()
        bridge_box.label(text="Bridge Server", icon='NETWORK_DRIVE')
        bridge_box.prop(self, "host")
        bridge_box.prop(self, "port")
        from . import mcp_to_blender_server as _mbs
        if _mbs.is_running():
            _bridge_port, _, _ = effective_ports(self)
            bridge_box.label(
                text="Status: Running on {:s}:{:d}".format(self.host, _bridge_port),
                icon='CHECKMARK',
            )
        else:
            bridge_box.label(text="Status: Stopped", icon='X')
        bridge_box.prop(self, "require_session_token")
        bridge_box.prop(self, "approval_mode")       # also on the chat's input row (#240)

        # -- MCP Server (External Harness mode only) ----------------
        if self.operating_mode == "EXTERNAL_HARNESS":
            mcp_box = layout.box()
            mcp_box.label(text="MCP Server (External Harness)", icon='SETTINGS')
            mcp_box.prop(self, "mcp_server_mode", expand=True)

            if self.mcp_server_mode == "STDIO":
                # -- Step 1: Pick your harness ---------------------------
                step1 = mcp_box.box()
                step1.label(text="Step 1: Pick your MCP client", icon='FORWARD')
                step1.prop(self, "harness_preset", text="")

                # Show a short info line about the selected preset.
                from .shared import get_harness_preset_by_id
                preset = get_harness_preset_by_id(self.harness_preset)
                if preset is not None:
                    row = step1.row(align=True)
                    row.label(text=preset.description, icon='INFO')
                    if preset.docs_url:
                        row.operator("bfacw.open_url", icon='URL', text="Docs").url = preset.docs_url

                # -- Step 2: Copy the config -----------------------------
                step2 = mcp_box.box()
                step2.label(text="Step 2: Copy the config", icon='COPYDOWN')
                row = step2.row(align=True)
                op = row.operator("bfacw.copy_mcp_config", icon="COPYDOWN", text="Copy to Clipboard")
                op.client_type = self.harness_preset
                row.operator("bfacw.test_mcp_config", icon="CHECKMARK", text="Test Config")
                from . import harness_clients
                if preset is not None and harness_clients.can_install(self.harness_preset):
                    op = step2.operator(
                        "bfacw.install_client_config", icon="IMPORT",
                        text="Add to {:s}".format(preset.name))
                    op.client_type = self.harness_preset
                    step2.label(
                        text="Writes the client's config file directly (backup kept) -- no copy/paste needed.",
                        icon='BLANK1',
                    )
                step2.label(
                    text="This copies the connection settings for your selected client.",
                    icon='BLANK1',
                )
                step2.label(
                    text="Test Config verifies the interpreter, PYTHONPATH and imports first.",
                    icon='BLANK1',
                )

                # Show the last validation result, if any.
                from . import operators_agent as _oa_cfg
                # Reuse the chat panel's multiline renderer: it feature-detects
                # Blender 5.3's native UILayout.label_multiline (which wraps to
                # the real layout width) and only falls back to character-based
                # wrapping on builds that lack the API.
                from .ui_chat import _draw_multiline
                _cfg_check = _oa_cfg.BFACW_OT_test_mcp_config._result
                if _cfg_check:
                    if _cfg_check.get("ok"):
                        _icon = 'CHECKMARK'
                        if _cfg_check.get("bridge_ok") is False:
                            _icon = 'INFO'
                    else:
                        _icon = 'ERROR'
                    step2.label(
                        text=_cfg_check.get("summary", ""),
                        icon=_icon,
                    )
                    if not _cfg_check.get("ok") and _cfg_check.get("hint"):
                        _draw_multiline(step2, _cfg_check["hint"])
                    _installed = _cfg_check.get("installed") or {}
                    if _installed.get("summary"):
                        step2.label(
                            text=_installed["summary"],
                            icon='ERROR' if _installed.get("problems") else 'CHECKMARK',
                        )
                        for _problem in _installed.get("problems", [])[1:]:
                            _draw_multiline(step2, _problem)
                    if _cfg_check.get("stderr_tail"):
                        _tail_box = step2.box()
                        _tail_box.label(text="Server output (last lines):", icon='CONSOLE')
                        _draw_multiline(
                            _tail_box,
                            "\n".join(_cfg_check["stderr_tail"].splitlines()[-8:]),
                        )

                # -- Step 3: Configure your client ---------------------------
                step3 = mcp_box.box()
                step3.label(text="Step 3: Configure your client (Add to client, settings UI, or config file)", icon='FILE_TEXT')
                step3.label(
                    text="Config file locations can vary per system and client version.",
                    icon='BLANK1',
                )
                if preset is not None and preset.config_path_help:
                    for line in preset.config_path_help.split("\n"):
                        step3.label(text=line, icon='FILE_FOLDER')
                if preset is not None and preset.chat_paste_hint:
                    step3.label(
                        text="Tip: {:s}".format(preset.chat_paste_hint),
                        icon='INFO',
                    )
                step3.label(
                    text="If you edit the file yourself, merge the copied entry into the existing",
                    icon='INFO',
                )
                step3.label(
                    text="servers section -- don't replace the whole file.",
                    icon='BLANK1',
                )

                # -- Step 4: Restart -------------------------------------
                step4 = mcp_box.box()
                step4.label(text="Step 4: Restart your MCP client", icon='LOOP_BACK')
                step4.label(
                    text="Close and re-open your MCP client completely. "
                         "A window close is not enough on some apps.",
                    icon='BLANK1',
                )
                if preset is not None and preset.notes:
                    step4.label(text="\u2139\ufe0f {:s}".format(preset.notes), icon='INFO')
                # -- Detailed setup for this client ----------------------------
                if preset is not None and preset.setup_steps:
                    setup_box = mcp_box.box()
                    setup_box.label(text="Detailed setup for this client:", icon='PLAY')
                    for i, step in enumerate(preset.setup_steps, 1):
                        setup_box.label(
                            text="{:d}. {:s}".format(i, step),
                            icon='DOT',
                        )

                # -- Advanced options --------------------------------------
                adv_box = mcp_box.box()
                adv_box.label(text="Advanced Options", icon='SETTINGS')
                adv_box.prop(self, "use_blender_python_for_harness")

                # Config preview.
                adv_box.label(text="Config Preview:", icon='COPYDOWN')
                from . import agent_controller as _ac
                _bridge_port, _, _ = effective_ports(self)
                preview = _ac.generate_mcp_client_config(
                    client_type=self.harness_preset,
                    blender_host=self.host,
                    blender_port=_bridge_port,
                    use_blender_python=self.use_blender_python_for_harness,
                )
                for line in preview.split("\n"):
                    adv_box.label(text=line, icon='BLANK1')

            elif self.mcp_server_mode == "NETWORK":
                mcp_box.prop(self, "mcp_server_host")
                mcp_box.prop(self, "mcp_server_port_override")
                if self.mcp_server_host not in ("127.0.0.1", "localhost", "::1"):
                    mcp_box.label(
                        text="\u26a0 Binding to non-localhost exposes the MCP server to your network!",
                        icon='ERROR',
                    )
                row = mcp_box.row(align=True)
                from . import agent_controller as _ac
                if _ac._agent_state.mcp_server_running:
                    row.operator("bfacw.mcp_server_stop", icon="CANCEL", text="Stop MCP Server")
                else:
                    row.operator("bfacw.mcp_server_start", icon="PLAY", text="Start MCP Server")

        # -- Agent Control ---------------------------------------------
        box = layout.box()
        box.label(text="Coworker Control", icon='WORKSPACE')
        box.prop(self, "agent_autostart")
        row = box.row()
        row.operator("bfacw.ping_agent", icon="FILE_REFRESH", text="Check Status")
        # Lazy import to avoid circular dependency.
        from . import operators_agent as _oa
        ping = _oa._BFACW_OT_ping_agent._result
        if ping:
            is_harness = (self.operating_mode == "EXTERNAL_HARNESS")
            status_icon = "CHECKMARK" if ping.get("all_ok") else "ERROR"
            for key, label in [
                ("bridge_server", "Bridge"),
                ("mcp_server", "MCP"),
                ("llm_health", "LLM"),
                ("llm_chat", "Chat"),
                ("harness_config", "Config"),
            ]:
                val = ping.get(key, "--")
                if val == "N/A":
                    continue
                is_ok = val.startswith("OK") or (is_harness and val.startswith("N/A"))
                box.label(
                    text="{:<6s} {:s}".format(label + ":", val),
                    icon=status_icon if is_ok else "ERROR",
                )

        # -- Port Settings ----------------------------------------------
        port_box = layout.box()
        port_box.label(text="Port Settings", icon='SETTINGS')
        port_box.prop(self, "port_offset")
        self._draw_effective_ports(port_box)
        row = port_box.row()
        row.prop(self, "bridge_port")
        row.prop(self, "mcp_port")
        row.prop(self, "llm_port")
        row.prop(self, "whisper_port")

        # -- Skills (not in External Harness mode) -----------------------
        if self.operating_mode != "EXTERNAL_HARNESS":
            skills_box = layout.box()
            skills_box.label(text="Skills", icon='TEXT')
            try:
                import bpy as _bpy_skills  # pylint: disable=import-error
                version_str = ".".join(str(v) for v in _bpy_skills.app.version[:3])
                skills_box.label(
                    text="Blender {:s}".format(version_str),
                    icon='BLENDER',
                )
            except Exception:
                pass
            # Show loaded skill files.
            try:
                from . import skills as _skills_mod  # pylint: disable=import-error
                _bpy_ver = tuple(bpy.app.version) if hasattr(bpy, "app") else None
                loaded = _skills_mod.list_loaded_skills(bpy_version=_bpy_ver)
                if loaded:
                    col = skills_box.column(align=True)
                    col.label(text="Loaded Skills:", icon='CHECKMARK')
                    for name in loaded:
                        col.label(text="  \u2022 {:s}".format(name))
                else:
                    skills_box.label(text="No skills loaded", icon='INFO')
            except Exception:
                skills_box.label(text="Skills module not available", icon='ERROR')
            row = skills_box.row()
            row.operator("bfacw.reload_skills", icon="FILE_REFRESH", text="Reload Skills")

        # -- Custom Skills (not in External Harness mode) ----------------
        if self.operating_mode != "EXTERNAL_HARNESS":
            custom_box = layout.box()
            custom_box.label(text="Custom Skills", icon='GREASEPENCIL')
            custom_box.label(
                text="Extra instructions injected into every conversation. "
                     "Use for project-specific conventions, tool preferences, "
                     "or workflow rules. Markdown format supported.",
                icon='INFO',
            )
            # Multiline textbox (5.3 textbox API -- same as chat input).
            custom_box.textbox(self, "custom_skills_text")

        # -- Text Editor Memory Bank (not in External Harness mode) ------
        if self.operating_mode != "EXTERNAL_HARNESS":
            mem_box = layout.box()
            mem_box.label(text="Text Editor Memory Bank", icon='TEXT')
            mem_box.label(
                text="Save executed code to timestamped text datablocks\n"
                     "(Coworker_HH-MM-SS) for review and reuse.",
                icon='INFO',
            )
            mem_box.prop(self, "save_code_to_text_editor")

        # -- Chat Display -----------------------------------------------
        chat_box = layout.box()
        chat_box.label(text="Chat Display", icon='SORTTIME')
        chat_box.prop(self, "auto_continue_rounds")
        chat_box.label(
            text="Long requests keep going in rounds while the plan makes progress.",
            icon='INFO',
        )
        chat_box.prop(self, "magic_wording")
        chat_box.prop(self, "helpers_per_turn")
        chat_box.label(
            text="A chat can hand parts of a job to helper chats; on Local they run one after another.",
            icon='INFO',
        )
        if self.operating_mode != "EXTERNAL_HARNESS":     # #359
            chat_box.prop(self, "chats_at_once")
            if self.operating_mode == "LOCAL_LLM":
                chat_box.prop(self, "local_side_by_side")

        # -- Debug Mode -------------------------------------------------
        debug_box = layout.box()
        debug_box.label(text="Debug Mode", icon='MODIFIER')
        debug_box.prop(self, "debug_mode")
        debug_box.label(
            text="Enable benchmarks and advanced diagnostics.",
            icon='INFO',
        )


# ---------------------------------------------------------------------------
# Preferences Tab Selector Operator

class BFACW_OT_copy_update_url(bpy.types.Operator):  # type: ignore[misc]
    """Copy the Coworker extension repository URL (for Get Extensions > Repositories)"""
    bl_idname = "bfacw.copy_update_url"
    bl_label = "Copy Repository URL"

    def execute(self, context: bpy.types.Context) -> set[str]:
        from .shared import UPDATE_REPO_URL
        context.window_manager.clipboard = UPDATE_REPO_URL
        self.report({'INFO'}, "Copied: {:s}".format(UPDATE_REPO_URL))
        return {'FINISHED'}


class BFACW_OT_pref_tab_select(bpy.types.Operator):  # type: ignore[misc]
    """Switch to a different preferences tab."""
    bl_idname = "bfacw.pref_tab_select"
    bl_label = "Select Preferences Tab"
    bl_description = "Switch to this preferences tab"
    bl_options = {'INTERNAL'}

    tab_id: StringProperty(  # type: ignore[valid-type]
        name="Tab ID",
        default="LOCAL_LLM",
    )

    def execute(self, context: bpy.types.Context) -> set[str]:
        prefs = context.preferences.addons[__package__].preferences
        prefs.pref_tab = self.tab_id
        return {'FINISHED'}