# SPDX-FileCopyrightText: 2026 Blender Authors
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""
Carry Coworker's preferences across install locations (issue #86).

Blender stores an add-on's preferences under its full module path, which for
an extension includes the repository: ``bl_ext.user_default.bfa_coworker`` and
``bl_ext.Bforartists_Coworker.bfa_coworker`` are two different add-ons as far
as preferences go.  Moving Coworker into the update repository (the Coworker
Installer does this once) would otherwise reset the API key, model paths,
ports, ...

So the preferences are written to a small JSON file in Blender's user config
folder whenever the add-on is disabled (upgrade, uninstall, quit), and a fresh
install with untouched preferences reads them back once.

"Once" holds only when Blender saves its preferences afterwards: the flag that
says "restored" is itself a preference, so after a session that ended in a crash
or a kill the next start restores again (#575).  That is safe because a restore
only fills settings that still hold their defaults: when this install holds any
setting that is neither its default nor the backup's value (newer than the
backup), nothing is restored.  The limit: a setting you deliberately set back to its
default, while the backup holds another value and no other setting differs, is
restored to the backup's value.

Values are set like any setting (``setattr``): since Blender 5.0 the property
storage (``prefs[key] = value``) no longer reaches ``bpy.props`` values (#396).
Some update callbacks auto-fill *other* fields (model presets, provider URLs),
so those settings are set first and the fields they fill are restored after
them, ending with their saved values.

Also used by the Coworker Installer (it has its own copy of ``dump``) to save
the settings of an old copy before replacing it.  ``bpy`` is only touched
through the objects passed in, so this module is testable without Blender.

The backup keeps your API keys and Hugging Face token on purpose (that is its
job), in their own ``secrets`` field (#346).  The file is readable by your
account only (mode 600 on Linux / macOS; on Windows Blender's config folder is
in your user profile, which is already private), and its contents are never
printed or logged.
"""

from __future__ import annotations

import json
import os
from typing import Any

__all__ = (
    "FILENAME",
    "RESTORED_FLAG",
    "settings_path",
    "dump",
    "apply",
    "save",
    "load",
    "newer_than_backup",
    "restore_once",
)

FILENAME = "bfa_coworker_settings.json"
# Hidden BoolProperty on the preferences: True once this install has either
# restored a backup or decided there was nothing to restore.
RESTORED_FLAG = "settings_restored"

# Never carried over: bookkeeping, UI-only toggles, and live status text.
_SKIP = {"rna_type", RESTORED_FLAG, "bl_idname"}
_SKIP_PREFIXES = ("show_", "ui_", "_")
_VALUE_TYPES = {"BOOLEAN", "INT", "FLOAT", "STRING", "ENUM"}
# Restored first: their update callbacks fill in other fields (mode -> agent / llm mode,
# preset -> model, context and token fields, provider -> URL), which come after.
_DRIVERS = ("operating_mode", "llm_mode", "remote_provider", "model_preset", "local_ctx_preset")
# Kept in the backup's "secrets" field (#346): these, and any other PASSWORD field.
SECRET_KEYS = ("remote_api_key", "hf_token", "gen_remote_key")


# #631: the Local context presets start at 16K.  A saved 4K / 8K preset (an identifier that is
# no longer an item) or a custom size under 16384 becomes 16K.
CTX_MIN = 16384
CTX_PRESET_IDS = ("16384", "32768", "65536", "131072", "custom")


def migrate_ctx_data(data: dict[str, Any]) -> dict[str, Any]:
    """*data* (a saved settings dict) with a too-small context moved up to 16K (#631).

    Returns *data* itself when nothing needs it, else a copy; the fix is printed once."""
    preset, size = data.get("local_ctx_preset"), data.get("local_ctx_size")
    small = isinstance(size, int) and not isinstance(size, bool) and size < CTX_MIN
    gone = isinstance(preset, str) and preset not in CTX_PRESET_IDS
    if not (small or gone):
        return data
    out = dict(data)
    out["local_ctx_preset"] = str(CTX_MIN)
    out["local_ctx_size"] = CTX_MIN
    print("[Coworker] context window: the saved {:s} is below 16K, now 16K (16384)".format(
        "size {:d}".format(size) if small and not gone else "preset {!s}".format(preset)))
    return out


def migrate_ctx_prefs(prefs: Any) -> bool:
    """The live preferences: a context preset that is no longer offered, or a size under
    16K, becomes 16K (#631).  True when it changed something.  Never raises."""
    try:
        try:
            preset = getattr(prefs, "local_ctx_preset")
        except Exception:  # pylint: disable=broad-exception-caught
            preset = ""         # a stored value that is no item (blank drop-down)
        size = int(getattr(prefs, "local_ctx_size", CTX_MIN))
        if preset in CTX_PRESET_IDS and size >= CTX_MIN:
            return False
        was = "preset {!s}, size {:d}".format(preset or "(none)", size)
        prefs.local_ctx_size = CTX_MIN
        prefs.local_ctx_preset = str(CTX_MIN)
        print("[Coworker] context window: the saved {:s} is below 16K, now 16K (16384)".format(was))
        return True
    except Exception as ex:  # pylint: disable=broad-exception-caught
        print("[Coworker] context window migration: {:s}".format(str(ex)))
        return False


def _is_secret(prop: Any) -> bool:
    return prop.identifier in SECRET_KEYS or getattr(prop, "subtype", "") == "PASSWORD"


def _write_private(path: str, text: str) -> None:
    """Like ``session_identity.write_private`` (this module also loads on its own):
    mode 600 from creation on POSIX; Windows ignores it (the user profile is private)."""
    tmp = path + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write(text)
    try:
        os.chmod(tmp, 0o600)    # a .tmp left over from before keeps its old mode
    except OSError:
        pass
    os.replace(tmp, path)


def settings_path(config_dir: str) -> str:
    return os.path.join(config_dir, FILENAME)


def _props(prefs: Any) -> list[Any]:
    out = []
    for prop in prefs.bl_rna.properties:
        ident = prop.identifier
        if ident in _SKIP or ident.startswith(_SKIP_PREFIXES):
            continue
        if prop.type not in _VALUE_TYPES or getattr(prop, "is_readonly", False):
            continue
        if getattr(prop, "is_array", False) or getattr(prop, "array_length", 0):
            continue
        out.append(prop)
    return out


def dump(prefs: Any) -> dict[str, Any]:
    """Plain-JSON snapshot of every user setting on *prefs*."""
    data: dict[str, Any] = {}
    for prop in _props(prefs):
        try:
            value = getattr(prefs, prop.identifier)
        except Exception:  # pylint: disable=broad-exception-caught
            continue
        if prop.type == "ENUM" and getattr(prop, "is_enum_flag", False):
            value = sorted(value)
        if isinstance(value, (bool, int, float, str, list)):
            data[prop.identifier] = value
    return data


def apply(prefs: Any, data: dict[str, Any]) -> list[str]:
    """Set *data* on *prefs*, the fields-filling settings (:data:`_DRIVERS`) first.

    Unknown keys (older/newer versions), bad types and enum identifiers that
    no longer exist are skipped; a setting that can't be set is printed.
    Returns the keys that were applied.
    """
    applied: list[str] = []
    data = migrate_ctx_data(data)
    props = {p.identifier: p for p in _props(prefs)}
    order = [k for k in _DRIVERS if k in data] + [k for k in data if k not in _DRIVERS]
    for key in order:
        value, prop = data[key], props.get(key)
        if prop is None:
            continue
        try:
            if prop.type == "ENUM":
                if getattr(prop, "is_enum_flag", False):
                    continue  # rare; not used by Coworker's preferences
                if not isinstance(value, str) or value not in {item.identifier for item in prop.enum_items}:
                    continue  # dynamic enum or renamed option: keep the default
            elif prop.type == "BOOLEAN":
                value = bool(value)
            elif prop.type == "INT":
                if isinstance(value, bool) or not isinstance(value, int):
                    continue
            elif prop.type == "FLOAT":
                if isinstance(value, bool) or not isinstance(value, (int, float)):
                    continue
                value = float(value)
            elif prop.type != "STRING" or not isinstance(value, str):
                continue
            setattr(prefs, key, value)
            applied.append(key)
        except Exception as ex:  # pylint: disable=broad-exception-caught
            # A secret's error could quote its value: name the error only (#346).
            reason = type(ex).__name__ if _is_secret(prop) else str(ex)
            print("[Coworker] settings restore: {:s} not restored ({:s})".format(key, reason))
    return applied


def save(prefs: Any, config_dir: str, version: str = "") -> bool:
    """Write the settings backup, secrets in their own field, owner-only.  Never raises."""
    try:
        os.makedirs(config_dir, exist_ok=True)
        settings = dump(prefs)
        secret_keys = {p.identifier for p in _props(prefs) if _is_secret(p)}
        secrets = {k: settings.pop(k) for k in sorted(secret_keys) if k in settings}
        payload = {"format": 2, "version": version, "settings": settings, "secrets": secrets}
        _write_private(settings_path(config_dir), json.dumps(payload, indent=1, sort_keys=True))
        return True
    except Exception:  # pylint: disable=broad-exception-caught
        return False


def load(config_dir: str) -> dict[str, Any]:
    """The saved settings, secrets included (format 1, from older copies and older
    Installers, kept them among the settings; the Installer writes format 2 since #418)."""
    try:
        with open(settings_path(config_dir), "r", encoding="utf-8") as fh:
            payload = json.load(fh)
        if not isinstance(payload, dict):
            return {}
        settings, secrets = payload.get("settings"), payload.get("secrets")
        out = dict(settings) if isinstance(settings, dict) else {}
        if isinstance(secrets, dict):
            out.update(secrets)
        return out
    except (OSError, ValueError):
        return {}


_UNKNOWN = object()


def _same(prop: Any, a: Any, b: Any) -> bool:
    if prop.type == "FLOAT":
        try:
            return abs(float(a) - float(b)) <= 1e-6
        except (TypeError, ValueError):
            return False
    return a == b


def newer_than_backup(prefs: Any, data: dict[str, Any]) -> list[str]:
    """Settings in *data* that this install holds with a value that is neither the backup's
    nor the setting's default: someone set them after the backup was written (#575).

    A setting whose default can't be read (no ``default``, an enum whose items come from a
    function) is left out: it can't tell "untouched" from "changed"."""
    out: list[str] = []
    for prop in _props(prefs):
        key = prop.identifier
        if key not in data:
            continue
        default = getattr(prop, "default", _UNKNOWN)
        if default is _UNKNOWN:
            continue
        if prop.type == "ENUM":
            if getattr(prop, "is_enum_flag", False):
                continue
            if default not in {item.identifier for item in getattr(prop, "enum_items", ())}:
                continue        # dynamic items: no fixed default
        try:
            value = getattr(prefs, key)
        except Exception:  # pylint: disable=broad-exception-caught
            continue
        if not _same(prop, value, data[key]) and not _same(prop, value, default):
            out.append(key)
    return out


def restore_once(prefs: Any, config_dir: str) -> list[str]:
    """Restore the backup into a FRESH install, once.

    A fresh install is one whose ``settings_restored`` flag is still False.
    Upgrades in place keep their preferences and already have the flag set,
    so they are never overwritten by an older backup.  The flag is a preference
    too, kept only when Blender saves them (not after a crash or a kill), so the
    restore may come again: it then restores nothing when any setting is newer
    than the backup (:func:`newer_than_backup`).  So it never overwrites a setting that differs
    from both its default and the backup (#575).  It cannot tell a setting you set back to its
    default from one never touched: with no other setting differing, the backup's value is
    written back.
    """
    try:
        if getattr(prefs, RESTORED_FLAG, True):
            return []
        data = migrate_ctx_data(load(config_dir))
        newer = newer_than_backup(prefs, data) if data else []
        if newer:
            setattr(prefs, RESTORED_FLAG, True)
            # Names only: a secret's value is never printed (#346).
            print("[Coworker] settings restore skipped: {:d} setting(s) are newer than the backup ({:s})".format(
                len(newer), ", ".join(sorted(newer)[:6]) + (", ..." if len(newer) > 6 else "")))
            return []
        applied = apply(prefs, data)
        setattr(prefs, RESTORED_FLAG, True)
        return applied
    except Exception as ex:  # pylint: disable=broad-exception-caught
        print("[Coworker] settings restore: {:s}".format(str(ex)))
        return []
