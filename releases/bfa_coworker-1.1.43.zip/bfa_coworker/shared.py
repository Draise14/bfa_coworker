# SPDX-FileCopyrightText: 2026 Blender Authors
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""
Shared constants, helpers, and lazy-import wrappers for the Coworker add-on.
"""

__all__ = (
    "PORT_MIN",
    "PORT_MAX",
    "AUTOSTART_DELAY",
    "STATE_OFFLINE_ERROR_MESSAGE",
    "MODEL_PRESET_ITEMS",
    "REMOTE_PROVIDER_ITEMS",
    "GEN_BACKEND_ITEMS",
    "AGENT_MODE_ITEMS",
    "MCP_SERVER_MODE_ITEMS",
    "OPERATING_MODE_ITEMS",
    "CHAT_MODE_ITEMS",
    "HARNESS_PRESET_ITEMS",
    "HarnessPreset",
    "DEFAULT_BRIDGE_PORT",
    "DEFAULT_MCP_PORT",
    "DEFAULT_LLM_PORT",
    "DEFAULT_WHISPER_PORT",
    "is_debug_mode",
    "effective_ports",
    "effective_whisper_port",
    "UPDATE_REPO_URL",
    "update_repo_of_this_install",
    "get_llm_manager",
    "get_agent_controller",
    "get_gen_controller",
    "icon",
    "is_bforartists",
    "mark_preferences_changed",
    "set_user_pref",
)

import os
from pathlib import Path

PORT_MIN = 1024
PORT_MAX = 65535


# -- Icons that work in Blender too (#456) ----------------------------------------
# Bforartists has about 1,300 icons Blender doesn't.  A layout call or a class with
# an unknown icon fails in Blender ("enum not found"): a class's bl_icon stops
# register() part way.  Every Bforartists-only icon goes through icon(), which falls
# back to a Blender icon (tests/test_blender_icons.py keeps it that way).
ICON_FALLBACKS = {
    "WIZARD": "GHOST_ENABLED",      # the agent
    "WARNING": "ERROR",             # Blender's warning triangle is ERROR
    "MAKE_SCREENSHOT": "WINDOW",
    "EXTENSION": "PLUGIN",
    # The Auto Captions dialog (#605): Bforartists' own icons, a distinct Blender icon for each.
    "SEQ_TEXT": "TEXT",             # the Text section
    "CARET_NEXT_WORD": "FORWARD",
    "MOVE_UP": "TRIA_UP",
    "MOVE_DOWN": "TRIA_DOWN",
    "CARET_NEXT_CHAR": "KEY_RETURN",
    "SET_UPPERCASE": "SMALL_CAPS",
    "SET_LOWERCASE": "FONT_DATA",
    "SET_STRING_CASE": "SORTALPHA",
    "MESH_LINE": "REMOVE",
}
_ICONS: frozenset[str] | None = None


def is_bforartists() -> bool:
    """True in Bforartists.  Blender has no ``bpy.app.bfa_version_string``; menus such
    as ``VIEW3D_MT_view`` exist in both, so they can't tell them apart."""
    try:
        import bpy
    except ImportError:
        return False
    return hasattr(bpy.app, "bfa_version_string")


def _known_icons() -> frozenset[str] | None:
    global _ICONS
    if _ICONS is None:
        try:
            import bpy
            _ICONS = frozenset(bpy.types.UILayout.bl_rna.functions["prop"].parameters["icon"].enum_items.keys())
        except (ImportError, AttributeError, KeyError):
            return None         # no bpy (tests): names pass through
    return _ICONS


def icon(name: str) -> str:
    """*name* if this build has the icon, else its Blender fallback, else ``NONE``."""
    known = _known_icons()
    if known is None or name in known:
        return name
    fallback = ICON_FALLBACKS.get(name, "NONE")
    return fallback if fallback in known else "NONE"

# Default seconds to wait after registration before auto-starting the server.
# Avoids adding work to Blender's startup sequence.
AUTOSTART_DELAY = 1.0

# This error is shown in the UI & command line when online access isn't enabled.
#
# NOTE(@ideasman42): we could consider `localhost` to be acceptable, this is a grey area
# regarding what counts as "online" or not.
STATE_OFFLINE_ERROR_MESSAGE = "Online access must be enabled in the system preferences"

# -- Default Ports --------------------------------------------------------

DEFAULT_BRIDGE_PORT = 9876
DEFAULT_MCP_PORT = 9191
DEFAULT_LLM_PORT = 8081
# whisper-server, speech to text (#375).  Clear of the others plus their offsets (0-100).
DEFAULT_WHISPER_PORT = 8481

# -- Your choices, kept on quit (#575) --------------------------------------
def mark_preferences_changed(preferences=None) -> None:
    """Tell Blender the preferences changed, so "Auto-Save Preferences" writes them on quit (#575).

    Blender sets this flag itself when you change a setting with a button, and when Python
    changes one of Blender's own settings, but not when Python changes an add-on's setting.
    With Auto-Save Preferences off it only marks them unsaved (Save Preferences), as for any
    other change.  *preferences* is ``context.preferences``; default ``bpy.context``'s.
    """
    try:
        if preferences is None:
            import bpy  # pylint: disable=import-error
            preferences = bpy.context.preferences
        preferences.is_dirty = True
    except (AttributeError, TypeError, ImportError):
        pass


def set_user_pref(prefs, name: str, value, preferences=None) -> bool:
    """Store a choice YOU made in one of Coworker's settings from code, kept on quit (#575).

    Only where a user's action is behind it (an operator, a menu, a drag); never for start-up
    or timer bookkeeping: that would make Blender save the preferences when you changed
    nothing, and with two windows open the one quitting last writes its older copy over the
    other's.  Marks the preferences changed only when the value really changed; returns
    True then.
    """
    missing = object()
    old = getattr(prefs, name, missing)
    setattr(prefs, name, value)
    changed = old is missing or getattr(prefs, name, missing) != old
    if changed:
        mark_preferences_changed(preferences)
    return changed


# Debug mode: controlled by user-facing preference toggle.
# Previously a hardcoded constant; now reads from preferences at runtime.
def is_debug_mode() -> bool:
    """Return True when the user has enabled debug/diagnostics mode.

    Reads from the add-on preferences at call time.  Falls back to True
    (show diagnostics) when preferences are not yet available (e.g. during
    early registration).
    """
    try:
        import bpy  # pylint: disable=import-error
        prefs = bpy.context.preferences.addons.get(__package__)
        if prefs is not None and hasattr(prefs.preferences, "debug_mode"):
            return prefs.preferences.debug_mode
    except Exception:  # pylint: disable=broad-exception-caught
        pass
    return True  # safe default -- show diagnostics until preferences load


def effective_ports(prefs) -> tuple[int, int, int]:
    """Return (bridge_port, mcp_port, llm_port) with offset applied.

    If an individual port override is set (> 0), it is used directly
    *without* the offset.  Otherwise, ``DEFAULT_*_PORT + offset`` is used.
    """
    offset = prefs.port_offset if hasattr(prefs, 'port_offset') else 0
    bridge = (
        prefs.bridge_port
        if hasattr(prefs, 'bridge_port') and prefs.bridge_port > 0
        else DEFAULT_BRIDGE_PORT + offset
    )
    mcp = (
        prefs.mcp_port
        if hasattr(prefs, 'mcp_port') and prefs.mcp_port > 0
        else DEFAULT_MCP_PORT + offset
    )
    llm = (
        prefs.llm_port
        if hasattr(prefs, 'llm_port') and prefs.llm_port > 0
        else DEFAULT_LLM_PORT + offset
    )
    # Issue #85: once THIS window's servers are running they may have moved
    # to a free port (another Blender window held the configured one).  Every
    # caller -- MCP launch, health checks, harness configs, the UI -- must use
    # the port this window actually owns, never the configured one.
    try:
        from . import mcp_to_blender_server as _mbs
        if _mbs.is_running() and _mbs.get_actual_port():
            bridge = int(_mbs.get_actual_port())
    except Exception:  # pylint: disable=broad-exception-caught
        pass
    try:
        from . import agent_controller as _ac
        _st = _ac._agent_state
        if getattr(_st, "mcp_server_running", False) and getattr(_st, "mcp_port_actual", 0):
            mcp = int(_st.mcp_port_actual)
    except Exception:  # pylint: disable=broad-exception-caught
        pass
    return (bridge, mcp, llm)


def effective_whisper_port(prefs) -> int:
    """The whisper-server port (#375), like :func:`effective_ports`: the override when
    set (> 0), else ``DEFAULT_WHISPER_PORT + offset``; once THIS window's server runs,
    the port it actually got (it moves up when another window holds the configured one)."""
    offset = prefs.port_offset if hasattr(prefs, 'port_offset') else 0
    port = (
        prefs.whisper_port
        if hasattr(prefs, 'whisper_port') and prefs.whisper_port > 0
        else DEFAULT_WHISPER_PORT + offset
    )
    try:
        from . import whisper_manager as _wm
        actual = _wm.running_port()
        if actual:
            port = int(actual)
    except Exception:  # pylint: disable=broad-exception-caught
        pass
    return port


# -- Updates (issue #86) ----------------------------------------------------

# The Coworker extension repository (Blender's "v1" static listing).  Keep in
# sync with extension_repo.py and installer/bfa_coworker_installer.
UPDATE_REPO_URL = "https://raw.githubusercontent.com/Draise14/bfa_coworker/main/extensions/index.json"


def update_repo_of_this_install():
    """The extension repository this copy is installed in, if it is the
    Coworker update repository; else ``None`` (installed from a file)."""
    try:
        import bpy  # pylint: disable=import-error
        parts = (__package__ or "").split(".")
        if len(parts) < 3 or parts[0] != "bl_ext":
            return None
        module = parts[1]
        for repo in bpy.context.preferences.extensions.repos:
            if repo.module == module:
                if repo.use_remote_url and repo.remote_url.rstrip("/") == UPDATE_REPO_URL:
                    return repo
                return None
    except Exception:  # pylint: disable=broad-exception-caught
        pass
    return None


# -- Lazy Import Helpers (avoids circular imports) ------------------------

def get_llm_manager():
    """Lazy import of llm_manager module."""
    from . import llm_manager as _m
    return _m


def get_agent_controller():
    """Lazy import of agent_controller module."""
    from . import agent_controller as _m
    return _m


def get_gen_controller():
    """Lazy import of gen_controller module."""
    from . import gen_controller as _m
    return _m


# -- Static EnumProperty Items --------------------------------------------

def _llm_manager_module():
    """llm_manager in the package, or by path when this file is loaded on its own (tests)."""
    try:
        from . import llm_manager as _m
    except ImportError:
        import importlib.util as _ilu
        _spec = _ilu.spec_from_file_location("bfacw_llm_manager_for_shared", Path(__file__).with_name("llm_manager.py"))
        _m = _ilu.module_from_spec(_spec)  # type: ignore[arg-type]
        _spec.loader.exec_module(_m)  # type: ignore[union-attr]
    return _m


# Static preset items for the model_preset EnumProperty.
# Must be a module-level constant -- callbacks can fail during class registration.
# Built once at import from llm_manager.PRESET_MODELS (#558): the tooltips carry
# the same generated VRAM and download texts as the preferences rows.
MODEL_PRESET_ITEMS: list[tuple[str, str, str]] = _llm_manager_module().preset_enum_items()

# Static preset items for the remote_provider EnumProperty.
_REMOTE_PROVIDER_ITEMS: list[tuple[str, str, str]] = [
    ("openrouter", "OpenRouter", "One key -> 300+ models (OpenAI, Anthropic, DeepSeek, etc.)"),
    ("_custom", "Custom (manual entry)", "Manually specify API URL and model name"),
]

REMOTE_PROVIDER_ITEMS: list[tuple[str, str, str]] = _REMOTE_PROVIDER_ITEMS

# Static preset items for the gen_backend EnumProperty.
_GEN_BACKEND_ITEMS: list[tuple[str, str, str]] = [
    (
        "local",
        "Local (Built-in)",
        "Run generative models locally via diffusers/torch -- "
        "models downloaded on first use from HuggingFace",
    ),
    (
        "pallaidium",
        "Pallaidium Bridge",
        "Bridge to Pallaidium addon if installed -- "
        "access 50+ models through Pallaidium's pipeline",
    ),
    (
        "comfyui",
        "ComfyUI",
        "Connect to a local ComfyUI server -- "
        "use custom workflows as generation models",
    ),
    (
        "remote",
        "Remote API",
        "Use a remote OpenAI-compatible generation API "
        "(e.g. fal.ai, LocalAI)",
    ),
]

GEN_BACKEND_ITEMS: list[tuple[str, str, str]] = _GEN_BACKEND_ITEMS

# -- Agent Mode EnumProperty Items ----------------------------------------

AGENT_MODE_ITEMS: list[tuple[str, str, str]] = [
    (
        "SELF_CONTAINED",
        "Self-Contained",
        "Built-in chat UI with managed local LLM or remote API -- "
        "everything runs inside Blender (recommended for new users)",
    ),
    (
        "EXTERNAL_HARNESS",
        "External Harness",
        "Bridge-only mode -- run the TCP bridge server inside Blender "
        "and connect an external MCP client (Claude Desktop, Cursor, "
        "VS Code, or any MCP-compatible tool)",
    ),
]

# -- Operating Mode EnumProperty Items ------------------------------------
# Unified top-level selector that combines agent_mode + llm_mode.

# How much the chat asks before tools run (#240), for every engine.
APPROVAL_MODE_ITEMS: list[tuple[str, str, str, str, int]] = [
    # Adjectives for how much freedom the tools get, strictest first (the ids stay: saved settings
    # keep working).  The tooltips carry the detail.
    ("ASK", "Strict",
     "Strict: it asks before each change to the scene (Allow once, Allow this turn, or Deny). Looking "
     "around never asks", "LOCKED", 0),
    ("RISKY", "Permissive",
     "Permissive: changes to the scene run on their own; it asks only before saving or opening files, "
     "quitting, deleting, exporting, running another program, writing outside the project folder or "
     "connecting to the internet", "UNLOCKED", 1),
    ("AUTO", "Auto",               # not "Free": that reads as the price
     "Auto: nothing asks, everything runs straight away (the agent's own tools still follow Only "
     "Coworker Tools)", "AUTO", 2),
]

OPERATING_MODE_ITEMS: list[tuple[str, str, str, str, int]] = [
    (
        "LOCAL_LLM",
        "Local LLM",
        "Chat here; a model runs on this computer (llama-server, download one in Settings). "
        "Private, works offline",
        "CONSOLE",
        0,
    ),
    (
        "REMOTE_API",
        "Remote API",
        "Chat here; a model from an online service (OpenAI, OpenRouter, ...) with your API key",
        "WORLD",
        1,
    ),
    (
        "EXTERNAL_AGENT",
        "External Agent",
        "Chat here; an agent app on this computer (Claude Code, OpenCode, Codex, Gemini, Copilot) "
        "does the work with Coworker's Blender tools, on your own subscription",
        "LINKED",
        3,
    ),
    (
        "EXTERNAL_HARNESS",
        "External Harness",
        "Chat in another app (Claude Desktop, Cursor, VS Code, ...): it works in Blender through "
        "Coworker's bridge, and Coworker's own chat is off",
        "NETWORK_DRIVE",
        2,
    ),
]

# -- MCP Server Mode EnumProperty Items -----------------------------------

MCP_SERVER_MODE_ITEMS: list[tuple[str, str, str]] = [
    (
        "MANAGED",
        "Managed (HTTP)",
        "The addon manages the MCP server as a subprocess with HTTP transport -- "
        "used by the built-in chat UI",
    ),
    (
        "STDIO",
        "Stdio (External Client)",
        "The MCP server runs via stdio -- for external MCP clients like "
        "Claude Desktop, Cursor, or VS Code. The addon provides config snippets "
        "but does NOT manage the server process",
    ),
    (
        "NETWORK",
        "Network (HTTP Server)",
        "The MCP server listens on a configurable host:port with HTTP transport -- "
        "for browser-based clients or remote connections",
    ),
]

# -- Chat Mode EnumProperty Items (Tier 1: Agent/Ask Toggle) --------------

CHAT_MODE_ITEMS: list[tuple[str, str, str, str, int]] = [
    ("AGENT", "Coworker", "Coworker works in the scene: it runs tools and changes things", "GHOST_ENABLED", 0),
    ("ASK", "Ask", "Ask questions: it answers without changing anything", "QUESTION", 1),
    ("PLAN", "Plan", "Make a step plan for your request without changing anything. Carry it out later -- "
                     "with this engine or another (Local, Remote, an agent): the plan stays in this chat",
     "LINENUMBERS_ON", 2),
]

# -- Harness Preset Dataclass ---------------------------------------------


class HarnessPreset:
    """Metadata for an external MCP client harness preset.

    Each preset describes one supported harness with its config format,
    file location, setup steps, and documentation links.
    """

    __slots__ = (
        "identifier",
        "name",
        "description",
        "icon",
        "is_open_source",
        "config_path_help",
        "setup_steps",
        "docs_url",
        "notes",
        "chat_paste_hint",
    )

    def __init__(
        self,
        identifier: str,
        name: str,
        description: str,
        icon: str = "URL",
        is_open_source: bool = False,
        config_path_help: str = "",
        setup_steps: list[str] | None = None,
        docs_url: str = "",
        notes: str = "",
        chat_paste_hint: str = "",
    ) -> None:
        self.identifier = identifier
        self.name = name
        self.description = description
        self.icon = icon
        self.is_open_source = is_open_source
        self.config_path_help = config_path_help
        self.setup_steps = setup_steps or []
        self.docs_url = docs_url
        self.notes = notes
        self.chat_paste_hint = chat_paste_hint


# -- Harness Presets ------------------------------------------------------
# Config formats, paths and steps below were checked against each client's
# own documentation (issue #100); formats live in harness_clients.py.
_HARNESS_PRESETS: list[HarnessPreset] = [
    HarnessPreset(
        identifier="claude_desktop",
        name="Claude Desktop",
        description="Anthropic's desktop app for Windows and macOS.",
        icon="URL",
        is_open_source=False,
        config_path_help=(
            "Windows: %APPDATA%\\Claude\\claude_desktop_config.json\n"
            "  (some installs: %LOCALAPPDATA%\\Claude-Data\\claude_<id>\\claude_desktop_config.json)\n"
            "macOS: ~/Library/Application Support/Claude/claude_desktop_config.json"
        ),
        setup_steps=[
            "Quit Claude Desktop fully (File -> Exit) -- it rewrites its config while running",
            "Click 'Add to Claude Desktop', or open Settings -> Developer -> Edit Config and merge the copied entry",
            "Reopen Claude Desktop",
            "Check the server under the + menu -> Connectors",
        ],
        docs_url="https://modelcontextprotocol.io/docs/develop/connect-local-servers",
        notes="Claude Desktop must be fully quit and reopened after config changes.",
    ),
    HarnessPreset(
        identifier="claude_code",
        name="Claude Code",
        description="Anthropic's coding agent: terminal CLI, plus VS Code and JetBrains extensions.",
        icon="CONSOLE",
        is_open_source=False,
        config_path_help=(
            "User scope (all projects): ~/.claude.json  (Windows: %USERPROFILE%\\.claude.json)\n"
            "Project scope: .mcp.json in the folder you open with Claude Code"
        ),
        setup_steps=[
            "Click 'Add to Claude Code' -- it writes the server into ~/.claude.json",
            "Or: save the copied config as .mcp.json in your project folder",
            "Restart Claude Code (CLI: exit and re-run claude; VS Code: reload the window)",
            "Run /mcp in Claude Code -- bfa-coworker should show as connected",
        ],
        docs_url="https://code.claude.com/docs/en/mcp",
        notes="Claude Code does NOT read claude_desktop_config.json -- a server set up for Claude Desktop is invisible to it.",
        chat_paste_hint="Claude Code: /mcp only lists servers that are already configured -- use 'Add to Claude Code' or a .mcp.json file to add one.",
    ),
    HarnessPreset(
        identifier="codex",
        name="Codex CLI",
        description="OpenAI's open-source coding agent for the terminal.",
        icon="CONSOLE",
        is_open_source=True,
        config_path_help=(
            "~/.codex/config.toml  (or .codex/config.toml in a trusted project) -- TOML, not JSON"
        ),
        setup_steps=[
            "Click 'Add to Codex CLI', or paste the copied TOML into ~/.codex/config.toml",
            "Or run: codex mcp add bfa-coworker --env BFACW_PORT=<port> -- <command> <args>",
            "Start codex in your terminal",
            "Run codex mcp list to confirm bfa-coworker is listed",
        ],
        docs_url="https://learn.chatgpt.com/docs/extend/mcp?surface=cli",
        notes="Codex reads TOML: each server is a [mcp_servers.<name>] table.",
    ),
    HarnessPreset(
        identifier="cursor",
        name="Cursor",
        description="AI code editor (VS Code fork) with agent mode and MCP support.",
        icon="FILE_TEXT",
        is_open_source=False,
        config_path_help=(
            "Global: ~/.cursor/mcp.json   Project: .cursor/mcp.json"
        ),
        setup_steps=[
            "Click 'Add to Cursor', or merge the copied entry into ~/.cursor/mcp.json",
            "Restart Cursor",
            "Open Customize in the sidebar and check that bfa-coworker is enabled",
        ],
        docs_url="https://cursor.com/docs/context/mcp",
        notes="Cursor uses the mcpServers key with type: stdio.",
    ),
    HarnessPreset(
        identifier="windsurf",
        name="Windsurf",
        description="IDE with the Cascade agent (now documented as Devin Desktop).",
        icon="FILE_TEXT",
        is_open_source=False,
        config_path_help=(
            "Current: %APPDATA%\\devin\\mcp_config.json (Windows), ~/.config/devin/mcp_config.json\n"
            "Older Windsurf: ~/.codeium/windsurf/mcp_config.json"
        ),
        setup_steps=[
            "In Cascade, open ... -> MCPs -> Open MCP config file once (creates it)",
            "Click 'Add to Windsurf', or merge the copied entry into that file",
            "Restart Windsurf / Devin Desktop",
        ],
        docs_url="https://docs.devin.ai/desktop/cascade/mcp",
        notes="Cascade servers are added by editing mcp_config.json; there is no chat-paste or one-click install.",
    ),
    HarnessPreset(
        identifier="cline",
        name="Cline",
        description="Open-source coding agent extension for VS Code and JetBrains.",
        icon=icon("EXTENSION"),
        is_open_source=True,
        config_path_help=(
            "IDE: MCP Servers icon -> Configure -> 'Configure MCP Servers' opens cline_mcp_settings.json\n"
            "CLI: ~/.cline/data/settings/cline_mcp_settings.json"
        ),
        setup_steps=[
            "Click the MCP Servers icon in Cline's toolbar",
            "Open the Configure tab and click 'Configure MCP Servers'",
            "Merge the copied entry into mcpServers and save",
        ],
        docs_url="https://docs.cline.bot/mcp/configuring-mcp-servers",
        notes="Cline asks you to approve each tool call unless you add it to autoApprove.",
    ),
    HarnessPreset(
        identifier="opencode",
        name="OpenCode",
        description="Open-source coding agent: terminal TUI, desktop app, or IDE.",
        icon="CONSOLE",
        is_open_source=True,
        config_path_help=(
            "Global: ~/.config/opencode/opencode.json   Project: opencode.json"
        ),
        setup_steps=[
            "Install: npm install -g opencode-ai  (or see the install docs)",
            "Click 'Add to OpenCode', or merge the copied mcp entry into opencode.json",
            "Start opencode",
            "Run opencode mcp list to confirm bfa-coworker is listed",
        ],
        docs_url="https://opencode.ai/docs/mcp-servers/",
        notes="OpenCode uses its own schema: mcp -> {type: local, command: [...], environment}.",
    ),
    HarnessPreset(
        identifier="vscode",
        name="VS Code (Copilot)",
        description="VS Code's built-in MCP support for agent mode.",
        icon="FILE_TEXT",
        is_open_source=False,
        config_path_help=(
            "Workspace: .vscode/mcp.json   User: run 'MCP: Open User Configuration'"
        ),
        setup_steps=[
            "Run 'MCP: Open User Configuration' from the Command Palette (or create .vscode/mcp.json)",
            "Merge the copied entry into the servers section and save",
            "Start the server from the MCP list (MCP: List Servers)",
        ],
        docs_url="https://code.visualstudio.com/docs/copilot/customization/mcp-servers",
        notes="VS Code uses the servers key (not mcpServers).",
    ),
    HarnessPreset(
        identifier="freebuff",
        name="Freebuff (unverified)",
        description="Freebuff agent client -- no public MCP docs found; format unverified.",
        icon="URL",
        is_open_source=True,
        config_path_help=(
            "Unknown -- use Freebuff's MCP / tools settings."
        ),
        setup_steps=[
            "Open Freebuff's MCP / tools settings",
            "Add a new stdio server using the copied command, args and env",
            "Restart Freebuff",
        ],
        docs_url="",
        notes="The copied config uses the common mcpServers format; we couldn't confirm Freebuff reads it.",
    ),
    HarnessPreset(
        identifier="generic",
        name="Generic STDIO",
        description="Common mcpServers format for any MCP client not listed above.",
        icon="SETTINGS",
        is_open_source=False,
        config_path_help=(
            "Varies by client -- check its documentation for MCP stdio servers."
        ),
        setup_steps=[
            "Find where your MCP client stores its servers",
            "Merge the copied bfa-coworker entry into it (rename the top key if your client uses another one)",
            "Restart your MCP client",
        ],
        docs_url="",
        notes="The command, args and env are what every stdio client needs, whatever its key names.",
    ),
]

# EnumProperty items for the harness_preset selector.
HARNESS_PRESET_ITEMS: list[tuple[str, str, str]] = [
    (p.identifier, p.name, p.description) for p in _HARNESS_PRESETS
]


def get_harness_preset_by_id(identifier: str) -> HarnessPreset | None:
    """Look up a harness preset by its identifier string."""
    for p in _HARNESS_PRESETS:
        if p.identifier == identifier:
            return p
    return None


def get_harness_presets() -> list[HarnessPreset]:
    """Return all harness presets."""
    return list(_HARNESS_PRESETS)