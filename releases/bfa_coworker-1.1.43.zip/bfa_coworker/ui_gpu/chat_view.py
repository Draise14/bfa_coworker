# SPDX-FileCopyrightText: 2026 Blender Authors
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""
The chat view of the GPU chat (Tier 4, task "GPU 2").

Draws a conversation, in the chat panel's own message shapes (see
``chat_state`` / ``chat_turns``), onto a :class:`layout.Canvas`:

* one box per turn: your message, the collapsible **Workshop** (tool rows,
  failed ones marked, reasoning, notes), and the reply as markdown;
* code blocks in monospace with a **Copy** button; tables as aligned rows;
* while a turn runs, its live text and phase instead of the reply;
* under the newest turn, a **job row** per background render or bake
  (``long_jobs``, #423): what runs, how long, a progress bar where Blender
  reports one, and how to stop it (Esc, or the job bar's X: Python can't);
* laid out from the **bottom up**: the newest turn sits just above the
  input, ``scroll`` counts pixels up from the bottom (0 = follow the newest),
  and a "jump to newest" button appears when you've scrolled away.

Icons come first, like in the native chat, so a row reads before its words:
you, Coworker (the add-on's agent icon), a finished turn, the Workshop (a
warning when a step failed), each tool row, notes, code and Copy, and
keyframe markers on headings -- full-colour Bforartists icons, see :mod:`.icons`.

The same code draws the full editor and the compact sidebar (``compact``).
Clicks come back from :meth:`ChatView.draw` as ``(action, value)`` pairs for
the input layer to carry out: ``("copy", text)``, ``("toggle", turn_key)``,
``("link", url)``, ``("jump", "")``.  For the right-click menu (#453) it
also keeps where each turn was drawn (:meth:`ChatView.turn_at`).

Text can be selected with the mouse (#451, #455): your messages, each block of a
reply (code too) and the live Thinking box are **units** (:func:`unit_texts`)
whose drawn lines the canvas keeps; the view holds the :class:`selection.ChatSelection`,
draws its highlight behind the text and gives its text as shown
(:meth:`ChatView.selected_text`).  A reply that is still streaming isn't
selectable.  Free of ``bpy``.
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field
from typing import Any, Callable

from .. import long_jobs
from ..chat_status import fmt_duration, phase_text, spinner_char
from ..chat_turns import NOTE_TITLES, group_turns, is_system_note_msg, split_turn
from .layout import Canvas, DrawCmd, InteractionState, Rect, TextLine
from .markdown import Block, Span, parse
from .selection import CHIP_PAD, ChatSelection, flow_tokens, highlight_rects, join_units, point_to_pos, word_bounds
from .style import RGBA, Style
from .suggestions import TYPE, suggestions

__all__ = (
    "ChatView",
    "LiveSnapshot",
    "block_text",
    "live_snapshot",
    "message_text",
    "transcript",
    "unit_texts",
)

# The sections of a turn's selectable units, top to bottom: your message, the live Thinking
# box, the reply's blocks.  A unit is (section, block index).
USER, THINK, REPLY = 0, 1, 2

_ERROR = (0.92, 0.40, 0.33, 1.0)   # failed tool rows (themes have no error colour)
# Heading sizes relative to body text, close to Blender 5.3's label_markdown.
_HEADING_SCALE = {1: 1.6, 2: 1.4, 3: 1.2, 4: 1.05}
# Heading markers, as in the native chat: keyframe shapes that shrink with the level.
_HEADING_ICON = {1: "KEYTYPE_EXTREME_VEC", 2: "KEYTYPE_MOVING_HOLD_VEC", 3: "KEYTYPE_JITTER_VEC"}


# Choices (a question's, or a reply's suggestions): a keyframe marks each, green (jitter) for the
# recommended one -- the first -- and blue (breakdown) for the others, in the theme's colours.
_CHOICE_ICONS = (("KEYTYPE_JITTER_VEC", 2), ("KEYTYPE_JITTER_VEC", 3))     # same diamond, two colours


def choice_height(canvas: Canvas, width: float, text: str) -> float:
    """The height of a choice button *width* wide: its text wraps to fit."""
    style = canvas.style
    inner = width - canvas.icon_size() - 2.4 * style.pad
    return max(style.unit * 1.1, canvas.text_height(text, inner) + style.pad * 0.8)


def draw_choice(canvas: Canvas, rect: Rect, widget_id: str, text: str, recommended: bool) -> bool:
    """A choice as a left-aligned button with a keyframe before its wrapped text; True when clicked."""
    style = canvas.style
    clicked = canvas.button(rect, widget_id, "")
    icon, colour = _CHOICE_ICONS[0] if recommended else _CHOICE_ICONS[1]
    side = canvas.icon_size() * 1.25          # the diamond fills less of its square than an icon
    edge = max(1.0, style.scale * 1.2)
    mark = Rect(rect.x + style.pad * 0.8, rect.top - style.pad * 0.4 - style.line_height + (style.line_height - side) / 2,
                side, side)
    canvas.icon(Rect(mark.x - edge, mark.y - edge, side + 2 * edge, side + 2 * edge), icon, style.keyframe_border)
    canvas.icon(mark, icon, style.keyframes[colour])
    tx = mark.right + style.pad * 0.6
    canvas.wrapped(tx, rect.top - style.pad * 0.4, rect.right - style.pad * 0.8 - tx, text, style.button.text)
    return clicked


# "[attached: a.png, b.jpg]" -- the marker a user message carries for its images.
_ATTACHED = re.compile(r"\s*\[attached:\s*([^\]]*)\]")
# Thumbnail heights (in widget units) for the S / M / L sizes.
THUMB_SIZES = {"S": 2.5, "M": 4.0, "L": 7.0}
_LIVE_MAX_LINES = 8    # the live-thinking box grows with its text up to this many lines (#452)
_LIVE_TAIL_CHARS = 4000    # ... and lays out only the newest part of a long chain of thought
_SCROLL_IDLE_ALPHA = 0.4   # the scrollbar's strength with the mouse away (#279)
_FRAME_LINES = 14      # code frames show this many lines (Show all for the rest)
_RESULT_LINES = 3      # a tool's result: a few lines (often not for reading; Show all: #236)
_RESULT_LINE_CHARS = 160   # ... each cut this short while folded (one long JSON line wraps a lot)
_ENTRY_CHARS = 600     # a Workshop thinking entry shows this much (Show all for the rest)
# The job row's last line (#423).  Python has no call that stops a render or bake (#419 adds
# one), so instead of the X the Classic chat's Blender job bar has, it says where that X is.
JOB_HINT = "Stop it with Esc, or the X on the job bar in the status bar"
_JOB_ICONS = {"RENDER": "RENDER_STILL", "OBJECT_BAKE": "TEXTURE"}


def split_attachments(text: str) -> tuple[str, list[str]]:
    """(text without the marker, attached image names)."""
    names: list[str] = []
    for m in _ATTACHED.finditer(text):
        names += [n.strip() for n in m.group(1).split(",") if n.strip()]
    return _ATTACHED.sub("", text).strip(), names


def message_text(content: Any) -> str:
    """Plain text of a message's content (string or a list of blocks)."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return " ".join(str(b.get("text", "")) for b in content if isinstance(b, dict))
    return str(content or "")


def _soft(color: RGBA, amount: float = 0.35) -> RGBA:
    return (color[0], color[1], color[2], color[3] * (1.0 - amount))


def _lighten(color: RGBA, amount: float) -> RGBA:
    return (min(1.0, color[0] + amount), min(1.0, color[1] + amount), min(1.0, color[2] + amount), color[3])


def _think_tail(text: str) -> str:
    """The newest part of a live chain of thought, cut at a line break (#452): the box shows
    its last lines only, so a long one isn't laid out whole each frame.  A code fence left
    open by the cut is opened again."""
    text = text.strip()
    if len(text) <= _LIVE_TAIL_CHARS:
        return text
    head, tail = text[:-_LIVE_TAIL_CHARS], text[-_LIVE_TAIL_CHARS:]
    cut = tail.find("\n")
    if cut >= 0:
        head, tail = head + tail[:cut + 1], tail[cut + 1:]
    return ("```\n" + tail) if head.count("```") % 2 else tail


def _markdown_gaps(blocks: list[Block], pad: float) -> tuple[float, float]:
    """The space ``ChatView._draw_markdown`` leaves above its first block and under its last."""
    def gaps(block: Block) -> tuple[float, float]:
        if block.kind in ("code", "table"):
            return pad * 0.5, pad * 0.5
        if block.kind == "hr":
            return pad, pad
        if block.kind == "heading":
            return pad * (1.2 if block.level <= 2 else 0.8), pad * 0.4
        if block.kind in ("item", "quote"):
            return 0.0, 0.0
        return 0.0, pad * 0.3
    if not blocks:
        return 0.0, 0.0
    return gaps(blocks[0])[0], gaps(blocks[-1])[1]


def _copy_texts(turn: list[dict], active: bool = False) -> tuple[str, str]:
    """What a turn's two Copy buttons copy: your text and the reply ("" while it runs)."""
    user, _process, conclusion = split_turn(turn)
    text = split_attachments(message_text(user.get("content")))[0] if user is not None else ""
    reply = message_text(conclusion.get("content")) if conclusion is not None and not active else ""
    return text, reply


def transcript(history: list[dict]) -> str:
    """The chat as text, for the menu's Copy Whole Chat (#453): your messages and Coworker's
    replies, turn by turn -- the same texts their Copy buttons copy; tool steps left out."""
    parts = []
    for turn in group_turns([m for m in history if m.get("role") != "system"]):
        text, reply = _copy_texts(turn)
        parts += [label + body for label, body in (("You:\n", text), ("Coworker:\n", reply)) if body.strip()]
    return "\n\n".join(parts)


def block_text(block: Block) -> str | None:
    """The text a markdown block shows (#455), or None for one with none (a rule)."""
    if block.kind in ("code", "table"):
        return "\n".join(block.lines or [""])
    if block.kind == "hr":
        return None
    return flow_tokens(block.spans)[0]


def unit_texts(turn: list[dict], active: bool = False) -> list[tuple[tuple, str, str]]:
    """A turn's selectable texts as shown, ``(unit, text, kind)`` in reading order: your
    message (without its attachment marker) and each block of the reply (markdown markers
    stripped); no reply while the turn runs.  The same texts the view draws, so a selection
    can span turns that scrolled out of view (#455)."""
    user, _process, conclusion = split_turn(turn)
    out: list[tuple[tuple, str, str]] = []
    if user is not None:
        text = split_attachments(message_text(user.get("content")))[0]
        if text:
            out.append(((USER, 0), text, "user"))
    if conclusion is not None and not active:
        for n, block in enumerate(parse(message_text(conclusion.get("content")))):
            text = block_text(block)
            if text is not None:
                out.append(((REPLY, n), text, block.kind))
    return out


def _tool_failed(msg: dict) -> bool:
    content = message_text(msg.get("content"))
    return content.startswith("Error") or '"status": "error"' in content


@dataclass(frozen=True)
class LiveSnapshot:
    """The running turn's live fields, read once for a frame (#387)."""

    is_thinking: bool = False
    streaming_text: str = ""
    reasoning_text: str = ""
    thinking_start_time: float = 0.0
    thinking_dots: int = 0
    turn_phase: str = ""


def live_snapshot(live: Any) -> Any:
    """*live* (the thread's ``AgentState``) read once, for one frame.

    A worker thread writes the running turn (our loop's streaming) while the chat draws.
    The view measures the turn and then draws it: reading the state twice, a text replaced
    in between (the turn ending, a new request starting over) was drawn other than it was
    measured -- an empty slot, or text past the turn's slot, for that frame (#387).
    """
    if live is None or isinstance(live, LiveSnapshot):
        return live
    def read(name: str, default: Any) -> Any:
        value = getattr(live, name, default)
        return default if value is None else value
    return LiveSnapshot(bool(read("is_thinking", False)), str(read("streaming_text", "")),
                        str(read("reasoning_text", "")), read("thinking_start_time", 0.0),
                        read("thinking_dots", 0), str(read("turn_phase", "")))


@dataclass
class ChatView:
    """View state of one chat surface (scroll, open Workshops, height cache)."""

    scroll: float = 0.0
    expanded: set[str] = field(default_factory=set)
    agent_icon: str = "WIZARD"          # the host passes "GHOST_ENABLED" in Blender
    thumb_size: str = "M"               # attachment thumbnails: S, M or L
    # The host sets it when the last turn can be undone in one step (Engine 6b).
    revertable: bool = False
    # Suggestion buttons under the newest reply (#220); the host turns them off while a card asks.
    suggest: bool = True
    _suggest_idx: int = -1
    # The host's lookup of an image's pixel size by name (None: not loaded).
    image_size: Callable[[str], "tuple[int, int] | None"] | None = None
    content_height: float = 0.0
    # The background jobs to show under the newest turn (#423): a render or bake Blender runs.
    running_jobs: Callable[[], list[dict]] = long_jobs.running
    _jobs: list[dict] = field(default_factory=list)
    _heights: dict[tuple, float] = field(default_factory=dict)
    _drag_y: float | None = None        # mouse y while the scrollbar handle is dragged
    _live_h: dict[int, float] = field(default_factory=dict)   # running turn: tallest stream so far
    _think_h: dict[int, float] = field(default_factory=dict)  # running turn: tallest Thinking box so far
    _row_h: dict[tuple, float] = field(default_factory=dict)  # Workshop rows, measured once (#218)
    # The right-click menu (#453), apart from the hit areas so left clicks don't change: each
    # turn drawn this frame (rect clipped to the chat, index, your text, the reply), your
    # messages' boxes and the code blocks (rect, code).  Only the real frame, never a measuring one.
    turn_rects: list[tuple[Rect, int, str, str]] = field(default_factory=list)
    _user_rects: dict[int, Rect] = field(default_factory=dict)
    _code_rects: list[tuple[Rect, str]] = field(default_factory=list)
    _frame: Any = None                  # the canvas of the frame being drawn
    # Text selected with the mouse (#451, #455), and what it needs between frames: the turns
    # last drawn, the running one, and the blocks its Thinking box showed.
    selection: ChatSelection | None = None
    _turns: list[list[dict]] = field(default_factory=list)
    _active: int = -1
    _think_blocks: dict[int, list[Block]] = field(default_factory=dict)

    # -- public ----------------------------------------------------------------
    def turn_at(self, x: float, y: float) -> dict | None:
        """The message at (x, y) in the last frame, for the right-click menu (#453): its turn
        ``idx``, ``part`` ("user" over your message, else "reply"), ``text`` (what that part's
        Copy button copies), ``code`` (the code block under the mouse, or "") and ``last``."""
        for rect, idx, user, reply in self.turn_rects:
            if rect.contains(x, y):
                box = self._user_rects.get(idx)
                on_user = box is not None and box.contains(x, y)
                code = next((text for r, text in self._code_rects if r.contains(x, y)), "")
                return {"idx": idx, "part": "user" if on_user else "reply", "text": user if on_user else reply,
                        "code": code, "last": idx == getattr(self, "_last", -1)}
        return None

    # -- selection (#451, #455) -------------------------------------------------------
    def select(self, anchor: tuple, focus: tuple | None = None) -> None:
        """Select from *anchor* to *focus* (positions: (turn, unit, offset))."""
        self.selection = ChatSelection(anchor, anchor if focus is None else focus)
        self.selection.sig = self._selection_sig(self.selection)

    def extend(self, focus: tuple) -> None:
        """Move the selection's moving end to *focus*."""
        if self.selection is None:
            self.select(focus)
            return
        self.select(self.selection.anchor, focus)

    def select_word(self, pos: tuple) -> None:
        """Select the word at *pos* (a double-click)."""
        text = next((t for unit, t, _k in self._units(pos[0]) if unit == pos[1]), "")
        a, b = word_bounds(text, pos[2])
        self.select((pos[0], pos[1], a), (pos[0], pos[1], b))

    def clear_selection(self) -> bool:
        had = self.selection is not None
        self.selection = None
        return had

    def has_selection(self) -> bool:
        return self.selection is not None and not self.selection.empty

    def selected_text(self) -> str:
        """The selected text as shown (#455): markdown markers and attachment markers left
        out; blocks apart by a blank line.  Also for turns that scrolled out of view."""
        sel = self.selection
        if sel is None or sel.empty:
            return ""
        lo, hi = sel.ordered()
        return join_units(((t, unit, text, kind) for t in range(lo[0], hi[0] + 1)
                           for unit, text, kind in self._units(t)), sel)

    def _units(self, idx: int) -> list[tuple[tuple, str, str]]:
        if not 0 <= idx < len(self._turns):
            return []
        units = unit_texts(self._turns[idx], idx == self._active)
        if idx == self._active:
            for n, block in enumerate(self._think_blocks.get(idx, [])):
                text = block_text(block)
                if text is not None:
                    units.append(((THINK, n), text, block.kind))
        return sorted(units, key=lambda u: u[0])

    def _selection_sig(self, sel: ChatSelection) -> tuple | None:
        """What the selected turns are now: a selection is dropped when it changes (a turn
        gets a message, ends, another chat shows), or when the Thinking text it covers does."""
        lo, hi = sel.ordered()
        out: list[Any] = []
        for idx in range(lo[0], hi[0] + 1):
            if not 0 <= idx < len(self._turns):
                return None
            turn = self._turns[idx]
            first = message_text(turn[0].get("content"))[:200] if turn else ""
            out.append((first, len(turn),
                        sum(len(message_text(m.get("content"))) for m in turn), idx == self._active))
        if lo[0] <= self._active <= hi[0] and (hi[0] > self._active or hi[1][0] >= THINK):
            texts = [block_text(b) or "" for b in self._think_blocks.get(self._active, [])]
            if hi[0] == self._active and hi[1][0] == THINK:
                last = hi[1][1]
                texts = texts[:last] + [texts[last][:hi[2]] if last < len(texts) else None]
            out.append(tuple(texts))
        return tuple(out)

    def _unit(self, canvas: Canvas, idx: int, unit: tuple) -> tuple | None:
        """The key a unit's lines are kept under -- in the frame on screen only."""
        return (idx, unit) if canvas is self._frame else None

    def _paint_selection(self, canvas: Canvas) -> None:
        """The highlight, behind the selected text: the theme's text-selection colour
        (a text field's), darker on your messages' own coloured box."""
        sel = self.selection
        if sel is None or sel.empty:
            return
        style = canvas.style
        on_user = (style.text_field.inner[0], style.text_field.inner[1], style.text_field.inner[2], 0.55)
        rects = highlight_rects(canvas.text_lines, sel, canvas.measure)
        for cmd, rect, key in sorted(rects, key=lambda r: r[0], reverse=True):
            canvas.commands.insert(cmd, DrawCmd("rect", rect, on_user if key[1][0] == USER else style.selection))

    def scroll_by(self, dy: float, visible_height: float) -> None:
        """Scroll up (dy > 0) or down; clamped to the content."""
        self.scroll = max(0.0, min(self.scroll + dy, max(0.0, self.content_height - visible_height)))

    def draw(self, canvas: Canvas, rect: Rect, history: list[dict], live: Any = None,
             compact: bool = False, drag: tuple[float, float] | None = None) -> list[tuple[str, str]]:
        """Draw *history* into *rect*; return the actions clicked this frame.  *drag*: the
        mouse while it drags a selection -- its moving end follows it on this frame's text
        (also after the wheel scrolled under it)."""
        actions: list[tuple[str, str]] = []
        live = live_snapshot(live)          # measured and drawn from the same text (#387)
        style = canvas.style
        pad = style.pad * (0.7 if compact else 1.0)
        gap = pad
        width = rect.w - 2 * pad - self._bar_widths(style)[1]   # leave room for the scrollbar
        self._scrollbar_input(canvas, rect)
        turns = group_turns([m for m in history if m.get("role") != "system"])
        active = len(turns) - 1 if (live is not None and getattr(live, "is_thinking", False)) else -1
        self.turn_rects, self._user_rects, self._code_rects = [], {}, []
        self._turns, self._active = turns, active
        if not turns:
            canvas.wrapped(rect.x + pad, rect.top - pad, rect.w - 2 * pad,
                           "Start a conversation: type below and press Enter.", _soft(style.text))
            self.content_height = 0.0
            self.selection = None
            return actions

        self._last = len(turns) - 1
        self._jobs = list(self.running_jobs() or [])
        self._suggest_idx = self._last if active < 0 and self.suggest else -1
        heights = [self._turn_height(canvas, turn, idx, width, idx == active, live, compact)
                   for idx, turn in enumerate(turns)]
        self.content_height = sum(heights) + gap * (len(turns) + 1)
        self.scroll = max(0.0, min(self.scroll, max(0.0, self.content_height - rect.h)))

        canvas.push_clip(rect)
        bottom = rect.y + gap - self.scroll
        for idx in range(len(turns) - 1, -1, -1):
            h = heights[idx]
            if bottom > rect.top:
                break
            if bottom + h >= rect.y:
                self._frame = canvas
                self._draw_turn(canvas, turns[idx], idx, rect.x + pad, bottom + h, width,
                                idx == active, live, compact, actions)
                self._frame = None
                self.turn_rects.append((Rect(rect.x + pad, bottom, width, h).intersect(rect), idx,
                                        *_copy_texts(turns[idx], idx == active)))
            bottom += h + gap
        canvas.pop_clip()
        if self.selection is not None and self._selection_sig(self.selection) != self.selection.sig:
            self.selection = None           # its turn changed under it
        if drag is not None and self.selection is not None:
            pos = point_to_pos(canvas.text_lines, drag[0], drag[1], canvas.measure)
            if pos is not None and pos != self.selection.focus:
                self.extend(pos)
        self._paint_selection(canvas)

        self._draw_scrollbar(canvas, rect)
        size = style.unit * 1.2
        right = rect.right - pad - self._bar_widths(style)[1]
        if self.scroll > style.unit:
            jump = Rect(right - size, rect.y + pad, size, size)
            if canvas.button(jump, "jump", "", icon="TRIA_DOWN"):
                actions.append(("jump", ""))
            right = jump.x - pad * 0.5
        if active >= 0 and split_turn(turns[active])[1]:
            # Fold / unfold the running turn's Workshop from wherever you are in the chat
            # (#196); the Thinking box always shows -- it lets you feel what's happening.
            # Icons only (#216): the fold arrow and the Workshop's own icon.
            key = "t{:d}".format(active)
            side = canvas.icon_size()
            w = 2 * side + 2.0 * style.pad
            pill = Rect(right - w, rect.y + pad, w, size)
            if canvas.button(pill, "fold_workshop", ""):
                actions.append(("toggle", key))
            iy = pill.y + (pill.h - side) / 2
            lead = pill.x + style.pad * 0.75
            canvas.icon(Rect(lead, iy, side, side), "TRIA_DOWN" if key in self.expanded else "TRIA_RIGHT",
                        style.button.text)
            canvas.icon(Rect(lead + side + style.pad * 0.5, iy, side, side), "PACKAGE", style.button.text)
        return actions

    # -- measuring -----------------------------------------------------------------
    def _turn_height(self, canvas: Canvas, turn: list[dict], idx: int, width: float,
                     active: bool, live: Any, compact: bool) -> float:
        key = None
        # The newest turn with a job row is measured each frame: its time line can wrap anew.
        if not active and not (self._jobs and idx == getattr(self, "_last", -1)):
            key = (idx, len(turn), sum(len(message_text(m.get("content"))) for m in turn),
                   round(width), canvas.style.scale, f"t{idx}" in self.expanded, compact, self.thumb_size,
                   idx == self._suggest_idx,
                   tuple(sorted(k for k in self.expanded if k.startswith("x{:d}:".format(idx)))))
            cached = self._heights.get(key)
            if cached is not None:
                return cached
        scratch = Canvas(canvas.style, canvas.measure, InteractionState())
        top = 0.0
        new_top = self._draw_turn(scratch, turn, idx, 0.0, top, width, active, live, compact, [])
        height = top - new_top
        if key is not None:
            if len(self._heights) > 2000:
                self._heights.clear()
            self._heights[key] = height
        return height

    # -- drawing -------------------------------------------------------------------
    def _draw_turn(self, canvas: Canvas, turn: list[dict], idx: int, x: float, top: float,
                   width: float, active: bool, live: Any, compact: bool,
                   actions: list[tuple[str, str]]) -> float:
        style = canvas.style
        pad = style.pad * (0.7 if compact else 1.0)
        user, process, conclusion = split_turn(turn)
        if user is not None:
            indent = 0.0 if compact else style.unit * 2
            raw = message_text(user.get("content"))
            text, images = split_attachments(raw)
            side, gap = canvas.icon_size(), pad * 0.6
            copy_w = style.line_height
            inner_w = width - indent - 2 * pad - side - gap - copy_w - pad * 0.5
            thumbs = self._layout_thumbs(canvas, images, inner_w, compact)
            thumbs_h = (max(r.top for _n, r, _ok in thumbs) + pad) if thumbs else 0.0
            h = (canvas.text_height(text, inner_w) if text else style.line_height) + thumbs_h + 2 * pad
            box = Rect(x + indent, top - h, width - indent, h)
            canvas.box(box, colors=style.button, selected=True, outline=False)
            if canvas is self._frame:
                self._user_rects[idx] = box
            canvas.icon(self._first_line_icon(canvas, box.x + pad, box.top - pad, style.line_height),
                        "USER", style.button.text_sel)
            self._copy_button(canvas, box.right - pad * 0.5, box.top - pad * 0.5, "copyuser:{:d}".format(idx),
                              text, actions)
            text_top = box.top - pad
            if text:
                text_top = canvas.wrapped(box.x + pad + side + gap, text_top, inner_w, text, style.button.text_sel,
                                          unit=self._unit(canvas, idx, (USER, 0)))
            self._draw_thumbs(canvas, thumbs, box.x + pad + side + gap, text_top - pad, actions)
            top = box.y - pad
        # The same spinner and words as the panel chat (chat_status), driven by
        # the state's thinking_dots tick.
        spinner = spinner_char(live) if active else ""
        if active:
            # While it runs: the phase and the Thinking box, the Workshop right under
            # them, then the reply as it streams -- the order a finished turn has (#178).
            top = self._draw_live(canvas, idx, x, top, width, live, spinner, pad, actions, stream=False)
            if process:
                top = self._draw_workshop(canvas, process, turn, idx, x, top - pad * 0.5, width, active,
                                          compact, actions, spinner) - pad
            top = self._draw_live(canvas, idx, x, top, width, live, spinner, pad, actions, stream=True)
            # The floating Workshop button sits at the chat's bottom right: keep the row clear of it.
            return self._draw_jobs(canvas, idx, x, top, width, clear_fold=bool(process))
        self._live_h.pop(idx, None)
        self._think_h.pop(idx, None)
        self._think_blocks.pop(idx, None)
        if process:
            top = self._draw_workshop(canvas, process, turn, idx, x, top, width, active, compact, actions,
                                      spinner) - pad
        if conclusion is not None:
            seconds = next((m["turn_seconds"] for m in reversed(turn)
                            if isinstance(m.get("turn_seconds"), (int, float))), None)
            # Always Coworker, with its hat, whichever engine or agent did the work: the chat's
            # voice is Coworker's (the status line says which app is connected).
            who = "Coworker"
            label = who + ("  |  " + fmt_duration(seconds) if seconds is not None and seconds >= 1 else "")
            row_top = top
            top = self._icon_line(canvas, x, top, self.agent_icon, label, _soft(style.text, 0.2))
            done = canvas.icon_size()
            canvas.icon(self._first_line_icon(canvas, x + width - done, row_top, style.line_height),
                        "CHECKMARK", style.text)
            # Copy the whole reply, like the panel chat's copy button.
            reply = message_text(conclusion.get("content"))
            self._copy_button(canvas, x + width - done - style.pad * 0.5, row_top, "copymsg:{:d}".format(idx),
                              reply, actions)
            if self.revertable and idx == getattr(self, "_last", -1):
                side = style.line_height
                right = x + width - done - style.pad - side
                if canvas.button(Rect(right - side, row_top - side, side, side), "revert_turn", "",
                                 icon="LOOP_BACK"):
                    actions.append(("revert_turn", ""))
            top = self._draw_markdown(canvas, parse(reply), idx, x, top, width, actions, section=REPLY)
        top = self._draw_jobs(canvas, idx, x, top, width)
        if conclusion is not None and idx == self._suggest_idx:
            top = self._draw_suggestions(canvas, message_text(conclusion.get("content")), x, top, width, actions)
        return top

    def _draw_jobs(self, canvas: Canvas, idx: int, x: float, top: float, width: float,
                   clear_fold: bool = False) -> float:
        """The job row under the newest turn (#423), like the Classic chat's
        (``ui_chat._draw_job_rows``): per running render or bake its icon, "Baking, 40 s --
        Bake combined: Monkey" and a progress bar where Blender reports one; then where to
        stop it.  The whole box is one tooltip area ("jobs").  *clear_fold*: room under it for
        the running turn's floating fold button, which would cover the hint."""
        if not self._jobs or idx != getattr(self, "_last", -1):
            return top
        style = canvas.style
        pad = style.pad
        side, gap = canvas.icon_size(), pad * 0.6
        text_x, text_w = x + pad + side + gap, width - 2 * pad - side - gap
        bar_h = max(3.0, round(style.unit * 0.3))
        rows = [("{:s} — {:s}".format(str(job.get("text", "")), str(job.get("label", ""))), job)
                for job in self._jobs]
        h = pad * 0.5 + canvas.text_height(JOB_HINT, text_w) + pad * 0.5
        for text, job in rows:
            h += canvas.text_height(text, text_w) + pad * 0.3
            if job.get("progress") is not None:
                h += bar_h + pad * 0.5
        box = Rect(x, top - pad * 0.5 - h, width, h)
        canvas.box(box, colors=style.box)
        row_top = box.top - pad * 0.5
        for text, job in rows:
            canvas.icon(self._first_line_icon(canvas, x + pad, row_top, style.line_height),
                        _JOB_ICONS.get(str(job.get("kind", "")), "TIME"), style.box.text)
            row_top = canvas.wrapped(text_x, row_top, text_w, text, style.box.text)
            frac = job.get("progress")
            if frac is not None:
                frac = max(0.0, min(1.0, float(frac)))
                track = Rect(text_x, row_top - pad * 0.25 - bar_h, text_w, bar_h)
                colors = style.progress
                canvas.fill(track, colors.inner, bar_h / 2)
                if frac > 0.0:
                    canvas.fill(Rect(track.x, track.y, track.w * frac, bar_h), colors.item, bar_h / 2)
                row_top = track.y - pad * 0.25
            row_top -= pad * 0.3
        soft = _soft(style.box.text, 0.4)
        canvas.icon(self._first_line_icon(canvas, x + pad, row_top, style.line_height), "STATUSBAR", soft)
        canvas.wrapped(text_x, row_top, text_w, JOB_HINT, soft)
        canvas.hit_areas.append((box, "jobs"))
        return box.y - (style.unit * 1.2 + pad * 0.5 if clear_fold else 0.0)

    def _draw_suggestions(self, canvas: Canvas, reply: str, x: float, top: float, width: float,
                          actions: list[tuple[str, str]]) -> float:
        """The next steps the reply offers, as large buttons; a click sends one (#220)."""
        style = canvas.style
        gap = style.pad * 0.4
        for n, (label, text) in enumerate(suggestions(reply)):
            h = choice_height(canvas, width, label)          # wraps to fit a narrow sidebar
            button = Rect(x, top - style.pad * 0.5 - h, width, h)
            if draw_choice(canvas, button, "suggest:{:d}".format(n), label, recommended=n == 0):
                # "No, something else...": you finish it in the input (#270).
                actions.append(("suggest", text) if text != TYPE else ("suggest_type", "No, "))
            top = button.y - gap
        return top

    def _draw_live(self, canvas: Canvas, idx: int, x: float, top: float, width: float, live: Any,
                   spinner: str, pad: float, actions: list[tuple[str, str]], stream: bool = False) -> float:
        """The running turn.  ``stream=False``: phase + time and the live thinking, as
        markdown in a box as tall as its text, up to ``_LIVE_MAX_LINES`` lines; a longer
        one keeps its newest part in view (#452).  ``stream=True``: the reply as it
        streams.  Both only grow during the turn, so a half-typed line can't make the
        chat jitter."""
        style = canvas.style
        if stream:
            streaming = getattr(live, "streaming_text", "") or ""
            if streaming:
                start = top
                end = self._draw_markdown(canvas, parse(streaming), idx, x, top, width, actions)
                used = max(self._live_h.get(idx, 0.0), start - end)
                self._live_h[idx] = used
                top = start - used
            return top
        label = "{:s} {:s}".format(phase_text(live), spinner)
        started = float(getattr(live, "thinking_start_time", 0.0) or 0.0)
        if started:
            label += "  |  " + fmt_duration(time.time() - started)
        reasoning = _think_tail(str(getattr(live, "reasoning_text", "") or ""))
        top = self._icon_line(canvas, x, top, self.agent_icon, label, _soft(style.text, 0.15))
        if not reasoning:
            self._think_h.pop(idx, None)
            self._think_blocks.pop(idx, None)
            return top
        # Its own lines kept, drawn as markdown in the faded colour; no Copy or links in it.
        blocks = parse(reasoning)
        if canvas is self._frame:
            self._think_blocks[idx] = blocks       # what a selection in it copies (#455)
        inner_w = width - 3 * pad
        color = _soft(style.text_field.text, 0.25)
        lead, trail = _markdown_gaps(blocks, style.pad)
        # Measured the way _turn_height measures a turn, so the height drawn and the one the
        # scroll counts with agree; less the gaps markdown leaves above and below its blocks.
        scratch = Canvas(style, canvas.measure, InteractionState())
        content = -self._draw_markdown(scratch, blocks, idx, 0.0, 0.0, inner_w, [], color=color,
                                       interactive=False) - lead - trail
        inset = pad * 0.5
        h = max(self._think_h.get(idx, 0.0), min(content, _LIVE_MAX_LINES * style.line_height) + 2 * inset)
        self._think_h[idx] = h
        frame = Rect(x + pad * 0.5, top - pad * 0.5 - h, width - pad, h)
        canvas.box(frame, colors=style.text_field)
        canvas.push_clip(frame)
        # From the top while it fits; past the cap the newest part at the bottom, like a terminal.
        text_top = max(frame.top - inset, frame.y + inset + content) + lead
        self._draw_markdown(canvas, blocks, idx, frame.x + pad, text_top, inner_w, actions, color=color,
                            interactive=False, section=THINK)
        canvas.pop_clip()
        return frame.y - pad * 0.5

    def _copy_button(self, canvas: Canvas, right: float, top: float, widget_id: str, text: str,
                     actions: list[tuple[str, str]]) -> None:
        """A small square Copy button whose top-right corner is (right, top)."""
        side = canvas.style.line_height
        if canvas.button(Rect(right - side, top - side, side, side), widget_id, "", icon="COPYDOWN"):
            actions.append(("copy", text))

    def _code_frame(self, canvas: Canvas, x: float, top: float, width: float, code: str, label: str,
                    widget_id: str, actions: list[tuple[str, str]], color: RGBA | None = None,
                    expand_key: str = "", max_lines: int = _FRAME_LINES, line_chars: int = 0) -> float:
        """Code (or a tool's output) in its own framed box with a header and Copy; a long
        one shows its first lines and Show all (*expand_key*, #169)."""
        style = canvas.style
        pad = style.pad
        lines = code.rstrip("\n").split("\n")
        is_open = bool(expand_key) and expand_key in self.expanded
        shown = lines if is_open else lines[:max_lines]
        more = len(lines) - len(shown)
        cut = bool(line_chars) and not is_open and any(len(line) > line_chars for line in shown)
        if cut:
            shown = [line if len(line) <= line_chars else line[:line_chars] + "…" for line in shown]
        text = "\n".join(shown) + ("\n... {:d} more line{:s}".format(more, "" if more == 1 else "s")
                                   if more and not expand_key else "")
        head = style.line_height + pad * 0.5
        inner_w = width - 2 * pad
        h = canvas.text_height(text, inner_w, font="mono") + head + pad
        frame = Rect(x, top - h, width, h)
        canvas.box(frame, colors=style.text_field)
        soft = _soft(style.text_field.text, 0.4)
        canvas.label(Rect(frame.x + pad, frame.top - head, frame.w, head), label, soft)
        self._copy_button(canvas, frame.right - pad * 0.5, frame.top - pad * 0.25, widget_id, code, actions)
        canvas.wrapped(frame.x + pad, frame.top - head, inner_w, text, color or style.text_field.text, font="mono")
        if expand_key and (more or is_open or cut):     # cut lines: Show all brings them back whole
            return self._show_all(canvas, x, frame.y, expand_key, is_open, more, "line", actions)
        return frame.y

    def _show_all(self, canvas: Canvas, x: float, top: float, key: str, is_open: bool, more: int, unit: str,
                  actions: list[tuple[str, str]]) -> float:
        """The small Show all / Show less button under a cut-off entry (#169)."""
        style = canvas.style
        label = ("Show less" if is_open else "Show all" if more <= 0 else
                 "Show all ({:d} more {:s}{:s})".format(more, unit, "" if more == 1 else "s"))
        w = canvas.icon_size() + canvas.measure(label, "ui", style.font_size) + 2 * style.pad
        h = style.line_height * 1.1
        if canvas.button(Rect(x, top - h - style.pad * 0.2, w, h), "more:" + key, label,
                         icon="TRIA_DOWN" if is_open else "TRIA_RIGHT"):
            actions.append(("toggle", key))
        return top - h - style.pad * 0.2

    @staticmethod
    def _call_inputs(turn: list[dict]) -> dict[str, tuple[str, dict]]:
        """tool_call_id -> (tool name, arguments) from the turn's assistant tool calls."""
        out: dict[str, tuple[str, dict]] = {}
        for msg in turn:
            for call in msg.get("tool_calls") or []:
                fn = call.get("function") or {}
                args = fn.get("arguments")
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except ValueError:
                        args = {"input": args}
                out[str(call.get("id", ""))] = (str(fn.get("name", "")), args if isinstance(args, dict) else {})
        return out

    # -- attachment thumbnails --------------------------------------------------------
    def _layout_thumbs(self, canvas: Canvas, names: list[str], width: float,
                       compact: bool) -> list[tuple[str, Rect, bool]]:
        """(name, rect, loaded) per image, wrapped in rows; rects grow down from y=0."""
        style = canvas.style
        units = THUMB_SIZES.get(self.thumb_size, 4.0)
        if compact:
            units = min(units, THUMB_SIZES["S"])
        height = style.unit * units
        out: list[tuple[str, Rect, bool]] = []
        x = y = 0.0
        for name in names:
            size = self.image_size(name) if self.image_size is not None else None
            if size and size[0] > 0 and size[1] > 0:
                w, h, loaded = min(width, height * size[0] / size[1]), height, True
            else:   # not in this file: a chip with the name
                w = min(width, canvas.measure(name, "ui", style.font_size) + canvas.icon_size() + 2 * style.pad)
                h, loaded = style.unit, False
            if x > 0 and x + w > width:
                x, y = 0.0, max(r.top for _n, r, _ok in out) + style.pad * 0.5
            out.append((name, Rect(x, y, w, h), loaded))
            x += w + style.pad * 0.5
        return out

    def _draw_thumbs(self, canvas: Canvas, thumbs: list[tuple[str, Rect, bool]], x: float, top: float,
                     actions: list[tuple[str, str]]) -> None:
        style = canvas.style
        row_tops: dict[float, float] = {}
        for _name, r, _ok in thumbs:     # each row's height, so rows hang from *top*
            row_tops[r.y] = max(row_tops.get(r.y, 0.0), r.h)
        for name, r, loaded in thumbs:
            row_h = row_tops[r.y]
            rect = Rect(x + r.x, top - r.y - row_h + (row_h - r.h), r.w, r.h)
            widget_id = "img:" + name
            if loaded:
                canvas.fill(rect, style.text_field.inner, style.radius(style.text_field))
                canvas.image(rect.inset(1.0), name)
                hovered = canvas.state.hovered(rect)
                canvas.stroke(rect, style.cursor if hovered else style.text_field.outline,
                              style.radius(style.text_field))
            else:
                canvas.box(rect, colors=style.box)
                side = canvas.icon_size()
                canvas.icon(Rect(rect.x + style.pad * 0.5, rect.y + (rect.h - side) / 2, side, side),
                            "IMAGE_DATA", style.box.text)
                canvas.label(Rect(rect.x + side + style.pad, rect.y, rect.w, rect.h), name, style.box.text)
            canvas.hit_areas.append((rect, widget_id))
            if loaded and canvas.state.clicked == widget_id:
                actions.append(("open_image", name))

    # -- icons -------------------------------------------------------------------------
    @staticmethod
    def _first_line_icon(canvas: Canvas, x: float, top: float, line_h: float) -> Rect:
        """The square for an icon at *x*, centred on the line that starts at *top*."""
        side = canvas.icon_size()
        return Rect(x, top - line_h + (line_h - side) / 2, side, side)

    def _icon_line(self, canvas: Canvas, x: float, top: float, icon: str, text: str,
                   color: RGBA, width: float | None = None, font: str = "ui") -> float:
        """An icon, then *text* (wrapped to *width* when given); return the new top."""
        style = canvas.style
        side, gap = canvas.icon_size(), style.pad * 0.6
        canvas.icon(self._first_line_icon(canvas, x, top, style.line_height), icon, color)
        if width is None:
            top -= style.line_height
            canvas.text(x + side + gap, top + (style.line_height - style.font_size) / 2 + style.font_size * 0.2,
                        text, color, font)
            return top
        return canvas.wrapped(x + side + gap, top, width - side - gap, text, color, font=font)

    def _draw_workshop(self, canvas: Canvas, process: list[dict], turn: list[dict], idx: int, x: float,
                       top: float, width: float, active: bool, compact: bool,
                       actions: list[tuple[str, str]], spinner: str = "") -> float:
        style = canvas.style
        pad = style.pad * (0.7 if compact else 1.0)
        key = f"t{idx}"
        tools = [m for m in process if m.get("role") == "tool"]
        failed = sum(1 for m in tools if _tool_failed(m))
        # "Workshop <spinner>" while the turn runs, like the panel chat.
        parts = ["Workshop " + spinner if active else "Workshop",
                 "{:d} step{:s}".format(len(tools), "" if len(tools) == 1 else "s")]
        if failed:
            parts.append("{:d} failed".format(failed))
        is_open = key in self.expanded
        header = Rect(x, top - style.unit, width, style.unit)
        if canvas.button(header, "ws:" + key, "", align="left"):
            actions.append(("toggle", key))
        side, gap = canvas.icon_size(), style.pad * 0.5
        iy = header.y + (header.h - side) / 2
        text_color = style.button.text
        lead = header.x + style.pad
        canvas.icon(Rect(lead, iy, side, side), "TRIA_DOWN" if is_open else "TRIA_RIGHT", text_color)
        canvas.icon(Rect(lead + side + gap, iy, side, side),
                    "WARNING" if failed else "PACKAGE", text_color)
        canvas.label(Rect(lead + 2 * (side + gap), header.y, header.w, header.h), "  |  ".join(parts), text_color)
        top = header.y
        if not is_open:
            return top
        inputs = self._call_inputs(turn)
        row_x, row_w = x + pad, width - 2 * pad
        clip = canvas._clips[-1] if canvas._clips else None      # None: only measuring
        for n, msg in enumerate(process):
            role = msg.get("role")
            text = message_text(msg.get("content"))
            # A long Workshop (#218): a row measured before is only stepped over when it is
            # off screen, or when the turn is just being measured.
            row_key = (id(msg), idx, n, role, len(text), msg.get("tool_call_id"), msg.get("name"), round(row_w),
                       style.scale, tuple(k for k in ("x{:d}:{:d}".format(idx, n), "x{:d}:{:d}:code".format(idx, n),
                                                      "x{:d}:{:d}:res".format(idx, n)) if k in self.expanded))
            known = self._row_h.get(row_key)
            if known is not None and (clip is None or top - known > clip.top or top < clip.y):
                top -= known
                continue
            row_start = top
            if role == "tool":
                bad = _tool_failed(msg)
                name = str(msg.get("name", "tool"))
                args = msg.get("args") or inputs.get(str(msg.get("tool_call_id", "")), ("", {}))[1]
                row_top = top - pad * 0.5
                top = self._icon_line(canvas, row_x, row_top, "ERROR" if bad else "CHECKMARK", name,
                                      _ERROR if bad else style.text, row_w - style.line_height, font="mono")
                code = args.get("code") if isinstance(args, dict) else None
                if isinstance(code, str) and code.strip():      # what ran, in its own frame
                    top = self._code_frame(canvas, row_x, top - pad * 0.3, row_w, code, "python",
                                           "copycode:{:d}:{:d}".format(idx, n), actions,
                                           expand_key="x{:d}:{:d}:code".format(idx, n)) - pad * 0.3
                elif isinstance(args, dict) and args:
                    shown = ", ".join("{:s}={:s}".format(k, json.dumps(v)[:60]) for k, v in list(args.items())[:4])
                    top = canvas.wrapped(row_x + side + gap, top, row_w - side - gap, shown,
                                         _soft(style.text, 0.35), font="mono")
                result = text.strip()
                if result and result != "(running)":
                    top = self._code_frame(canvas, row_x + style.pad, top - pad * 0.3, row_w - style.pad, result,
                                           "error" if bad else "result", "copyres:{:d}:{:d}".format(idx, n),
                                           actions, _ERROR if bad else None,
                                           expand_key="x{:d}:{:d}:res".format(idx, n),
                                           max_lines=_RESULT_LINES, line_chars=_RESULT_LINE_CHARS) - pad * 0.3
            elif role == "reasoning":
                label = str(msg.get("label") or "Thinking")
                body = " ".join(text.split())
                row_top = top - pad * 0.5
                key = "x{:d}:{:d}".format(idx, n)
                is_open = key in self.expanded
                cut = len(body) > _ENTRY_CHARS and not is_open
                shown = body[:_ENTRY_CHARS].rstrip() + "..." if cut else body
                top = self._icon_line(canvas, row_x, row_top, self.agent_icon,
                                      "{:s}: {:s}".format(label, shown), _soft(style.text),
                                      row_w - style.line_height - pad * 0.5)
                self._copy_button(canvas, row_x + row_w, row_top, "copythink:{:d}:{:d}".format(idx, n), body,
                                  actions)
                if len(body) > _ENTRY_CHARS:
                    top = self._show_all(canvas, row_x + canvas.icon_size() + style.pad * 0.5, top, key, is_open,
                                         len(body) - _ENTRY_CHARS, "character", actions)
            elif is_system_note_msg(msg):
                body = text[len("[System:"):-1].strip() if text.startswith("[System:") and text.endswith("]") else text
                title, icon = NOTE_TITLES.get(str(msg.get("system_note") or ""), ("Note", "INFO"))
                top = self._icon_line(canvas, row_x, top - pad * 0.5, icon,
                                      "{:s}: {:s}".format(title, " ".join(body.split())[:300]),
                                      _soft(style.text, 0.5), row_w)
            if len(self._row_h) > 5000:
                self._row_h.clear()
            self._row_h[row_key] = row_start - top
        return top

    # -- markdown --------------------------------------------------------------------
    def _draw_markdown(self, canvas: Canvas, blocks: list[Block], idx: int, x: float, top: float,
                       width: float, actions: list[tuple[str, str]], color: RGBA | None = None,
                       interactive: bool = True, section: int | None = None) -> float:
        """Draw *blocks*; return the new top.  *color* tints all of it (the Thinking box's faded
        look); with *interactive* off there are no Copy buttons and no link areas (#452).
        With *section* each block is a selectable unit (#455): (section, block index)."""
        style = canvas.style
        pad = style.pad
        base = color or style.text
        code_n = 0
        for n, block in enumerate(blocks):
            unit = self._unit(canvas, idx, (section, n)) if section is not None else None
            if block.kind == "code" or block.kind == "table":
                lines = block.lines or [""]
                text = "\n".join(lines)
                inner_w = width - 2 * pad
                # Code blocks get a header strip (language + Copy) so the
                # button never covers the code, even in the narrow sidebar.
                head = style.unit * 1.1 if block.kind == "code" else 0.0
                h = canvas.text_height(text, inner_w, font="mono") + 2 * pad + head
                box = Rect(x, top - h - pad * 0.5, width, h)
                canvas.box(box, colors=style.text_field)
                if block.kind == "code" and canvas is self._frame:     # the menu's Copy Code (#453)
                    self._code_rects.append((box, text))
                if block.kind == "code":
                    strip = Rect(box.x, box.top - head, box.w, head)
                    soft = _soft(style.text_field.text, 0.4)
                    side = canvas.icon_size()
                    canvas.icon(Rect(strip.x + pad, strip.y + (head - side) / 2, side, side), "SCRIPT", soft)
                    canvas.label(Rect(strip.x + pad + side + pad * 0.5, strip.y, strip.w, head),
                                 block.lang or "code", soft)
                    bw = style.unit * 0.9    # a square icon button
                    copy = Rect(box.right - bw - pad * 0.75, strip.y + (head - bw) / 2, bw, bw)
                    if interactive and canvas.button(copy, "copy:{:d}:{:d}".format(idx, code_n), "",
                                                     icon="COPYDOWN"):
                        actions.append(("copy", text))
                    code_n += 1
                canvas.wrapped(box.x + pad, box.top - head - pad, inner_w, text, color or style.text_field.text,
                               font="mono", unit=unit)
                top = box.y - pad * 0.5
            elif block.kind == "hr":
                top -= pad
                canvas.fill(Rect(x, top, width, max(1.0, style.scale)), style.outline)
                top -= pad
            elif block.kind == "heading":
                size = style.font_size * _HEADING_SCALE.get(block.level, 1.0)
                top -= pad * (1.2 if block.level <= 2 else 0.8)
                icon = _HEADING_ICON.get(block.level, "KEYTYPE_BREAKDOWN_VEC")
                side = size * 0.8
                # Keyframe colours with their dark border, like the Dope Sheet.
                mark = Rect(x, top - size * 1.45 + (size * 1.45 - side) / 2, side, side)
                edge = max(1.0, style.scale * 1.5)
                canvas.icon(Rect(mark.x - edge, mark.y - edge, side + 2 * edge, side + 2 * edge), icon,
                            style.keyframe_border)
                canvas.icon(mark, icon, style.keyframes[min(block.level, 4) - 1])
                top = self._flow(canvas, block.spans, x + side + pad * 0.6, top, width - side - pad * 0.6,
                                 actions, size=size, bold=True, color=color or style.title,
                                 interactive=interactive, unit=unit) - pad * 0.4
            elif block.kind == "item":
                indent = style.unit * (0.6 + block.level)
                marker = ("•" if block.level == 0 else "◦") if block.marker == "-" else block.marker
                canvas.text(x + indent - style.unit * 0.5, top - style.line_height + style.line_height * 0.3,
                            marker, base)
                top = self._flow(canvas, block.spans, x + indent, top, width - indent, actions, color=color,
                                 interactive=interactive, unit=unit)
            elif block.kind == "quote":
                start = top
                top = self._flow(canvas, block.spans, x + style.unit * 0.6, top, width - style.unit * 0.6,
                                 actions, color=_soft(base, 0.25), interactive=interactive, unit=unit)
                canvas.fill(Rect(x, top, max(2.0, 2 * style.scale), start - top), style.outline)
            else:
                top = self._flow(canvas, block.spans, x, top, width, actions, color=color,
                                 interactive=interactive, unit=unit) - pad * 0.3
        return top

    def _flow(self, canvas: Canvas, spans: list[Span], x: float, top: float, width: float,
              actions: list[tuple[str, str]], size: float | None = None, bold: bool = False,
              color: RGBA | None = None, interactive: bool = True, unit: tuple | None = None) -> float:
        """Lay out styled *spans* as wrapped lines; return the new top.  Links are click areas
        only when *interactive*.  With *unit* the lines are kept for selecting (#455)."""
        style = canvas.style
        size = size or style.font_size
        line_h = size * 1.45
        base = color or style.text
        # Words, and each run of spaces as one (none before the first word): the unit's text.
        lines: list[list[tuple[str, Span, float, int]]] = [[]]
        used = 0.0
        for token, span, offset in flow_tokens(spans)[1]:
            font = "mono" if span.style == "code" else "ui"
            if token == " ":
                lines[-1].append((" ", span, canvas.measure(" ", font, size), offset))
                used += lines[-1][-1][2]
                continue
            w = canvas.measure(token, font, size)
            if lines[-1] and used + w > width:
                while lines[-1] and lines[-1][-1][0] == " ":
                    lines[-1].pop()
                lines.append([])
                used = 0.0
            lines[-1].append((token, span, w, offset))
            used += w
        clip = canvas._clips[-1] if canvas._clips else None
        for line in lines:
            top -= line_h
            baseline = top + (line_h - size) / 2 + size * 0.2
            cx = x
            first_cmd = len(canvas.commands)
            pieces = []
            for token, span, w, offset in line:
                font = "mono" if span.style == "code" else "ui"
                own = -1
                if span.style == "code":
                    canvas.fill(Rect(cx - CHIP_PAD, top + line_h * 0.1, w + 2 * CHIP_PAD, line_h * 0.8),
                                style.text_field.inner, line_h * 0.3)
                    own = len(canvas.commands)          # its highlight goes over its own background
                    canvas.text(cx, baseline, token, style.text_field.text, font="mono", size=size)
                elif span.style == "link":
                    canvas.text(cx, baseline, token, style.link if interactive else _soft(style.link, 0.25),
                                size=size, bold=bold)
                    if interactive:
                        area = Rect(cx, top, w, line_h)
                        canvas.hit_areas.append((area, "link:" + span.url))
                        if canvas.state.clicked == "link:" + span.url and ("link", span.url) not in actions:
                            actions.append(("link", span.url))
                else:
                    tint = _soft(base, 0.3) if span.style == "italic" else base
                    canvas.text(cx, baseline, token, tint, size=size, bold=bold or span.style == "bold")
                pieces.append((offset, token, cx, w, font, size, own))
                cx += w
            if unit is not None and pieces:
                canvas.text_lines.append(TextLine(unit, pieces[0][0], x, top + line_h, top, "ui", size,
                                                  tuple(pieces), first_cmd, clip))
        return top

    # -- scrollbar: like Blender's region scrollbars (View2D) ---------------------------
    @staticmethod
    def _bar_widths(style: Style) -> tuple[float, float]:
        """(thin, full) widths: V2D_SCROLL_MIN_WIDTH and V2D_SCROLL_WIDTH -- in UI scale only,
        like Blender's region scrollbars: the chat's or the panel's zoom doesn't fatten it (#279)."""
        px = style.ui_scale
        return 5.0 * px + 2.0 * px, 0.45 * 20.0 * px + 2.0 * px

    def _bar_geometry(self, style: Style, rect: Rect) -> tuple[Rect, Rect, float] | None:
        """(track, handle, scroll per handle pixel) at full width, or None when all fits."""
        max_scroll = self.content_height - rect.h
        if max_scroll <= 0:
            return None
        _thin, full = self._bar_widths(style)
        margin = 2.0 * style.scale
        track = Rect(rect.right - full - margin, rect.y + margin, full, rect.h - 2 * margin)
        handle_h = min(track.h, max(style.unit, track.h * rect.h / self.content_height))
        travel = track.h - handle_h
        y = track.y + (self.scroll / max_scroll) * travel
        return track, Rect(track.x, y, full, handle_h), (max_scroll / travel if travel > 0 else 0.0)

    def _scrollbar_input(self, canvas: Canvas, rect: Rect) -> None:
        """Drag the handle; click the track to page (uses last frame's geometry)."""
        state = canvas.state
        geometry = self._bar_geometry(canvas.style, rect)
        if geometry is None or state.mouse is None:
            self._drag_y = None
            return
        _track, handle, ratio = geometry
        if state.pressed == "scroll_handle":
            if self._drag_y is not None:
                self.scroll_by((state.mouse[1] - self._drag_y) * ratio, rect.h)
            self._drag_y = state.mouse[1]
            return
        self._drag_y = None
        if state.clicked == "scroll_track":
            page = rect.h * 0.9
            self.scroll_by(page if state.mouse[1] > handle.top else -page, rect.h)

    def _draw_scrollbar(self, canvas: Canvas, rect: Rect) -> None:
        geometry = self._bar_geometry(canvas.style, rect)
        if geometry is None:
            return
        style = canvas.style
        track, handle, _ratio = geometry
        colors = style.scroll
        state = canvas.state
        dragging = state.pressed == "scroll_handle"
        over = state.mouse is not None and track.contains(*state.mouse)
        # Fade in as the mouse comes near (AZONEFADEOUT .. AZONEFADEIN), like Blender; while the
        # chat is longer than its room it always shows, faint (#279).
        alpha = 0.0
        if dragging:
            alpha = 1.0
        elif state.mouse is not None:
            mx, my = state.mouse
            dx = max(track.x - mx, 0.0, mx - track.right)
            dy = max(track.y - my, 0.0, my - track.top)
            dist = (dx * dx + dy * dy) ** 0.5
            unit = 20.0 * style.ui_scale
            fade_in, fade_out = 5.0 * unit, 6.5 * unit
            alpha = 1.0 if dist <= fade_in else max(0.0, 1.0 - (dist - fade_in) / (fade_out - fade_in))
        alpha = max(alpha, _SCROLL_IDLE_ALPHA)
        canvas.hit_areas.append((track, "scroll_track"))
        canvas.hit_areas.append((handle, "scroll_handle"))
        if alpha <= 0.0:
            return
        thin, full = self._bar_widths(style)
        width = full if (over or dragging) else thin
        x = track.right - width

        def faded(color: RGBA, strength: float = alpha) -> RGBA:
            return (color[0], color[1], color[2], color[3] * strength)

        # With the mouse away only a thin, faint handle shows, like a region's scrollbar;
        # the track and outlines fade in as the mouse comes near.
        near = (alpha - _SCROLL_IDLE_ALPHA) / (1.0 - _SCROLL_IDLE_ALPHA)
        radius = colors.roundness * width / 2
        if near > 0.0:
            canvas.fill(Rect(x, track.y, width, track.h), faded(colors.inner, near), radius)
            canvas.stroke(Rect(x, track.y, width, track.h), faded(colors.outline, near), radius)
        item = colors.item
        if dragging:
            item = _lighten(item, 0.2)
        elif over and handle.contains(*state.mouse):
            item = _lighten(item, 0.1)
        canvas.fill(Rect(x, handle.y, width, handle.h), faded(item), radius)
        if near > 0.0:
            canvas.stroke(Rect(x, handle.y, width, handle.h), faded(colors.outline, near), radius)
