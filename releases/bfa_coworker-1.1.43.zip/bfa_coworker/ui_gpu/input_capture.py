# SPDX-FileCopyrightText: 2026 Blender Authors
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""
Route window events to the GPU chat (Tier 4, tasks "GPU 3" and "GPU 4").

GPU-drawn widgets get no mouse or keyboard from Blender, so one small modal
operator per window watches events and hands them to the chat surface
(:class:`surface.ChatSurface`) under the mouse:

* **hover** redraws the surface when what's under the mouse changes (button
  highlights, the scrollbar fading in), and **press / release** make clicks;
  a press on the scrollbar handle keeps dragging even outside the region;
* the **wheel** scrolls the chat, **Ctrl+wheel** zooms it;
* **click** in the input box focuses it and places the cursor (Shift+click
  selects, a drag selects, a double-click selects a word: #451); a click
  anywhere else leaves it -- that click still goes through, unless it was on
  a message: a press there selects the message's text and a drag extends it,
  across messages (#455); Ctrl+C copies that (redacted, like the Copy
  buttons) while the mouse is over the chat and no box has the keyboard, Esc
  or a click elsewhere drops it;
* **keys** go to the focused box (Enter sends, Shift+Enter adds a line...);
  while it has focus, editor shortcuts never fire;
* Ctrl+C / X / V use the window manager clipboard; Ctrl+V's text goes to the host's
  *on_action* (``("paste", text)``), which attaches a copied image or image file to the
  box's chat or pastes the text (#450);
* **right-click** over a chat opens its own menu (``BFACW_MT_chat_context``,
  #453) with what was under the mouse (:func:`menu_target`), not the Node
  Editor's: the press, release and click are all used, so neither Blender's
  (press) nor Bforartists' (click) node menu opens; nothing changes outside;
* **Edit** opens the text in a native text field, which takes IME input
  (Chinese, Japanese, Korean...) that a GPU box can't;
* the caret blinks, and the operator restarts after a file is opened (a
  file load ends every modal operator) and for new windows;
* **autosave** keeps running: Blender skips autosave while any modal
  operator runs (#370), so when Blender's would be due the chat writes it
  with Blender's own *Save Autosave* (``wm.save_auto_save``), by Blender's
  rules, and the operator never stops -- no key or click is lost (#488).

Only the region is redrawn, never the whole area (a 3D View sidebar must
not re-render the viewport).  The host calls :func:`set_host` with a
*router* -- ``router(context, event) -> (surface, area, region) | None`` --
and an *on_action* callback for what the box asks (``send``, ``stop``...).
A bare :class:`input_box.InputBox` also works as a target (input only).
Needs ``bpy``.
"""

from __future__ import annotations

import time
from typing import Any, Callable

import bpy  # pylint: disable=import-error

from .input_box import InputBox, Key

__all__ = (
    "autosave_step",
    "ensure_running",
    "focus",
    "focused_box",
    "key_from_event",
    "menu_edit",
    "menu_target",
    "register",
    "set_host",
    "unregister",
)

Router = Callable[[Any, Any], "tuple[Any, Any, Any] | None"]
OnAction = Callable[[InputBox, str, str], None]

_HOST: dict[str, Any] = {"router": None, "on_action": None, "after_key": None}
# The focused box and its region; the surface being dragged / hovered; running windows.
_FOCUS: dict[str, Any] = {"box": None, "region": None}
_DRAG: dict[str, Any] = {"hit": None}
# Ctrl+MMB drag zoom over a full-size chat: (hit, start mouse y, start zoom).
_ZOOM_DRAG: dict[str, Any] = {"hit": None, "y": 0.0, "zoom": 1.0}
_HOVER: dict[str, Any] = {"hit": None, "cursor": "DEFAULT"}
# The chat that has text selected in its messages (#455): (surface, area, region).
_SELECT: dict[str, Any] = {"hit": None}
_RUNNING: set[int] = set()
# The right-click menu (#453): the chat it was opened on and what was under the mouse.
CONTEXT_MENU = "BFACW_MT_chat_context"
_MENU: dict[str, Any] = {"surface": None, "area": None, "region": None, "widget": None, "turn": None}
_RIGHT = frozenset({"RELEASE", "CLICK", "DOUBLE_CLICK"})
# Autosave (#370, #488).  "since": when Blender's autosave interval last started (the chat's last
# autosave, a save, a clean check).
_AUTOSAVE: dict[str, Any] = {"since": 0.0}
# #638: the last key / mouse button press or release or wheel turn the chat's operator saw (monotonic
# seconds; 0.0 = none yet) and the mouse buttons held right now.  The autosave waits for a quiet moment.
_INPUT: dict[str, Any] = {"last": 0.0, "held": set()}
_QUIET_SECONDS = 2.0
# Job kinds Blender may know (the valid list differs per version; an unknown one is skipped).
_JOB_KINDS = ("RENDER", "RENDER_PREVIEW", "COMPOSITE", "OBJECT_BAKE", "OBJECT_BAKE_TEXTURE",
              "SHADER_COMPILATION")
_TRACE_LIMIT, _TRACE_KEEP = 200, 100

_IGNORED = frozenset({"TIMER", "TIMER_REPORT", "TIMERREGION", "WINDOW_DEACTIVATE", "NONE"})
_MOVES = frozenset({"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"})
_WHEEL = {"WHEELUPMOUSE": True, "WHEELDOWNMOUSE": False}
_NEWLINE_MARK = " ↵ "     # how a line break shows in the one-line native field
_BLINK_SECONDS = 0.53
_WATCH_SECONDS = 1.0
_OWN_MODAL = frozenset({"BFACW_OT_gpu_input", "bfacw.gpu_input"})
# Modes whose undo steps are global (memfile) or image ones: Blender autosaves only in those while
# global undo is on (ED_undosys_autosave_compatible); in edit / sculpt mode it waits.
_AUTOSAVE_MODES = frozenset({"OBJECT", "POSE", "PAINT_TEXTURE"})


def set_host(router: Router | None, on_action: OnAction | None = None,
             after_key: Callable[[InputBox], None] | None = None) -> None:
    """Set (or clear, with ``None``) where events go, who handles ``send`` / ``stop``,
    and who hears about every key the focused box used (*after_key*)."""
    _HOST["router"], _HOST["on_action"], _HOST["after_key"] = router, on_action, after_key
    if router is None:
        _blur()
        _DRAG["hit"] = _HOVER["hit"] = _SELECT["hit"] = None
        _forget_menu()


def menu_target() -> dict[str, Any]:
    """What the right-click menu was opened on (#453): ``surface``, ``area``, ``region``,
    ``widget`` (the hit id under the mouse) and ``turn`` (:meth:`ChatSurface.turn_at`)."""
    return _MENU


def _forget_menu() -> None:
    _MENU.update(surface=None, area=None, region=None, widget=None, turn=None)


def menu_edit(action: str, clipboard: str) -> str | None:
    """*action* ``cut`` / ``copy`` / ``paste`` / ``select_all`` from the menu, on the prompt
    it was opened on, like Ctrl+X / C / V / A (#453); the box gets the keyboard.  Returns
    the new clipboard text, or None to leave it."""
    surface, region = _MENU["surface"], _MENU["region"]
    box = getattr(surface, "box", None)
    if box is None:
        return None
    model, out = box.model, None
    if action in ("cut", "copy"):
        out = model.selected_text() or None
        if out and action == "cut":
            model.delete()
    elif action == "paste":
        box.paste(clipboard or "")
    elif action == "select_all":
        model.select_all()
    focus(box, region)
    return out


def focused_box() -> InputBox | None:
    return _FOCUS["box"]


def key_from_event(event: Any) -> Key:
    return Key(type=event.type, value=event.value, unicode=event.unicode or "",
               shift=event.shift, ctrl=event.ctrl, alt=event.alt, oskey=event.oskey)


def _tag(region: Any) -> None:
    try:
        if region is not None:
            region.tag_redraw()
    except ReferenceError:      # the region went away (screen change, file load)
        pass


def _redraw() -> None:
    _tag(_FOCUS["region"])


def _blur() -> None:
    box = _FOCUS["box"]
    if box is not None:
        box.focused = False
        box.suggestions = []
    _redraw()
    _FOCUS["box"] = _FOCUS["region"] = None


def focus(box: InputBox, region: Any) -> None:
    """Give *box* (drawn in *region*) the keyboard."""
    if _FOCUS["box"] is not box:
        _blur()
    box.focused, box.blink_phase = True, True
    _FOCUS["box"], _FOCUS["region"] = box, region
    _redraw()


def _run_actions(box: InputBox, context: Any) -> None:
    actions, box.actions = box.actions, []
    for action, value in actions:
        if action == "copy":
            context.window_manager.clipboard = value
        elif action == "paste":
            text = context.window_manager.clipboard or ""
            if _HOST["on_action"] is None:
                box.paste(text)
            else:           # the host may attach an image instead, to this box's chat (#450)
                _HOST["on_action"](box, "paste", text)
        elif action == "blur":
            _blur()
        elif action == "native_edit":
            bpy.ops.bfacw.gpu_input_native("INVOKE_DEFAULT")
        elif _HOST["on_action"] is not None:
            _HOST["on_action"](box, action, value)


def _local(event: Any, region: Any) -> tuple[float, float]:
    return float(event.mouse_x - region.x), float(event.mouse_y - region.y)


def _shows_file_browser(window: Any) -> bool:
    """*window* shows a temporary file browser: its own window, or an area maximized for it
    (Preferences > Interface > Temporary Editors).  A File Browser in a layout is not one."""
    try:
        screen = window.screen
        return bool(screen.is_temporary) and any(a.type == "FILE_BROWSER" for a in screen.areas)
    except (AttributeError, ReferenceError):
        return False


def _same(a: Any, b: Any) -> bool:
    return a is not None and b is not None and a[0] is b[0]


class BFACW_OT_gpu_input(bpy.types.Operator):
    """Pass mouse and keys to the Coworker chat"""

    bl_idname = "bfacw.gpu_input"
    bl_label = "Coworker Chat Input"
    bl_options = {"INTERNAL"}

    _window = 0

    def invoke(self, context, _event):
        ptr = context.window.as_pointer()
        if ptr in _RUNNING:
            return {"CANCELLED"}
        self._window = ptr
        _RUNNING.add(ptr)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def _finish(self):
        _RUNNING.discard(self._window)
        return {"FINISHED", "PASS_THROUGH"}

    def modal(self, context, event):
        _note_input(event)
        router = _HOST["router"]
        if router is None:
            return self._finish()
        if event.type in _IGNORED or not event.type:
            # No type = an event Python can't name, like a file drop (EVT_DROP): it must reach
            # the file handlers even while the box has focus (#215).
            return {"PASS_THROUGH"}
        if _shows_file_browser(getattr(context, "window", None)):
            # A file browser of its own (Open, Attach Image...): its keys are its own, never the
            # focused chat's, or Enter sent the draft instead of opening the file (#449).
            return {"PASS_THROUGH"}
        try:
            return self._handle(context, event, router)
        except ReferenceError:      # a region/area went away mid-event
            _DRAG["hit"] = _HOVER["hit"] = None
            return {"PASS_THROUGH"}

    def _handle(self, context, event, router):
        drag = _DRAG["hit"]
        zoom = _ZOOM_DRAG["hit"]
        if zoom is not None:                           # Ctrl+MMB drag: up zooms in, like Blender's views
            if event.type in _MOVES:
                surface, _area, region = zoom
                surface.zoom = max(0.6, min(2.5, _ZOOM_DRAG["zoom"] + (event.mouse_y - _ZOOM_DRAG["y"]) * 0.005))
                _tag(region)
                return {"RUNNING_MODAL"}
            if event.type == "MIDDLEMOUSE" and event.value == "RELEASE":
                _ZOOM_DRAG["hit"] = None
                return {"RUNNING_MODAL"}
        if event.type == "MIDDLEMOUSE" and event.value == "PRESS" and event.ctrl:
            hit = router(context, event)
            # Full-size chats only: in a sidebar, Ctrl+MMB zooms the whole sidebar (and the chat with it).
            if hit is not None and hasattr(hit[0], "zoom") and not getattr(hit[0], "compact", True):
                _ZOOM_DRAG.update(hit=hit, y=float(event.mouse_y), zoom=hit[0].zoom)
                return {"RUNNING_MODAL"}
        if event.type in _MOVES:
            if drag is not None:                       # dragging: keep feeding, even outside
                surface, _area, region = drag
                surface.on_move(*_local(event, region))
                _tag(region)
                return {"RUNNING_MODAL"}
            hit = router(context, event)
            hover = _HOVER["hit"]
            if hover is not None and not _same(hover, hit):
                if hover[0].on_leave():
                    _tag(hover[2])
            _HOVER["hit"] = hit if hit is not None and hasattr(hit[0], "on_move") else None
            cursor = "DEFAULT"
            if _HOVER["hit"] is not None:
                x, y = _local(event, hit[2])
                if hit[0].on_move(x, y):
                    _tag(hit[2])
                pick = getattr(hit[0], "cursor_at", None)
                if pick is not None:
                    cursor = pick(x, y)
                elif hit[0].hit(x, y) == "input":
                    cursor = "TEXT"
            # An I-beam over text, like a text field (#455); up-down arrows on an edge that
            # resizes (#389).  Kept while a drag runs (moves then don't come here).
            if cursor != _HOVER["cursor"]:
                _HOVER["cursor"] = cursor
                try:
                    context.window.cursor_set(cursor)
                except (AttributeError, TypeError, ValueError):
                    pass
            return {"PASS_THROUGH"}

        if event.type == "RIGHTMOUSE":
            used = _right_click(context, event, router)
            if used is not None:
                return used

        if event.type == "LEFTMOUSE" and event.value == "RELEASE" and drag is not None:
            surface, _area, region = drag
            surface.on_release(*_local(event, region))
            _DRAG["hit"] = None
            _tag(region)
            return {"RUNNING_MODAL"}

        # Blender sends a double-click's second press as DOUBLE_CLICK (#451, #455).
        left_double = event.type == "LEFTMOUSE" and event.value == "DOUBLE_CLICK"
        if event.type in {"LEFTMOUSE", "RIGHTMOUSE"} and (event.value == "PRESS" or left_double):
            hit = router(context, event)
            if event.type == "LEFTMOUSE":
                _drop_selection_elsewhere(hit)
            if hit is not None and event.type == "LEFTMOUSE":
                target, _area, region = hit
                x, y = _local(event, region)
                if hasattr(target, "on_press"):            # a chat surface
                    used = target.on_press(x, y, shift=event.shift, double=left_double)
                    if target.box.focused:
                        focus(target.box, region)
                    elif _FOCUS["box"] is target.box:
                        _blur()
                    if target.pressed is not None:
                        _DRAG["hit"] = hit
                    if getattr(target, "pressed", None) == "select":
                        _SELECT["hit"] = hit
                    _tag(region)
                    if used:
                        return {"RUNNING_MODAL"}
                elif target.rect is not None and target.rect.contains(x, y):   # a bare input box
                    focus(target, region)
                    target.place_cursor(x, y, select=event.shift)
                    return {"RUNNING_MODAL"}
            if _FOCUS["box"] is not None:
                _blur()
            return {"PASS_THROUGH"}

        if event.type in _WHEEL:
            hit = router(context, event)
            if hit is not None and hasattr(hit[0], "on_wheel"):
                if hit[0].on_wheel(_WHEEL[event.type], event.ctrl, *_local(event, hit[2])):
                    _tag(hit[2])
                    return {"RUNNING_MODAL"}
            return {"PASS_THROUGH"}

        box = _FOCUS["box"]
        if box is None:
            return _selection_key(context, event, router) or {"PASS_THROUGH"}
        used = box.handle_key(key_from_event(event))
        _run_actions(box, context)
        if used and _HOST["after_key"] is not None:
            _HOST["after_key"](box)
        _redraw()
        return {"RUNNING_MODAL"} if used else {"PASS_THROUGH"}


def _drop_selection_elsewhere(hit: Any) -> None:
    """A left press outside the chat that has text selected drops that selection (#455)."""
    held = _SELECT["hit"]
    if held is None or _same(held, hit):
        return
    _SELECT["hit"] = None
    try:
        if held[0].clear_selection():
            _tag(held[2])
    except (AttributeError, ReferenceError):
        pass


def _selection_key(context: Any, event: Any, router: Router) -> set[str] | None:
    """Ctrl+C (Cmd+C) copies the chat's selected text, Esc drops it (#455) -- while no box
    has the keyboard and the mouse is over that chat; anywhere else the key is the editor's
    (Ctrl+C in the 3D View still copies objects).  None: not used."""
    held = _SELECT["hit"]
    if held is None or event.value != "PRESS" or event.type not in ("C", "ESC"):
        return None
    surface, _area, region = held
    if not getattr(surface, "has_selection", lambda: False)() or not _same(router(context, event), held):
        return None
    if event.type == "ESC":
        surface.clear_selection()
        _SELECT["hit"] = None
        _tag(region)
        return {"RUNNING_MODAL"}
    if not (event.ctrl or event.oskey) or event.shift or event.alt:
        return None
    text = surface.selected_text()
    if text:
        if _HOST["on_action"] is not None:      # the host's copy: keys and tokens as *** (#346)
            _HOST["on_action"](surface.box, "copy", text)
        else:
            context.window_manager.clipboard = text
    return {"RUNNING_MODAL"}


def _chat_under(context: Any, event: Any, router: Router) -> tuple[Any, Any, Any] | None:
    """The chat surface under the mouse (inside what it drew), or None."""
    hit = router(context, event)
    if hit is None or not hasattr(hit[0], "on_right_press"):
        return None
    bounds = hit[0].bounds
    return hit if bounds is not None and bounds.contains(*_local(event, hit[2])) else None


def _open_menu(context: Any, area: Any, region: Any) -> None:
    """Open the chat's menu in *area* / *region*: its entries then run there, on that chat."""
    try:
        with context.temp_override(window=context.window, area=area, region=region):
            bpy.ops.wm.call_menu(name=CONTEXT_MENU)
    except (RuntimeError, TypeError, ReferenceError) as ex:
        print("[Coworker] chat menu: {:s}".format(str(ex)))


def _right_click(context: Any, event: Any, router: Router) -> set[str] | None:
    """#453: a right press over a chat opens the chat's menu; its release and click are used
    too.  None: not over a chat -- handled as before."""
    hit = _chat_under(context, event, router)
    if hit is None:
        return None            # not over a chat: the editor's own right-click (and blur, below)
    if event.value != "PRESS":
        return {"RUNNING_MODAL"} if event.value in _RIGHT else None
    surface, area, region = hit
    x, y = _local(event, region)
    _MENU.update(surface=surface, area=area, region=region, **surface.on_right_press(x, y))
    if _MENU["widget"] == "input":         # like a text field: the prompt takes the keyboard
        focus(surface.box, region)
    _tag(region)
    _open_menu(context, area, region)
    return {"RUNNING_MODAL"}


class BFACW_OT_gpu_input_native(bpy.types.Operator):
    """Edit the message in a native text field (supports IME input)"""

    bl_idname = "bfacw.gpu_input_native"
    bl_label = "Edit Message"
    bl_options = {"INTERNAL"}

    text: bpy.props.StringProperty(  # type: ignore[valid-type]
        name="Message",
        description="Line breaks show as ↵ and come back as line breaks",
        options={"SKIP_SAVE"},
    )

    def invoke(self, context, _event):
        box = _FOCUS["box"]
        if box is None:
            return {"CANCELLED"}
        self.text = box.model.text.replace("\n", _NEWLINE_MARK)
        return context.window_manager.invoke_props_dialog(self, width=int(520 * context.preferences.view.ui_scale))

    def draw(self, _context):
        self.layout.prop(self, "text", text="")

    def execute(self, _context):
        box = _FOCUS["box"]
        if box is not None:
            box.model.set_text(self.text.replace(_NEWLINE_MARK, "\n").replace("↵", "\n"))
            box.focused = True
            _redraw()
        return {"FINISHED"}


def ensure_running() -> None:
    """Start the input operator in every window that doesn't have it yet."""
    if _HOST["router"] is None:
        return
    wm = bpy.context.window_manager
    _RUNNING.intersection_update(w.as_pointer() for w in wm.windows)   # closed windows
    for window in wm.windows:
        if window.as_pointer() in _RUNNING:
            continue
        try:
            # The window alone, never screen=: overriding the screen is refused while any window
            # shows a temporary screen (Ctrl+Space), so the floating chat never came back (#391).
            with bpy.context.temp_override(window=window):
                bpy.ops.bfacw.gpu_input("INVOKE_DEFAULT")
        except (RuntimeError, TypeError):   # window closing / no screen yet: next tick
            pass


def autosave_step(now: float, since: float, autosave_on: bool, autosave_minutes: float,
                  dirty: bool, busy: bool, undo_ok: bool, job_running: bool = False,
                  bridge_busy: bool = False, quiet: bool = True) -> str:
    """What to do about Blender's autosave on this watch tick (#488): ``"wait"``, ``"skip"``
    (nothing to save: the next interval starts, as in Blender) or ``"write"``.

    Blender's own rules (``wm_autosave_timer``, ``wm_files.cc``): every *autosave_minutes*
    from the last autosave or save; a saved file has nothing to write; never while another
    modal operator runs (*busy*), nor in a mode whose undo isn't global (not *undo_ok*: edit,
    sculpt...) -- it waits.  Due one watch tick early, so the chat's write comes before
    Blender's own timer would start retrying.

    #638: it also waits for a quiet moment: no Blender job running (*job_running*), no bridge
    step running or queued (*bridge_busy*), and the user not in the middle of a click or a
    key (not *quiet*).  A clean file is still skipped, quiet or not."""
    if not autosave_on or now - since < max(1.0, autosave_minutes) * 60.0 - _WATCH_SECONDS:
        return "wait"
    if not dirty:
        return "skip"
    if busy or not undo_ok or job_running or bridge_busy or not quiet:
        return "wait"
    return "write"


def _note_input(event: Any) -> None:
    """Remember the last press / release / wheel turn and which mouse buttons are held (#638).
    Looks only; never raises and never changes what the operator does with the event."""
    try:
        etype, value = event.type, event.value
        if etype == "WINDOW_DEACTIVATE":        # the release may go to another window
            _INPUT["held"].clear()
            return
        if not etype or etype in _IGNORED or etype in _MOVES:
            return
        if etype in _WHEEL or etype.startswith("WHEEL"):
            _INPUT["last"] = time.monotonic()
            return
        if value in ("PRESS", "DOUBLE_CLICK", "RELEASE"):
            _INPUT["last"] = time.monotonic()
            if etype.endswith("MOUSE") or etype.startswith("BUTTON"):
                if value == "RELEASE":
                    _INPUT["held"].discard(etype)
                else:
                    _INPUT["held"].add(etype)
    except Exception:  # pylint: disable=broad-exception-caught
        pass


def _seconds_since_input(now: float) -> float | None:
    last = _INPUT["last"]
    return now - last if last else None


def _input_quiet(now: float) -> bool:
    """No mouse button held and no key / button / wheel event for :data:`_QUIET_SECONDS`."""
    if _INPUT["held"]:
        return False
    idle = _seconds_since_input(now)
    return idle is None or idle >= _QUIET_SECONDS


def _running_jobs() -> list[str]:
    """The kinds of Blender job running now (render, bake, compositor...)."""
    out = []
    for kind in _JOB_KINDS:
        try:
            if bpy.app.is_job_running(kind):
                out.append(kind)
        except Exception:  # pylint: disable=broad-exception-caught  # kind unknown in this version
            pass
    return out


def _bridge_state() -> str:
    """``"step"`` while the bridge runs agent code, ``"queued"`` while an answer is pending, else ``"idle"``."""
    try:
        from .. import deferred_tool, ui_activity
        if ui_activity.is_stepping():
            return "step"
        if deferred_tool.has_pending():
            return "queued"
    except Exception:  # pylint: disable=broad-exception-caught
        pass
    return "idle"


def _trace_path() -> Any:
    from .. import log
    return log.get_log_path().parent / "autosave_trace.txt"


def _trace(what: str, locks: int, now: float | None = None) -> None:
    """One line on disk about the autosave write (#638), flushed and closed at once, so a crash
    leaves what was going on.  No file names, no object names.  Never raises."""
    try:
        import os
        now = time.monotonic() if now is None else now
        idle = _seconds_since_input(now)
        try:
            mode = str(bpy.context.mode)
        except Exception:  # pylint: disable=broad-exception-caught
            mode = "?"
        line = "{:s} pid={:d} {:s} mode={:s} jobs={:s} bridge={:s} locks={:d} idle={:s}\n".format(
            time.strftime("%Y-%m-%d %H:%M:%S"), os.getpid(), what, mode,
            ",".join(_running_jobs()) or "-", _bridge_state(), locks,
            "-" if idle is None else "{:.1f}s".format(idle))
        path = _trace_path()
        with open(str(path), "a", encoding="utf-8") as f:
            f.write(line)
            f.flush()
        if path.stat().st_size > 64 * _TRACE_LIMIT:     # about 200 lines: read it back only then
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines(True)
            if len(lines) > _TRACE_LIMIT:
                path.write_text("".join(lines[-_TRACE_KEEP:]), encoding="utf-8")
    except Exception:  # pylint: disable=broad-exception-caught  # OSError and the rest: never stop the autosave
        pass


def _other_modal_running() -> bool:
    """A modal operator other than the chat's runs in some window (a grab, a box select...)."""
    try:
        return any(op.bl_idname not in _OWN_MODAL
                   for window in bpy.context.window_manager.windows for op in window.modal_operators)
    except (AttributeError, ReferenceError):
        return False


def _undo_allows_autosave() -> bool:
    try:
        if not bpy.context.preferences.edit.use_global_undo:
            return True
        return bpy.context.mode in _AUTOSAVE_MODES
    except AttributeError:
        return True


def _autosave_tick() -> None:
    """Write Blender's autosave when it is due, the way Blender would (#488)."""
    on, minutes = _autosave_prefs()
    now = time.monotonic()
    step = autosave_step(now, _AUTOSAVE["since"], on, minutes, bool(getattr(bpy.data, "is_dirty", True)),
                         _other_modal_running(), _undo_allows_autosave(),
                         bool(_running_jobs()), _bridge_state() != "idle", _input_quiet(now))
    if step == "wait":
        return
    _AUTOSAVE["since"] = now
    if step == "write":
        try:        # Blender's own autosave write; it restarts Blender's autosave timer too
            from .. import co_work_guard
            # #558: an autosave runs no save handlers, so lift the co-work lock here (put
            # back also when the write fails): the file keeps the objects' own hide_select.
            with co_work_guard.lifted(bpy.data) as held:
                locks = len(held) if hasattr(held, "__len__") else 0
                _trace("begin", locks, now)
                try:
                    bpy.ops.wm.save_auto_save()
                except RuntimeError:
                    _trace("failed", locks)
                    raise
                _trace("done", locks)
        except RuntimeError as ex:
            print("[Coworker] autosave failed: {:s}".format(str(ex)))


@bpy.app.handlers.persistent
def _on_save_post(*_args) -> None:
    # A save restarts Blender's autosave interval.
    _AUTOSAVE["since"] = time.monotonic()


def _autosave_prefs() -> tuple[bool, float]:
    try:
        paths = bpy.context.preferences.filepaths
        return bool(paths.use_auto_save_temporary_files), float(paths.auto_save_time)
    except (AttributeError, TypeError):
        return False, 0.0


def _watch() -> float:
    chat_on = _HOST["router"] is not None and bool(_RUNNING)
    if chat_on:
        _autosave_tick()        # no gap: nothing the chat should get can be lost (#488)
    ensure_running()
    return _WATCH_SECONDS


def _blink() -> float:
    box = _FOCUS["box"]
    if box is not None:
        box.blink_phase = not box.blink_phase
        _redraw()
    return _BLINK_SECONDS


@bpy.app.handlers.persistent
def _on_load_pre(*_args) -> None:
    # Opening a file ends every modal operator and frees every area.
    _RUNNING.clear()
    _INPUT["held"].clear()
    _FOCUS["box"] = _FOCUS["region"] = None
    _DRAG["hit"] = _HOVER["hit"] = _ZOOM_DRAG["hit"] = _SELECT["hit"] = None
    _forget_menu()


_CLASSES = (BFACW_OT_gpu_input, BFACW_OT_gpu_input_native)


def register() -> None:
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.app.handlers.load_pre.append(_on_load_pre)
    bpy.app.handlers.save_post.append(_on_save_post)
    _AUTOSAVE["since"] = time.monotonic()
    for fn, first in ((_watch, 0.2), (_blink, _BLINK_SECONDS)):
        if not bpy.app.timers.is_registered(fn):
            bpy.app.timers.register(fn, first_interval=first, persistent=True)


def unregister() -> None:
    set_host(None)
    for fn in (_watch, _blink):
        if bpy.app.timers.is_registered(fn):
            bpy.app.timers.unregister(fn)
    if _on_load_pre in bpy.app.handlers.load_pre:
        bpy.app.handlers.load_pre.remove(_on_load_pre)
    if _on_save_post in bpy.app.handlers.save_post:
        bpy.app.handlers.save_post.remove(_on_save_post)
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
    _RUNNING.clear()
