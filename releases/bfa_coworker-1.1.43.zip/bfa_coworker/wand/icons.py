# SPDX-FileCopyrightText: 2026 Blender Authors
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""
The icons of Coworker's operators (Tier 4m section 3.3, Wand 0 #331, Bforartists style #563).

Built from Bforartists' own icon SVGs (``icons/wand/<name>.svg``, see ``SOURCES.md``
there; rendered by ``_misc/build_icons.py``) as PNGs in two variants:
``<name>_dark_<size>.png`` for a dark theme and ``<name>_light_<size>.png`` for a
light theme, at 32 and 64 px (one palette today, so the two are the same picture).
The wand badge in the corner marks the tools that need Coworker's AI.
They are loaded with ``bpy.utils.previews`` and drawn with ``icon_value``, so
they work in plain Blender as in Bforartists.  The variant follows the theme's
menu text (light text = dark theme); the size follows the UI scale.  When the
previews can't be made, :func:`operator` falls back to a Blender icon.
"""

from __future__ import annotations

__all__ = (
    "ICON_DIR",
    "ICON_NAMES",
    "LAYOUT_ICON_NAMES",
    "SIZES",
    "THEMES",
    "free",
    "icon_id",
    "menu",
    "operator",
    "png_path",
    "size_for",
    "theme_for",
)

import os
from typing import Any

ICON_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "icons", "wand")
# A familiar base glyph, with the wand badge when the tool needs Coworker's AI; "wand" is the mark.
ICON_NAMES = ("remove_silences", "captions", "vertical", "transcribe", "tidy_nodes", "explain",
              "translate", "wand")
# Reframe's layout icons (#606): a tall frame with the parts a layout makes, drawn in Bforartists'
# palette by ``_misc/build_reframe_icons.py`` (PNGs only, same file scheme and loading as above).
LAYOUT_ICON_NAMES = ("reframe_full", "reframe_full_blur", "reframe_full_tracked", "reframe_split_half",
                     "reframe_split_top", "reframe_split_bottom", "reframe_track_all")
THEMES = ("dark", "light")
SIZES = (32, 64)

_STATE: dict[str, Any] = {}


def png_path(name: str, theme: str, size: int) -> str:
    return os.path.join(ICON_DIR, "{:s}_{:s}_{:d}.png".format(name, theme, size))


def theme_for(text_rgb: Any) -> str:
    """``"dark"`` when the theme's text is light (a dark theme), else ``"light"``."""
    r, g, b = (float(c) for c in tuple(text_rgb)[:3])
    return "dark" if 0.2126 * r + 0.7152 * g + 0.0722 * b >= 0.5 else "light"


def size_for(ui_scale: float) -> int:
    """32 px up to 1.25x UI scale, 64 px above (crisp on hi-DPI and on 2x toolshelf buttons)."""
    return 64 if ui_scale > 1.25 else 32


def _current_key() -> tuple[str, int]:
    import bpy  # pylint: disable=import-error
    prefs = bpy.context.preferences
    try:
        text = prefs.themes[0].user_interface.wcol_menu_item.text
    except (AttributeError, IndexError):
        text = (0.9, 0.9, 0.9)
    scale = getattr(prefs.system, "ui_scale", 1.0) * getattr(prefs.system, "pixel_size", 1.0)
    return theme_for(text), size_for(scale)


def _collection(group: str, names: tuple) -> Any:
    """The preview collection *group* ("wand" or "layout") for the current theme and size, made on demand.  Two
    collections, so the Reframe layout icons (#606) never change how the wand icons load."""
    key = _current_key()
    state = _STATE.setdefault(group, {"previews": None, "key": None})
    if state["previews"] is None or state["key"] != key:
        import bpy.utils.previews  # pylint: disable=import-error
        if state["previews"] is not None:
            bpy.utils.previews.remove(state["previews"])
        previews = bpy.utils.previews.new()
        theme, size = key
        for icon in names:
            path = png_path(icon, theme, size)
            if os.path.isfile(path):
                previews.load(icon, path, "IMAGE")
        state["previews"], state["key"] = previews, key
    return state["previews"]


def icon_id(name: str) -> int:
    """The ``icon_value`` of wand icon *name* for the current theme, or 0."""
    try:
        group, names = ("layout", LAYOUT_ICON_NAMES) if name in LAYOUT_ICON_NAMES else ("wand", ICON_NAMES)
        preview = _collection(group, names).get(name)
        return preview.icon_id if preview is not None else 0
    except Exception:  # pylint: disable=broad-exception-caught
        return 0        # no previews (background, a missing file): the caller's Blender icon


def operator(layout: Any, idname: str, *, name: str, fallback: str, text: str | None = None) -> Any:
    """``layout.operator`` with wand icon *name*, or the Blender icon *fallback*."""
    from ..shared import icon as safe_icon
    value = icon_id(name)
    kwargs = {} if text is None else {"text": text}
    if value:
        return layout.operator(idname, icon_value=value, **kwargs)
    return layout.operator(idname, icon=safe_icon(fallback), **kwargs)


def menu(layout: Any, menu_id: str, *, name: str, fallback: str, text: str | None = None) -> Any:
    """``layout.menu`` with wand icon *name*, or the Blender icon *fallback*."""
    from ..shared import icon as safe_icon
    value = icon_id(name)
    kwargs = {} if text is None else {"text": text}
    if value:
        return layout.menu(menu_id, icon_value=value, **kwargs)
    return layout.menu(menu_id, icon=safe_icon(fallback), **kwargs)


def free() -> None:
    for group in ("wand", "layout"):
        state = _STATE.pop(group, None)
        if state is not None and state["previews"] is not None:
            try:
                import bpy.utils.previews  # pylint: disable=import-error
                bpy.utils.previews.remove(state["previews"])
            except Exception:  # pylint: disable=broad-exception-caught
                pass
